package controle_Alunos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class Controle_Alunos {

	private HashSet<Aluno> colecao_Alunos = new HashSet<Aluno>();
	private HashSet<Grupo> colecao_Grupos = new HashSet<Grupo>();
	private ArrayList<Aluno> alunosQueResponderamQuestoes = new ArrayList<>();
	private HashMap<Grupo, Aluno> grupo = new HashMap<>();

	public void cadastraAluno(String matricula, String nome, String curso) {
		Aluno alunoExiste = buscaAluno(matricula);
		if (alunoExiste == null) {
			Aluno aluno = new Aluno(matricula, nome, curso);
			colecao_Alunos.add(aluno);
		} else
			System.out.println("MATR�CULA J� CADASTRADA!");
	}

	public Aluno buscaAluno(String matricula) {
		Aluno retorno = null;
		for (Aluno a : colecao_Alunos) {
			if (a.getMatricula().equals(matricula)) {
				retorno = a;
			}
		}
		return retorno;
	}

	public Grupo buscaGrupo(String nome) {
		Grupo grupoProcurado = null;
		for (Grupo grupo : colecao_Grupos) {
			if (grupo.getNome().equalsIgnoreCase(nome))
				grupoProcurado = grupo;
		}
		return grupoProcurado;
	}

	public void criaGrupo(String nomeDoGrupo) {
		Grupo novoGrupo = new Grupo(nomeDoGrupo);
		colecao_Grupos.add(novoGrupo);
	}

	public void alocarAluno(String matricula, String nomeGrupo) {
		Aluno aluno = buscaAluno(matricula);
		Grupo grupoProcurado = buscaGrupo(nomeGrupo);
		grupo.put(grupoProcurado, aluno);
	}

	public void imprimirGrupo(String nomeGrupo) {
		Grupo grupoProcurado = buscaGrupo(nomeGrupo);
		if (grupoProcurado == null)
			System.out.println("Grupo n�o cadastrado.");
		else {
			System.out.println("Alunos do grupo " + grupoProcurado.getNome() + ":");
			System.out.println("* " + grupo.get(grupoProcurado).toString());
		}
	}

	public void cadastrarResposta(String matricula) {
		Aluno aluno = buscaAluno(matricula);
		if(aluno == null) {
			System.out.println("Aluno n�o cadastrado.");
		}else {
			alunosQueResponderamQuestoes.add(aluno);
			System.out.println("ALUNO REGISTRADO!");
		}
	}

	public void imprimeAlunosQueResponderamQuestoes() {
		int contador = 0;
		for (Aluno aluno : alunosQueResponderamQuestoes) {
			contador ++;
			System.out.println(contador+". "+aluno.toString());
		}
	}
	
}
