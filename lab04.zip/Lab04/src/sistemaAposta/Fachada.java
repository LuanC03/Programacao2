package sistemaAposta;

public class Fachada {

	public void cadastraCenario(String descricao) {
		ControllerAposta.cadastraCenario(descricao);
	}

	public void exibirCenario(int cenario) {
		ControllerAposta.exibirCenario(cenario);
	}

	public void exibirCenarios() {
		ControllerAposta.exibirCenarios();
	}

	public void cadastraAposta(int cenario, String apostador, int valor, String previsao) {
		ControllerAposta.cadastraAposta(cenario, apostador, valor, previsao);
	}

	public void valorTotalDeApostas(int cenario) {
		ControllerAposta.valorTotalDeApostas(cenario);
	}

	public void totalDeApostas(int cenario) {
		ControllerAposta.totalDeApostas(cenario);
	}

	public void exibeApostas(int cenario) {
		ControllerAposta.exibeApostas(cenario);
	}

	public void fecharAposta(int cenario, boolean ocorreu) {
		ControllerAposta.fecharAposta(cenario, ocorreu);
	}

	public void getCaixaCenario(int cenario) {
		ControllerAposta.getCaixaCenario(cenario);
	}

	public void getTotalRateioCenario(int cenario) {
		ControllerAposta.getTotalRateioCenario(cenario);
	}
}
