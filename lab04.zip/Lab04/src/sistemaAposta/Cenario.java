package sistemaAposta;

import java.util.ArrayList;

public class Cenario {

	private String descricao;
	private String estado;
	private ArrayList Aposta;

	public Cenario(String descricao, String estado) {
		this.descricao = descricao;
		this.estado = estado;
		Aposta = new ArrayList();
	}

	public String getDescricao() {
		return descricao;
	}

	public String getEstado() {
		return estado;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	@Override
	public String toString() {
		return "''" + ControllerAposta.getTamanhoListaCenarios() + " - " + descricao + " - " + estado + "''";
	}	
}
