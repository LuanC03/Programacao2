package sistemaAposta;

public class Caixa {

	
}
