package sistemaAposta;

import java.util.ArrayList;
import java.util.HashMap;

public class ControllerAposta {

	private static int posicao = 0;
	private static int totalApostas = 0;
	private static Cenario cenarios;
	private static Aposta apostas;
	private static ArrayList listaCenarios = new ArrayList();
	

	public static int cadastraCenario(String descricao) {
		cenarios = new Cenario(descricao, "Não finalizado");
		listaCenarios.add(cenarios);
		return listaCenarios.size();
	}

	public static String exibirCenario(int cenario) {
		if (cenario <= listaCenarios.size()) {
			for (int i = 0; i < listaCenarios.size(); i++) {
				if (i == cenario) {
					return cenarios.toString();
				}
			}
		}
		return "POSICAO INVALIDA!";
	}

	public static String exibirCenarios() {
		String retorno = "";
		for (int i = 0; i < listaCenarios.size(); i++) {
			retorno += cenarios.toString() + "\n";
		}
		return retorno;
	}

	public static void cadastraAposta(int cenario, String apostador, int valor, String previsao) {
		apostas = new Aposta(apostador, valor, previsao);
		listaCenarios.add(cenario);
		listaCenarios.add(apostas);
	}

	// Errei no segundo for, no atributo "totalApostas", acho que ele nao conta
	// pra cada cenario
	public static double valorTotalDeApostas(int cenario) {
		double valor = 0;
		for (int i = 0; i < listaCenarios.size(); i++) {
			if (i == cenario) {
				valor += ((Aposta) listaCenarios.get(cenario)).getValor();
			}
		}
		return valor / 100;
	}

	// metodo errado(totalApostas), pois preciso contar realmente o total para
	// cada cenario.
	public static int totalDeApostas(int cenario) {
		int valor = 0;
		for (int i = 0; i < listaCenarios.size(); i++) {
			if (i == cenario) {
				for (int j = 0; j < totalApostas; j++) {
					valor += 1;
				}
			}
		}
		return valor;
	}

	public static String exibeApostas(int cenario) {
		String retorno = "";
		for (int i = 0; i < listaCenarios.size(); i++) {
			if (i == cenario) {
				retorno += listaCenarios.get(cenario).toString() + "\n";
			}
		}
		return retorno;
	}

	public static void fecharAposta(int cenario, boolean ocorreu) {
		if (ocorreu == true) {
			for (int i = 0; i < listaCenarios.size(); i++) {
				if (i == cenario) {
					cenarios.setDescricao("ocorreu");
				}
			}

		} else {
			for (int i = 0; i < listaCenarios.size(); i++) {
				if (i == cenario) {
					cenarios.setDescricao("n ocorreu");
				}
			}
		}
	}

	public static int getCaixaCenario(int cenario) {
		int valorTotal = 0;
		for (int i = 0; i < listaCenarios.size(); i++) {
			if (i == cenario) {
				for (int j = 0; j < totalApostas; j++) {
					valorTotal += apostas.getValor();
				}
			}
		}
		return valorTotal;
	}

	// falta implementar
	public static int getTotalRateioCenario(int cenario) {
		int valorVencedores = 0;
		for (int i = 0; i < listaCenarios.size(); i++) {
			if (i == cenario) {

			}
		}
		return valorVencedores;
	}
	public static int getTamanhoListaCenarios(){
		return listaCenarios.size();
	}
}
