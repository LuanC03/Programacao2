package sistemaAposta;

public class Aposta {

	private String nomeApostador;
	private int valor;
	private String aposta;
	
	public Aposta(String nomeApostador, int valor, String aposta){
		this.nomeApostador = nomeApostador;
		this.valor = valor;
		this.aposta = aposta;
	}

	public int getValor() {
		return valor;
	}

	public void setValor(int valor) {
		this.valor = valor;
	}

	public String getAposta() {
		return aposta;
	}

	public void setAposta(String aposta) {
		this.aposta = aposta;
	}

	public String getNomeApostador() {
		return nomeApostador;
	}

	@Override
	public String toString() {
		return "- ''" + nomeApostador + " - R$" + valor/100 + " - " + aposta+"''";
	}
	
}
