import static org.junit.Assert.*;

import org.junit.Test;

//@Test(expected=IllegalArgumentException.class)

public class CardapioTest {

	@Test
	public void testCriaCardapioPadrao() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo");
	}
	
	@Test
	public void testCriaCardapio() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 8);
	}
	
	public void testAdicionaItemCardapio() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 2);
		Item item = new Item("arroz branco", 100);
		cardapioTeste.adicionaItem(item);
	}
	
	@Test(expected=ArrayIndexOutOfBoundsException.class)
	public void testAdicionaItemCardapioCheio() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 2);
		Item item = new Item("arroz branco", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("arroz a grega", 200);
		cardapioTeste.adicionaItem(item);
		item = new Item("macarrao", 200);
		cardapioTeste.adicionaItem(item);
	}
	
	@Test
	public void testListaCardapioCompleto() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 3);
		Item item = new Item("arroz branco", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("arroz a grega", 200);
		cardapioTeste.adicionaItem(item);
		item = new Item("macarrao", 200);
		cardapioTeste.adicionaItem(item);
		String esperado = "1 - arroz branco - 100 calorias/porção\n2 - arroz a grega - 200 calorias/porção\n3 - macarrao - 200 calorias/porção";
		assertEquals(esperado, cardapioTeste.listaCardapio());
	}
	
	@Test
	public void testListaCardapioVazio() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 3);
		assertEquals("", cardapioTeste.listaCardapio());
	}
	
	@Test
	public void testListaCardapioPreenchidoNaoCompleto() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo");
		Item item = new Item("arroz branco", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("arroz a grega", 200);
		cardapioTeste.adicionaItem(item);
		String esperado = "1 - arroz branco - 100 calorias/porção\n2 - arroz a grega - 200 calorias/porção";
		assertEquals(esperado, cardapioTeste.listaCardapio());
	}
	
	@Test
	public void testCalcularCaloriasRefeicaoValidaCardapioCompletoPadrao() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 8);
		Item item = new Item("arroz branco", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("arroz a grega", 200);
		cardapioTeste.adicionaItem(item);
		item = new Item("macarrao", 200);
		cardapioTeste.adicionaItem(item);
		item = new Item("feijoada", 150);
		cardapioTeste.adicionaItem(item);
		item = new Item("feijao verde", 90);
		cardapioTeste.adicionaItem(item);
		item = new Item("frango assado", 90);
		cardapioTeste.adicionaItem(item);
		item = new Item("bife", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("vinagrete", 0);
		cardapioTeste.adicionaItem(item);
		String[] refeicao = {"arroz a grega", "feijoada", "bife", "vinagrete"};
		assertEquals(450,cardapioTeste.calcularCaloriasRefeicao(refeicao, "padrão"));
	}
	
	@Test
	public void testCalcularCaloriasRefeicaoValidaCardapioCompletoGrande() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 8);
		Item item = new Item("arroz branco", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("arroz a grega", 200);
		cardapioTeste.adicionaItem(item);
		item = new Item("macarrao", 200);
		cardapioTeste.adicionaItem(item);
		item = new Item("feijoada", 150);
		cardapioTeste.adicionaItem(item);
		item = new Item("feijao verde", 90);
		cardapioTeste.adicionaItem(item);
		item = new Item("frango assado", 90);
		cardapioTeste.adicionaItem(item);
		item = new Item("bife", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("vinagrete", 0);
		cardapioTeste.adicionaItem(item);
		String[] refeicao = {"arroz a grega", "feijoada", "bife", "vinagrete"};
		assertEquals(450*2,cardapioTeste.calcularCaloriasRefeicao(refeicao, "grande"));
	}
	
	@Test
	public void testCalcularCaloriasRefeicaoValidaCardapioCompletoMega() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 8);
		Item item = new Item("arroz branco", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("arroz a grega", 200);
		cardapioTeste.adicionaItem(item);
		item = new Item("macarrao", 200);
		cardapioTeste.adicionaItem(item);
		item = new Item("feijoada", 150);
		cardapioTeste.adicionaItem(item);
		item = new Item("feijao verde", 90);
		cardapioTeste.adicionaItem(item);
		item = new Item("frango assado", 90);
		cardapioTeste.adicionaItem(item);
		item = new Item("bife", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("vinagrete", 0);
		cardapioTeste.adicionaItem(item);
		String[] refeicao = {"arroz a grega", "feijoada", "bife", "vinagrete"};
		assertEquals(450*3,cardapioTeste.calcularCaloriasRefeicao(refeicao, "mega"));
	}
	
	@Test
	public void testCalcularCaloriasRefeicaoValidaCardapioNaoCompletoPadrao() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 8);
		Item item = new Item("arroz branco", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("arroz a grega", 200);
		cardapioTeste.adicionaItem(item);
		item = new Item("macarrao", 200);
		cardapioTeste.adicionaItem(item);
		String[] refeicao = {"arroz a grega", "macarrao"};
		assertEquals(400,cardapioTeste.calcularCaloriasRefeicao(refeicao, "padrão"));
	}
	
	@Test
	public void testCalcularCaloriasRefeicaoValidaCardapioNaoCompletoGrande() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 8);
		Item item = new Item("arroz branco", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("arroz a grega", 200);
		cardapioTeste.adicionaItem(item);
		item = new Item("macarrao", 200);
		cardapioTeste.adicionaItem(item);
		String[] refeicao = {"arroz a grega", "macarrao"};
		assertEquals(400*2,cardapioTeste.calcularCaloriasRefeicao(refeicao, "grande"));
	}
	
	@Test
	public void testCalcularCaloriasRefeicaoValidaCardapioNaoCompletoMega() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 8);
		Item item = new Item("arroz branco", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("arroz a grega", 200);
		cardapioTeste.adicionaItem(item);
		item = new Item("macarrao", 200);
		cardapioTeste.adicionaItem(item);
		String[] refeicao = {"arroz a grega", "macarrao"};
		assertEquals(400*3,cardapioTeste.calcularCaloriasRefeicao(refeicao, "mega"));
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testCalcularCaloriasRefeicaoInvalidaPadrao() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 3);
		Item item = new Item("arroz branco", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("arroz a grega", 200);
		cardapioTeste.adicionaItem(item);
		item = new Item("vinagrete", 0);
		cardapioTeste.adicionaItem(item);
		String[] refeicao = {"arroz a grega", "feijoada", "bife", "vinagrete"};
		int calorias = cardapioTeste.calcularCaloriasRefeicao(refeicao, "padrão");
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testCalcularCaloriasRefeicaoInvalidaGrande() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 3);
		Item item = new Item("arroz branco", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("arroz a grega", 200);
		cardapioTeste.adicionaItem(item);
		item = new Item("vinagrete", 0);
		cardapioTeste.adicionaItem(item);
		String[] refeicao = {"arroz a grega", "feijoada", "bife", "vinagrete"};
		int calorias = cardapioTeste.calcularCaloriasRefeicao(refeicao, "grande");
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testCalcularCaloriasRefeicaoInvalidaMega() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 3);
		Item item = new Item("arroz branco", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("arroz a grega", 200);
		cardapioTeste.adicionaItem(item);
		item = new Item("vinagrete", 0);
		cardapioTeste.adicionaItem(item);
		String[] refeicao = {"arroz a grega", "feijoada", "bife", "vinagrete"};
		int calorias = cardapioTeste.calcularCaloriasRefeicao(refeicao, "mega");
	}
	
	@Test
	public void testCalcularCaloriasRefeicaoVaziaPadrao() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 2);
		Item item = new Item("arroz branco", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("arroz a grega", 200);
		cardapioTeste.adicionaItem(item);
		String[] refeicao = {};
		assertEquals(0, cardapioTeste.calcularCaloriasRefeicao(refeicao, "padrão"));
	}
	
	@Test
	public void testCalcularCaloriasRefeicaoVaziaGrande() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 2);
		Item item = new Item("arroz branco", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("arroz a grega", 200);
		cardapioTeste.adicionaItem(item);
		String[] refeicao = {};
		assertEquals(0, cardapioTeste.calcularCaloriasRefeicao(refeicao, "grande"));
	}
	
	@Test
	public void testCalcularCaloriasRefeicaoVaziaMega() {
		Cardapio cardapioTeste = new Cardapio("Seu Olavo", 2);
		Item item = new Item("arroz branco", 100);
		cardapioTeste.adicionaItem(item);
		item = new Item("arroz a grega", 200);
		cardapioTeste.adicionaItem(item);
		String[] refeicao = {};
		assertEquals(0, cardapioTeste.calcularCaloriasRefeicao(refeicao, "mega"));
	}
	
	

}
