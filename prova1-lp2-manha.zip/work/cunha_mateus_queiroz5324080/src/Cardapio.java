
public class Cardapio {
	private String nomeEstabelecimento;
	private Item[] itens;
	private int itensCadastrados;
	
	public Cardapio(String nomeEstabelecimento, int quantidadeItens) {
		this.nomeEstabelecimento = nomeEstabelecimento;
		itens = new Item[quantidadeItens];
		this.itensCadastrados = 0;
	}
	
	public Cardapio(String nomeEstabelecimento) {
		this(nomeEstabelecimento, 5);
	}
	
	public void adicionaItem(Item item) {
		this.itens[this.itensCadastrados] = item;
		this.itensCadastrados++;
	}
	
	public String listaCardapio() {
		String lista = "";
		for (int i = 0; i < itensCadastrados; i++) {
			if (i == this.itensCadastrados - 1) {
				//gera string sem a quebra de linha ao fim
				lista += i+1 + " - " + this.itens[i].toString();
			} else {
			lista += i+1 + " - " + this.itens[i].toString() + "\n";
			}
		}
		return lista;
	}
	
	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		int totalCalorias = 0;
		boolean achou;
		for (String nomeRefeicao : refeicao) {
			achou = false;
			for (int i = 0; i < this.itensCadastrados; i++) {
				if (nomeRefeicao.equals(this.itens[i].getNome())) {
					totalCalorias += this.itens[i].getCalorias();
					achou = true;
					break;
				}
			}
			if (!achou) {
				throw new IllegalArgumentException("Os itens informados devem estar no cardápio.");
			}
		}
		if (tamanhoRefeicao.equals("padrão")) {
			totalCalorias *= 1;
		} else if (tamanhoRefeicao.equals("grande")) {
			totalCalorias *= 2;
		} else if (tamanhoRefeicao.equals("mega")) {
			totalCalorias *= 3;
		}
		return totalCalorias;
	}
}
