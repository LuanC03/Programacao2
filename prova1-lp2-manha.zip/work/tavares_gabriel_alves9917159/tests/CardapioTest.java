import static org.junit.Assert.*;

import org.junit.Test;

public class CardapioTest {

	@Test(expected=IllegalArgumentException.class)
	public void adicionaItemNomeNull() {
		Cardapio cardapio = new Cardapio("10naProva");
		
		cardapio.adicionaItem(null, 13);	
		fail("Item foi adiciona com nome igual a null");
	}

	@Test(expected=IllegalArgumentException.class)
	public void criaCardapioNomeNull1() {
		Cardapio cardapio = new Cardapio(null);
		fail("Cardapio foi criado com nome igual a null");
	}
	

	@Test(expected=IllegalArgumentException.class)
	public void criaCardapioNomeNull2() {
		Cardapio cardapio = new Cardapio(null, 12);
		fail("Cardapio foi criado com nome igual a null");
	}
	

	@Test(expected=IllegalArgumentException.class)
	public void calculaRefeicaoListaInvalida() {
		String[] lista =  {"Churrasquinho10/10", "AçaiSemGostoDeTerra"};
		Cardapio cardapio = new Cardapio("10naProva", 10);
		
		cardapio.adicionaItem("Churrasquinho10/10", 50);
		
		int teste = cardapio.calcularRefeicao(lista, "grande");
		fail("Valor da refeição foi calculada mesmo com itens inválidos na lista");
	}
	
	@Test(expected=NullPointerException.class)
	public void calculaRefeicaoListaNula() {
		String[] lista =  null;
		Cardapio cardapio = new Cardapio("10naProva", 10);
		
		cardapio.adicionaItem("Churrasquinho10/10", 50);
		
		int teste = cardapio.calcularRefeicao(lista, "grande");
		fail("Valor da refeição foi calculada mesmo com lista nula");
	}
	
	@Test(expected=NullPointerException.class)
	public void calculaRefeicaoTamanhoNulo() {
		String[] lista =  null;
		Cardapio cardapio = new Cardapio("10naProva", 10);
		
		cardapio.adicionaItem("Churrasquinho10/10", 50);
		
		int teste = cardapio.calcularRefeicao(lista, null);
		fail("Valor da refeição foi calculada mesmo com tamanho nulo");
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void calculaRefeicaoTamanhoInvalido() {
		String[] lista =  {"Churrasquinho10/10", "AçaiSemGostoDeTerra"};
		Cardapio cardapio = new Cardapio("10nProva", 10);
		
		cardapio.adicionaItem("Churrasquinho10/10", 50);
		cardapio.adicionaItem("AçaiSemGostoDeTerra", 50);
		
		int teste = cardapio.calcularRefeicao(lista, "taoGrandeQuantoaMinhaNota");
		
		fail("Valor da refeição foi calculada mesmo com itens inválidos na lista");
	}
	
	@Test
	public void equalsNull() {
		Cardapio cardapio = new Cardapio("10nProva", 10);
		Cardapio outro = null;
		
		if (cardapio.equals(outro)) {
			fail("Cardapio nulo foi considerado igual a outro cardapio não nulo");
		}
	}
	
	@Test
	public void equalsCardapiosVazios() {
		Cardapio cardapio = new Cardapio("10nProva", 10);
		Cardapio outro = new Cardapio("10nProva", 10);
		
		if (!cardapio.equals(outro)) {
			fail("Cardapio vazios e de mesmo nome foram considerados diferentes");
		}
	}
	
	
	@Test
	public void equalsItensIguaisNomeDiferente() {
		Cardapio cardapio = new Cardapio("10nProva", 10);
		Cardapio outro = new Cardapio("11nProva", 10);
		
		cardapio.adicionaItem("Churrasquinho10/10", 14);
		outro.adicionaItem("Churrasquinho10/10", 14);
		
		if (cardapio.equals(outro)) {
			fail("Cardapio de estabelecimentos diferentes foram considerados iguais");
		}
	}
	
	


}
