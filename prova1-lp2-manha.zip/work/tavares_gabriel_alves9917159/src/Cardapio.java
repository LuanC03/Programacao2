
public class Cardapio {
	
	private Alimento[] alimentos;
	private String nomeEstabelecimento;
	
	public Cardapio(String nome){
		if (nome == null) {
			throw new IllegalArgumentException();
		}
		
		this.nomeEstabelecimento = nome;
		this.alimentos = new Alimento[5];
	}

	public Cardapio(String nome, int tamanho){
		if (nome == null) {
			throw new IllegalArgumentException();
		}

		this.nomeEstabelecimento = nome;
		this.alimentos = new Alimento[tamanho];
	}
	
	public void adicionaItem(String nome, int calorias) {
		if (nome == null) {
			throw new IllegalArgumentException();
		}
		Alimento item = new Alimento(nome, calorias);
		
		for (int i = 0; i < alimentos.length; i++) {
			if (alimentos[i] == null) {
				alimentos[i] = item;
				break;
			}
		}
	}
	
	public String listaCardapio(){
		String lista = " ";
		
		for (int i = 0; i < alimentos.length; i++) {
			if (alimentos[i] != null) {
				lista += String.format("%d - %s", i+1, alimentos[i].toString());
			}
			if (i != alimentos.length-1) {
				lista += "\n";
			}
		}
		
		return lista;
	}
	
	private int valorCaloricoItem(String nome) {
		for (int i = 0; i < alimentos.length; i++) {
			if (alimentos[i] != null && alimentos[i].getNome().equals(nome)) {
				return alimentos[i].getValorCalorico();
			}
		}
		
		throw new IllegalArgumentException();
	}
	
	public int calcularRefeicao(String[] refeicao, String tamanhoRefeicao) {
		int valorCaloricoTotal = 0;
		int valorItem;
		
		for (int i = 0; i < refeicao.length; i++) {
			valorItem = valorCaloricoItem(refeicao[i]);
			valorCaloricoTotal += valorItem;							
		}
		
		int multiplicador;
		if (tamanhoRefeicao.equals("padrão")) {
			multiplicador = 1;
		} else if (tamanhoRefeicao.equals("grande")) {
			multiplicador = 2;
		} else if (tamanhoRefeicao.equals("mega")) {
			multiplicador = 3;
		} else {
			throw new IllegalArgumentException();
		}
		
		valorCaloricoTotal *= multiplicador;
		return valorCaloricoTotal;	
	}
	
	public boolean equals(Object objeto) {
		if (objeto == null || objeto.getClass() != Cardapio.class) return false;
		
		Cardapio outro = (Cardapio) objeto;
		
		if (this.alimentos.length != outro.alimentos.length || !this.nomeEstabelecimento.equals(outro.nomeEstabelecimento)) {
			return false;
		}
		
		for (int i = 0; i < this.alimentos.length; i++) {
			if (this.alimentos[i] == null && outro.alimentos[i] != null) return false;
			if (this.alimentos[i] != null && outro.alimentos[i] == null) return false;
			if (this.alimentos[i] != null && outro.alimentos[i] != null && !this.alimentos[i].equals(outro.alimentos[i])) return false;
		}
		
		return true;		
	}
	
	public String toString() {
		return String.format("%s - %d itens", nomeEstabelecimento, alimentos.length);
	}
}
