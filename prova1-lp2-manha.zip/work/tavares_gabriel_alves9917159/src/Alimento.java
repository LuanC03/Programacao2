
public class Alimento {

	private String nome;
	private int valorCalorico;
	
	public Alimento(String nome, int calorias) {
		if (nome.equals(null)) {
			throw new IllegalArgumentException();
		}
		
		this.nome = nome;
		this.valorCalorico = calorias;
	}
	
	public String getNome() {
		return this.nome;
	}
	

	public int getValorCalorico() {
		return this.valorCalorico;
	}
	
	public String toString() {
		return String.format("%s - %d calorias/porção", nome, valorCalorico);
	}
	
	
	public boolean equals(Object objeto) {
		if (objeto == null || objeto.getClass() != Alimento.class) return false;
		
		Alimento outro = (Alimento) objeto;
		
		return this.nome.equals(outro.nome);
	}
}
