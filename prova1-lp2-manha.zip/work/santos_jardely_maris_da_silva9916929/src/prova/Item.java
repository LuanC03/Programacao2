package prova;

public class Item {
	
	private String nome;
	private int calorias;
	
	public Item(String nome, int calorias) {
		this.nome = nome;
		this.calorias = calorias;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public int getCalorias() {
		return this.calorias;
	}
	
	@Override 
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (!this.getClass().equals(obj.getClass())) {
			return false;
		}
		Item item = (Item) obj;
		if (this.nome.equals(item.nome)) {
			return true;
		}
		return false;
	}
	
	@Override 
	public int hashCode() {
		return this.nome.hashCode();
	}
	
	@Override 
	public String toString() {
		return this.nome + " - " + this.calorias +  " calorias/porcao";
	}
}
