package prova;

import java.util.Arrays;

public class Cardapio {
	private Item[] itens;
	private String nomeEstabelecimento;
	
	public Cardapio(String nomeEstabelecimento) {
		this.nomeEstabelecimento = nomeEstabelecimento;
		this.itens = new Item[5];
	}
	
	public Cardapio(String nomeEstabelecimento, int qtdItens) {
		this.nomeEstabelecimento = nomeEstabelecimento;
		this.itens = new Item[qtdItens];
	}
	
	public boolean adicionaItem(Item item) {
		for (int i=0; i<itens.length; i++) {
			if (itens[i] == null) {
				itens[i] = item;
				return true;
			}
		}
		return false;
	}
	
	public String listaCardapio() {
		String aux = "";
		int contAux = 1;
		for (int i=0; i<itens.length; i++) {
			if (itens[i] != null) {
				aux += contAux + " - " + itens[i].toString() + "\n";
				contAux ++;
			}
		}
		return aux;
	}
	
	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		int calorias = 0;
		for (int i=0; i<refeicao.length; i++) {
			for (int e=0; e<itens.length; e++) {
				if (!refeicao[i].equals(null) && !itens[e].equals(null) && refeicao[i].equals(itens[e].getNome())){
					if (tamanhoRefeicao.equals("padrao")) {
						calorias += itens[e].getCalorias();
					} else if (tamanhoRefeicao.equals("grande")) {
						calorias += (itens[e].getCalorias() * 2);
					} else {
						calorias += (itens[e].getCalorias() * 3);
					}
				} else {
					throw new IllegalArgumentException();
				}
			}
		}
		return calorias;
	}
	
	@Override
	public String toString() {
		return "Cardapio [Itens = " + Arrays.toString(itens) + ", Nome do Estabelecimento = " + nomeEstabelecimento + "]";
	}

}
