package testes;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import prova.Cardapio;
import prova.Item;

public class TestCardapio {
	
	private Cardapio cardapio;
	private Item item;
	
	@Before
	public void setUp() {
		cardapio = new Cardapio("Luna");
		item = new Item("feijao", 10);
	}
	
	@Test
	public void testAdicionaItemMenuPadrao() { 
		assertTrue(cardapio.adicionaItem(item));
	}
	
	@Test
	public void testListaCardapio() {
		cardapio.adicionaItem(item);
		assertEquals(cardapio.listaCardapio(), "1 - feijao - 10 calorias/porcao\n");
	}
	
	@Test
	public void testCalculaCaloriaComItensValidosPadrao() {
		cardapio.adicionaItem(item);
		String[] refeicao = new String[1];
		refeicao[0] = "feijao";
		assertEquals(cardapio.calcularCaloriasRefeicao(refeicao, "padrao"), 10);
	}
	
	@Test
	public void testCalculaCaloriaComItensValidosGrande() {
		cardapio.adicionaItem(item);
		String[] refeicao = new String[1];
		refeicao[0] = "feijao";
		assertEquals(cardapio.calcularCaloriasRefeicao(refeicao, "grande"), 20);
	}
	
	@Test
	public void testCalculaCaloriaComItensValidosMega() {
		cardapio.adicionaItem(item);
		String[] refeicao = new String[1];
		refeicao[0] = "feijao";
		assertEquals(cardapio.calcularCaloriasRefeicao(refeicao, "mega"), 30);
	}
	
	@Test
	public void testCalculaCaloriaComItensInvalidos() {
		try{
			cardapio.adicionaItem(item);
			String[] refeicao = new String[1];
			refeicao[0] = "arroz";
			cardapio.calcularCaloriasRefeicao(refeicao, "padrao");
		} catch (IllegalArgumentException iae) {
		}
	}

}
