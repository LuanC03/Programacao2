package model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CardapioVirtualTest {
	
	CardapioVirtual cardapioBase;
	
	@Before
	public void inicia() {
		Item item1 = new Item("arroz",200);
		Item item2 = new Item("feijão",250);
	
		cardapioBase = new CardapioVirtual("Ferrão Lanches" , 3 );
		
		cardapioBase.adicionaItem(item1);
		cardapioBase.adicionaItem(item2);
		
	}
	@Test
	public void testListaCardapio() {
		String lista = "1 - arroz - 200 calorias/porção\n2 - feijão - 250 calorias/porção";
		assertEquals(lista,cardapioBase.listaCardapio());
	}
	
	@Test
	public void testCalcularCaloriasRefeição() {
		String caloriasEsperadas = "900 calorias";
		String[] refeicao = new String[2];
		refeicao[0] = "arroz";
		refeicao[1] = "feijão";
		assertEquals(caloriasEsperadas , cardapioBase.calcularCaloriasRefeicao(refeicao, "grande"));
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testCalcularCaloriasRefeiçãoArgumentoInvalido() {
		String caloriasEsperadas = "900 calorias";
		String[] refeicao = new String[2];
		refeicao[0] = "batata";
		refeicao[1] = "feijão";
		cardapioBase.calcularCaloriasRefeicao(refeicao, "grande");
	}
	
	@Test
	public void testAdicionaItem() {
		CardapioVirtual cardapio = new CardapioVirtual("Lanches" , 3 );
		Item item = new Item("arroz",200);
		Item item2 = new Item("feijão",250);
		cardapio.adicionaItem(item);
		cardapio.adicionaItem(item2);

		assertEquals(cardapioBase.listaCardapio(),cardapio.listaCardapio());
	}

}
