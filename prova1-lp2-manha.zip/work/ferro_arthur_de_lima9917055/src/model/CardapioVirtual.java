package model;

public class CardapioVirtual {

	private String nomeEstabelecimento;
	private Item[] itens;

	public CardapioVirtual(String nomeEstabelecimento) {
		this.itens = new Item[5];
		this.nomeEstabelecimento = nomeEstabelecimento;
	}

	public CardapioVirtual(String nomeEstabelecimento, int qtdItens) {
		this.nomeEstabelecimento = nomeEstabelecimento;
		this.itens = new Item[qtdItens];
	}

	public void adicionaItem(Item item) {
		for (int x = 0; x < this.itens.length; x++) {
			if (this.itens[x] == null) {
				this.itens[x] = item;
				break;
			}
		}
	}

	public String listaCardapio() {
		String lista = "";
		for (int x = 0; x < this.itens.length; x++) {
			if (this.itens[x] != null) {
				if(x==0) {
					lista += (x + 1) + " - " + itens[x].toString();
				}else {
				lista += "\n"+(x + 1) + " - " + itens[x].toString();
				}
			}else {
				break;
			}
		}
		return lista;
	}

	public String calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {

		Boolean valida = false;	
		int somaCalorias = 0;
		for (int x = 0; x < this.itens.length; x++) {
			if(itens[x]!=null) {
				valida = true;
				
				for(String comida : refeicao) {
					if (itens[x].getNome().equals(comida)){
						somaCalorias+= itens[x].getCalorias();
						valida = false;
					}
				}
				
				if(valida) {
					throw new IllegalArgumentException("Array com itens diferentes do esperado");
				}
			}
			
		}
		
		int tamanho = 1; 
		
		if(tamanhoRefeicao.equals("grande")) {
			tamanho = 2;
		}else if(tamanhoRefeicao.equals("mega")) {
			tamanho = 3;
		}
		return somaCalorias * tamanho  + " calorias";
	}

}
