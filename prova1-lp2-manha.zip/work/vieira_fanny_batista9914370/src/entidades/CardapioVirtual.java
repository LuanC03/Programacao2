package entidades;

import java.util.Arrays;

public class CardapioVirtual {
	
	private String nomeEstabelecimento;
	private Item[] items;
	private int qtdeItemsCadastrados;
	public static final String ITEM_DESCONHECIDO = "O item fornecido não foi cadastrado";
	
	public CardapioVirtual(String nomeEstabelecimento) {
		this(nomeEstabelecimento, 5);
	}
	
	public CardapioVirtual(String nomeEstabelecimento, int qtdeItens) {
		this.nomeEstabelecimento = nomeEstabelecimento;
		this.items = new Item[qtdeItens];
		this.qtdeItemsCadastrados = 0;
	}
	
	
	private boolean posicaoValida() {
		return qtdeItemsCadastrados < items.length;
	}
	
	
	public boolean adicionaItem(Item item) {
		if(posicaoValida()) {
			this.items[qtdeItemsCadastrados++] = item;
			return true;
		}
		return false;
	}
	
	public String listaCardapio() {
		return this.toString();
	}
	
	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		int total = 0;
		for(String nome: refeicao) {
			Item item = this.getItemPeloNome(nome);
			if(item == null) {
				throw new IllegalArgumentException(ITEM_DESCONHECIDO);
			}
			total += item.getCalorias(tamanhoRefeicao);
		}
		return total;
	}
	
	//A especificação não pede esse método, logo só será usado nessa classe
	private Item getItemPeloNome(String nome) {
		for(int i = 0;i < qtdeItemsCadastrados; i++) {
			if(items[i].getNome().equals(nome)) {
				return items[i];
			}
		}
		return null;
	}
	
	public String getNomeEstabelecimento() {
		return nomeEstabelecimento;
	}

	public Item[] getItems() {
		return items;
	}
	
	public void setItems(Item[] items) {
		this.items = items;
	}

	public int getQtdeItemsCadastrados() {
		return qtdeItemsCadastrados;
	}

	public String toString() {
		String result = "";
		for(int i = 0;i < qtdeItemsCadastrados; i++) {
			result += (i+1)+" - "+ items[i].toString()+"\n";
		}
		return result;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(items);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CardapioVirtual other = (CardapioVirtual) obj;
		if (!Arrays.equals(items, other.items))
			return false;
		return true;
	}

}
