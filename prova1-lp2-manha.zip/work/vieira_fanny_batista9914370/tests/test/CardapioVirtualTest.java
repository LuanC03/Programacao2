package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import entidades.CardapioVirtual;
import entidades.Item;

public class CardapioVirtualTest {

	String nomeEstabelecimento;
	Item item1;
	Item item2;
	Item item3;
	Item item4;
	Item item5;
	Item item6;
	Item item7;
	Item item8;
	
	@Before
	public void setUp() throws Exception {
		nomeEstabelecimento = "Kioske de Joabe";
		item1 = new Item("arroz branco", 100);
		item2 = new Item("arroz a grega", 200);
		item3 = new Item("macarrão", 200);
		item4 = new Item("feijoada", 150);
		item5 = new Item("feijão verde", 90);
		item6 = new Item("frango assado", 90);
		item7 = new Item("bife", 100);
		item8 = new Item("vinagrete", 0);
	}

	
	//Testa se quando é passado apenas o nome, o tamanho será o padrão
	@Test
	public void testCardapioVirtualString() {
		CardapioVirtual cardapioVirtual = new CardapioVirtual(nomeEstabelecimento);
		assertTrue((cardapioVirtual.getItems().length) == 5);
		
	}

	//Testa se quando é passado o nome e o tamnho, o tamnho é igual ao fornecido
	@Test
	public void testCardapioVirtualStringInt() {
		CardapioVirtual cardapioVirtual = new CardapioVirtual(nomeEstabelecimento, 10);
		assertTrue((cardapioVirtual.getItems().length) == 10);
	}

	/*Testa se quando a quantidade items cadastrados é menor que a especificada(nesse caso
	 * a padrão 5)
	 * O cardapio adiciona
	 * */
	@Test
	public void testAdicionaItemPosValida() {
		CardapioVirtual cardapioVirtual = new CardapioVirtual(nomeEstabelecimento);
		assertTrue(cardapioVirtual.adicionaItem(item1));
	}

	/*Testa se quando a quantidade items cadastrados já é igual a qtde especificada(
	 * dessa forma não será possivel cadastrar mais items)
	 * O cardapio não adiciona
	 * */
	@Test
	public void testAdicionaItemPosInValida() {
		CardapioVirtual cardapioVirtual = new CardapioVirtual(nomeEstabelecimento, 1);
		cardapioVirtual.adicionaItem(item1);
		assertFalse(cardapioVirtual.adicionaItem(item2));
	}

	
	@Test
	public void testListaCardapio() {
		Item[] items = {item1, item2, item3, item4, item5, item6, item7, item8};
		CardapioVirtual cardapioVirtual = new CardapioVirtual(nomeEstabelecimento);
		cardapioVirtual.setItems(items);
		assertEquals(cardapioVirtual.toString(), cardapioVirtual.listaCardapio());
	}

	
	@Test
	public void testCalcularCaloriasRefeicao() {
		String[] refeicao = {"arroz branco", "feijoada", "vinagrete"};
		CardapioVirtual cardapioVirtual = new CardapioVirtual(nomeEstabelecimento);
		cardapioVirtual.adicionaItem(item1);
		cardapioVirtual.adicionaItem(item8);
		cardapioVirtual.adicionaItem(item4);
		assertEquals(500, cardapioVirtual.calcularCaloriasRefeicao(refeicao, Item.PORCAO_GRANDE));
	}
	
	
	@Test
	public void testCalcularCaloriasRefeicaoInvalida() {
		String[] refeicao = {"arroz branco", "feijão", "vinagrete"};
		CardapioVirtual cardapioVirtual = new CardapioVirtual(nomeEstabelecimento);
		cardapioVirtual.adicionaItem(item1);
		cardapioVirtual.adicionaItem(item8);
		cardapioVirtual.adicionaItem(item4);
		try {
			cardapioVirtual.calcularCaloriasRefeicao(refeicao, Item.PORCAO_GRANDE);
			fail();
		}catch (Exception e) {
			assertEquals(CardapioVirtual.ITEM_DESCONHECIDO, e.getMessage());
		}
	}
	
	@Test
	public void testCardapiosIguais() {
		Item[] items = {item1, item2, item3, item4, item5, item6, item7, item8};
		CardapioVirtual cardapioVirtual1 = new CardapioVirtual(nomeEstabelecimento);
		cardapioVirtual1.setItems(items);
		
		CardapioVirtual cardapioVirtual2 = new CardapioVirtual(nomeEstabelecimento);
		cardapioVirtual2.setItems(items);
		
		assertTrue(cardapioVirtual1.equals(cardapioVirtual2));
	}
	
	
	@Test
	public void testCardapiosDiferentes() {
		Item[] items1 = {item1, item2, item3, item4};
		CardapioVirtual cardapioVirtual1 = new CardapioVirtual(nomeEstabelecimento);
		cardapioVirtual1.setItems(items1);
		
		Item[] items2 = {item5, item6, item7, item8};
		CardapioVirtual cardapioVirtual2 = new CardapioVirtual(nomeEstabelecimento);
		cardapioVirtual2.setItems(items2);
		
		assertFalse(cardapioVirtual1.equals(cardapioVirtual2));
	}
	
	


	

}
