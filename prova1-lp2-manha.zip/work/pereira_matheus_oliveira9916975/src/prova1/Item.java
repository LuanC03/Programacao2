package prova1;

public class Item {
	private String nome;
	private int caloriasPorPorcao;
	
	public Item(String nome, int caloriasPorPorcao) {
		this.nome = nome;
		this.caloriasPorPorcao = caloriasPorPorcao;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public int getCalorias() {
		return this.caloriasPorPorcao;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj == null) {
			return false;
		}
		if(obj.getClass() != this.getClass()) {
			return false;
		}
		
		Item it = (Item)obj;
		return this.nome.equals(it.nome);
	}
	
	@Override
	public String toString() {
		String representacao;
		representacao = this.nome + " - " + this.caloriasPorPorcao + " calorias/porção";
		return representacao;
	}
}
