package prova1;
import java.util.ArrayList;

public class Cardapio {
	private String nomeEstabelecimento;
	private ArrayList<Item> itens = new ArrayList<Item>();
	private int quantidadeItens = 0;
	
	public Cardapio(String nome) {
		this.nomeEstabelecimento = nome;
		defineTamanhoCardapio(5);
	}
	
	public Cardapio(String nome, int tamanhoCardapio) {
		this.nomeEstabelecimento = nome;
		defineTamanhoCardapio(tamanhoCardapio);
	}
	
	public void adicionaItem(Item item) {
		if(this.quantidadeItens < this.itens.size()) {
			this.itens.set(quantidadeItens, item);
			this.quantidadeItens += 1;
		}
		else {
			throw new IndexOutOfBoundsException("Capacidade máxima do cardápio atingida. Adição de itens não é possível.");
		}
	}
	
	private void defineTamanhoCardapio(int tamanho) {
		while(this.itens.size() < tamanho) {
			this.itens.add(null);
		}
	}
	
	public void aumentaTamanhoCardapio(int novoTamanho) {
		this.defineTamanhoCardapio(novoTamanho);
	}
	
	public String getNomeEstabelecimento() {
		return this.nomeEstabelecimento;
	}
	
	public boolean posicaoOcupada(int pos) {
		return (this.itens.get(pos) != null);
	}
	
	public void setNomeEstabelecimento(String novoNome) {
		this.nomeEstabelecimento = novoNome;
	}
	
	public void atualizarCardapio(int pos, Item it) {
		if(pos >= 0 && pos <= this.itens.size()) {
			this.itens.set(pos, it);
		}
		else {
			throw new IndexOutOfBoundsException("Posição de alteração inválida.");
		}
	}
	
	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		int caloriasTotais = 0, tamanho = 0;
		boolean alimentoEncontrado;
		
		for(int i=0; i < refeicao.length; i++) {
			
			alimentoEncontrado = false;
			
			for(int j=0; j < this.itens.size(); j++) {
				if( this.posicaoOcupada(j) ) {
					if( this.itens.get(j).getNome().equals(refeicao[i]) ) {
						caloriasTotais += this.itens.get(j).getCalorias();
						alimentoEncontrado = true;
					}
				}
			}
			
			if(!alimentoEncontrado) {
				throw new IllegalArgumentException("O nome de algum alimento inserido não está presente no cardápio");
			}
		}
		
		if( tamanhoRefeicao.equals("padrão") ) {
			tamanho = 1;
		}
		else if( tamanhoRefeicao.equals("grande") ) {
			tamanho = 2;
		}
		else if( tamanhoRefeicao.equals("mega") ) {
			tamanho = 3;
		}
		
		caloriasTotais *= tamanho;
		return caloriasTotais;
	}
	
	public String listaCardapio() {
		String listagem = "";
		
		for(int i=0; i < this.itens.size(); i++) {
			if( this.posicaoOcupada(i) ) {
				listagem += (i+1) + " - " + this.itens.get(i).toString() + "\n";
			}
		}
		
		return listagem;
	}
}
