package prova1;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class CardapioTest {
	private Cardapio cardapioSimples;

	@Before
	public void inicializar() {
		cardapioSimples = new Cardapio("Cantina do seu Olavo");
	}
	
	@Test
	public void testAdicionaItem() {
		Item it = new Item("Arroz", 49);
		cardapioSimples.adicionaItem(it);
		
		assertTrue( cardapioSimples.posicaoOcupada(0) );
		assertEquals( "1 - Arroz - 49 calorias/porção\n", cardapioSimples.listaCardapio() );
	}
	
	@Test
	public void testListaCardapio() {
		Item it = new Item("Arroz", 49);
		cardapioSimples.adicionaItem(it);
		assertEquals( "1 - Arroz - 49 calorias/porção\n", cardapioSimples.listaCardapio() );
		
		Item it2 = new Item("Cuscuz", 233);
		cardapioSimples.adicionaItem(it2);
		assertEquals( "1 - Arroz - 49 calorias/porção\n2 - Cuscuz - 233 calorias/porção\n", cardapioSimples.listaCardapio() );
	}
	
	@Test (expected=IllegalArgumentException.class) 
	public void testRefeicaoInvalida() {
		Item it = new Item("Pão", 457);
		
		String[] refeicao = {"Arroz"};
		String tamanhoRefeicao = "padrão";
		
		cardapioSimples.adicionaItem(it);
		cardapioSimples.calcularCaloriasRefeicao(refeicao, tamanhoRefeicao);
	}
	
	@Test
	public void testCalculaCaloriasRefeicao() {
		Item it = new Item("Arroz", 49);
		Item it2 = new Item("Cuscuz", 233);
		Item it3 = new Item("Carne", 447);
		Item it4 = new Item("Macarrão", 1000);
		
		cardapioSimples.adicionaItem(it);
		cardapioSimples.adicionaItem(it2);
		cardapioSimples.adicionaItem(it3);
		
		String[] refeicao = {"Arroz", "Cuscuz", "Carne"};
		String tamanhoRefeicao = "grande";
		
		int caloriasTotais = cardapioSimples.calcularCaloriasRefeicao(refeicao, tamanhoRefeicao);
		assertEquals(caloriasTotais, 1458);
		
		cardapioSimples.adicionaItem(it4);
		
		String[] novaRefeicao = {"Arroz", "Cuscuz", "Carne", "Macarrão"};
		tamanhoRefeicao = "mega";
		
		caloriasTotais = cardapioSimples.calcularCaloriasRefeicao(novaRefeicao, tamanhoRefeicao);
		assertEquals(caloriasTotais, 5187);
	}
	
	@Test
	public void testAtualizarCardapio() {
		Cardapio cardapio = new Cardapio("Cantina do Olavão", 2);
		
		Item it = new Item("Arroz", 49);
		Item it2 = new Item("Cuscuz", 233);
		Item it3 = new Item("Carne", 447);
		
		cardapio.adicionaItem(it);
		cardapio.adicionaItem(it2);
		assertEquals( "1 - Arroz - 49 calorias/porção\n2 - Cuscuz - 233 calorias/porção\n", cardapio.listaCardapio() );
		
		cardapio.atualizarCardapio(1, it3);
		assertEquals( "1 - Arroz - 49 calorias/porção\n2 - Carne - 447 calorias/porção\n", cardapio.listaCardapio() );
	}
	
	@Test
	public void testSetNomeEstabelecimento() {
		assertEquals(cardapioSimples.getNomeEstabelecimento(), "Cantina do seu Olavo");
		
		cardapioSimples.setNomeEstabelecimento("Cantina do Olavão");
		assertEquals(cardapioSimples.getNomeEstabelecimento(), "Cantina do Olavão");
	}
	
	@Test (expected=IndexOutOfBoundsException.class) 
	public void testAtualizaCardapioOutOfBounds() {
		Cardapio cardapio = new Cardapio("Cantina do Olavão", 1);
		
		Item it = new Item("Arroz", 49);
		Item it2 = new Item("Cuscuz", 233);
		
		cardapio.adicionaItem(it);
		cardapio.atualizarCardapio(43, it2);
	}
	
	@Test
	public void testAumentaTamanhoCardapio() {
		Cardapio cardapio = new Cardapio("Cantina do Olavão", 1);
		
		Item it = new Item("Arroz", 49);
		Item it2 = new Item("Cuscuz", 233);
		
		cardapio.adicionaItem(it);
		cardapio.aumentaTamanhoCardapio(2);
		assertEquals( "1 - Arroz - 49 calorias/porção\n", cardapio.listaCardapio() );
		
		cardapio.adicionaItem(it2);
		assertEquals( "1 - Arroz - 49 calorias/porção\n2 - Cuscuz - 233 calorias/porção\n", cardapio.listaCardapio() );
	}
}
