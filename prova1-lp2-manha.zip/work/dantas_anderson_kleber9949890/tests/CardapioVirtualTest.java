import static org.junit.Assert.*;

import org.junit.Test;

public class CardapioVirtualTest {

	@Test
	public void testcalcularCaloriasRefeicaoOk() {
		CardapioVirtual cardapio = new CardapioVirtual("Seu Olavo", 6);
		
		cardapio.adicionaItem(new Item("Arroz", 120));
		cardapio.adicionaItem(new Item("Feijao", 150));
		cardapio.adicionaItem(new Item("Batata", 110));
		cardapio.adicionaItem(new Item("Tomate", 65));
		cardapio.adicionaItem(new Item("Alface", 0));
		cardapio.adicionaItem(new Item("Farofa de manteiga", 260));
		
		String[] refeicao = {"Arroz", "Feijao", "Batata", "Tomate", "Alface"}; 
		
		assertEquals(cardapio.calcularCaloriasRefeicao(refeicao), 120 + 150 + 110 + 65 + 0);
		assertEquals(cardapio.calcularCaloriasRefeicao(refeicao, "grande"), 2 * (120 + 150 + 110 + 65 + 0));
		assertEquals(cardapio.calcularCaloriasRefeicao(refeicao, "mega"), 3 * (120 + 150 + 110 + 65 + 0));
		
		refeicao[0] = "Farofa de manteiga";
		
		assertEquals(cardapio.calcularCaloriasRefeicao(refeicao, "mega"), 3 * (260 + 150 + 110 + 65 + 0));
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testcalcularCaloriasRefeicaoIllegalTamanho() {
		
		CardapioVirtual cardapio = new CardapioVirtual("Seu Olavo", 4);
		
		cardapio.adicionaItem(new Item("Arroz", 120));
		cardapio.adicionaItem(new Item("Feijao", 150));
		
		String[] refeicao = {"Arroz", "Feijao"};
		
		cardapio.calcularCaloriasRefeicao(refeicao, "jumbo");
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testcalcularCaloriasRefeicaoIllegal() {
		
		CardapioVirtual cardapio = new CardapioVirtual("Seu Olavo", 4);
		
		cardapio.adicionaItem(new Item("Arroz", 120));
		cardapio.adicionaItem(new Item("Feijao", 150));
		
		String[] refeicao = {"Arroz", "Suco de batata"};
		
		cardapio.calcularCaloriasRefeicao(refeicao);
	}

}
