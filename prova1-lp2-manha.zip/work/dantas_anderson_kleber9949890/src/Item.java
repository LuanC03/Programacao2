
public class Item {
	
	private String nome;
	private int calorias;
	
	public Item(String nome, int calorias) {
		this.nome = nome;
		this.calorias = calorias;
	}
	
	public String getNome() {
		return nome;
	}
	
	public int getCalorias() {
		return calorias;
	}

	@Override
	public boolean equals(Object obj) {
		
		if(obj == null)
			return false;
		
		if(obj.getClass() == String.class) {
			return this.getNome() == obj;
		}
		
		if (this.getClass() != obj.getClass())
			return false;
		
		Item other = (Item) obj;
		
		return this.getNome() == other.getNome();
	}

	@Override
	public String toString() {
		return nome + " - " + calorias + " por porcao";
	}
}
