
public class CardapioVirtual {
	
	private Item[] itens;
	private String nome;
	private int nextIndex;
	
	public CardapioVirtual(String nome, int tamanho) {
		
		this.itens = new Item[tamanho];
		this.nome = nome;
		this.nextIndex = 0;
	}
	
	/**
	 * Construtor com cardapio de tamanho 5
	 * @param nome nome do cardapio
	 */
	public CardapioVirtual(String nome) {
		
		this(nome, 5);
	}
	
	/**
	 * Adiciona um objeto do tipo item ao cardapio
	 * @param item objeto de item
	 */
	public void adicionaItem(Item item) {
		if (this.nextIndex >= this.itens.length) {
			
			
			throw new IndexOutOfBoundsException();
		}
		
		this.itens[this.nextIndex++] = item;
	}
	
	/**
	 * 
	 * @return Uma String com informações sobre os itens no cardapio (nome e calorias)
	 */
	public String listaCardapio() {
		String msg = "";
		
		for(int i = 0; i < this.nextIndex; i++) {
			msg += this.itens[i].toString() + "\n";
		}
		
		return msg;
	}
	
	/**
	 * Método padrão para se calcular as calorias de uma refeição
	 * @param refeicao lista de alimentos na refeição
	 * @return inteiro referente ao numero de calorias na refeição
	 */
	public int calcularCaloriasRefeicao(String[] refeicao) {
		return this.calcularCaloriasRefeicao(refeicao, "padrao");
	}
	
	/**
	 * 
	 * @param refeicao lista de alimentos na refeição
	 * @param tamanhoRefeicao String referente ao tamanho da porção na refeição ("padrao", "grande" e "mega")
	 * @return inteiro referente ao numero de calorias na refeição
	 */
	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		if(tamanhoRefeicao != "padrao" && tamanhoRefeicao != "grande" && tamanhoRefeicao != "mega") {
			throw new IllegalArgumentException(tamanhoRefeicao + " nao e um argumento para um tamaho válido");
		}
		
		for(String i : refeicao) {
			if(!cardapioHasItem(i)) {
				throw new IllegalArgumentException(i + " nao esta incluida no nosso cardapio");
			}
		}
		
		int tam;
		
		if (tamanhoRefeicao == "padrao") {
			tam = 1;
		} else if( tamanhoRefeicao == "grande") {
			
			tam = 2;
		} else {
			
			tam = 3;
		}
		
		int caloriasTotais = 0;
		
		for(String i : refeicao) {
			caloriasTotais += getCaloriasDeItem(i) * tam;
		}
		
		return caloriasTotais;
	}
	
	private boolean cardapioHasItem(String itemNome) {
		for(int i = 0; i < this.nextIndex; i++) {
			if(this.itens[i].getNome() == itemNome){
				return true;
			}
		}
		
		return false;
	}
	
	private int getCaloriasDeItem(String nome) {
		
		for(int i = 0; i < this.nextIndex; i++) {
			if(this.itens[i].getNome() == nome){
				return this.itens[i].getCalorias();
			}
		}
		
		return 0;
	}

}
