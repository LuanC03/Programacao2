package cardapiovirtual;

public class CardapioVirtual {
    private String nome;
    private ItemCardapio[] itens;

    public CardapioVirtual(String nome, int numeroItens) {
        if (nome == null || nome.isEmpty())
            throw new IllegalArgumentException("Nome inválido");
        
        if (numeroItens < 1)
            throw new IllegalArgumentException("Número de itens inválido");
        
        this.nome = nome;
        itens = new ItemCardapio[numeroItens];
    }

    public CardapioVirtual(String nome) {
        this(nome, 5);
    }
    
    public boolean adicionaItem(ItemCardapio item) {
        if (item != null) {
            for (int i = 0; i < itens.length; i++) {
                if (itens[i] == null) {
                    itens[i] = item;
                    return true;
                }
            }
        }
        return false;
    }
    
    public String listaCardapio() {
        String opcoesCardapio = "";
        
        for (ItemCardapio it: itens) {
            if (it != null) {
                opcoesCardapio += it.toString() + "\n";
            }
        }
        
        return opcoesCardapio;
    }
    
    public int calcularCaloriasRefeicao(String[] refeicao, 
            String tamanhoRefeicao) {
        int caloriasTotal = 0;
        
        if (refeicao == null)
            throw new IllegalArgumentException("Refeição inválida.");
        
        for (int i = 0; i < refeicao.length; i++) {
            ItemCardapio ic = procuraItem(refeicao[i]);
            if (ic == null) {
                throw new IllegalArgumentException("Item(s) desconhecido(s)"
                        + " do cardápio.");
            } else {
                caloriasTotal += ic.getCaloriasPorPorcao();
            }
        }
        
        int qtd = calculaCalorias(tamanhoRefeicao);
        if (qtd == -1)
            throw new IllegalArgumentException("Tamanho de refeição inválido.");
        
        return qtd * caloriasTotal;
    }
    
    private int calculaCalorias(String tamanho) {
        switch (tamanho){
            case "pequeno": return 1;
            case "grande": return 2;
            case "mega": return 3;
            default: return -1;
        }
    }
    
    private ItemCardapio procuraItem(String refeicao) {
        for (ItemCardapio item : itens) {
            if (item != null) {
                if (item.getNome().equals(refeicao)) return item;
            }
        }
        
        return null;
    }
}
