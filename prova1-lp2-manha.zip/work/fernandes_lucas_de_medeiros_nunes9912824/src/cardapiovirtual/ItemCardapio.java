package cardapiovirtual;

import java.util.Objects;

public class ItemCardapio {
    private final String nome;
    private final int caloriasPorPorcao;

    public ItemCardapio(String nome, int caloriasPorPorcao) {
        if (nome == null || nome.isEmpty()) throw new 
            IllegalArgumentException("Nome inválido");
        if (caloriasPorPorcao < 0) throw new 
            IllegalArgumentException("Número de calorias inválido");
        
        this.nome = nome;
        this.caloriasPorPorcao = caloriasPorPorcao;
    }

    public String getNome() {
        return nome;
    }

    public int getCaloriasPorPorcao() {
        return caloriasPorPorcao;
    }

    @Override
    public String toString() {
        return this.nome + " - " + this.caloriasPorPorcao;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) return false;
        if (obj == this) return true;
        if (!(obj instanceof ItemCardapio)) return false;
        
        ItemCardapio itemComparado = (ItemCardapio) obj;
        
        return this.nome.equals(itemComparado.nome);
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 83 * hash + Objects.hashCode(this.nome);
        return hash;
    }
    
    
}
