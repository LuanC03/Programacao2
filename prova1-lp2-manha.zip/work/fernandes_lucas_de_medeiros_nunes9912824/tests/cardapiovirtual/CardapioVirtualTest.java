package cardapiovirtual;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

public class CardapioVirtualTest {
    
    private CardapioVirtual cardapio;
    
    public CardapioVirtualTest() {
    }
    
    @Before
    public void setUpClass() {
        cardapio = new CardapioVirtual("Churrascaria do Zé Bonitinho");
    }
    
    @Test
    public void testAdicionaItemNulo() {
        System.out.println("adicionaItemNulo");
        assertEquals(false, cardapio.adicionaItem(null));
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void adicionaItemComNomeVazio() {
        System.out.println("adicionaItemComNomeVazio");
        assertEquals(false, cardapio.adicionaItem(new ItemCardapio("", 200)));
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void adicionaItemComNomeNulo() {
        System.out.println("adicionaItemComNomeNulo");
        assertEquals(false, cardapio.adicionaItem(new ItemCardapio(null, 200)));
    }

    @Test
    public void testListaCardapioVazio() {
        System.out.println("listaCardapioVazio");
        assertEquals("", cardapio.listaCardapio());
    }
    
    @Test
    public void testListaCardapio() {
        System.out.println("listaCardapio");
        cardapio.adicionaItem(new ItemCardapio(("Feijoada"), 150));
        cardapio.adicionaItem(new ItemCardapio(("Picanha"), 200));
        cardapio.adicionaItem(new ItemCardapio(("Bife"), 100));
        assertEquals("Feijoada - 150\nPicanha - 200\nBife - 100\n", 
                cardapio.listaCardapio());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCalcularCaloriasRefeicaoNula() {
        System.out.println("calcularCaloriasRefeicaoNula");
        String[] refeicao = null;
        String tamanhoRefeicao = "grande";
        cardapio.calcularCaloriasRefeicao(refeicao, tamanhoRefeicao);
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void testCalcularCaloriasRefeicaoComNomeInvalido() {
        System.out.println("calcularCaloriasRefeicaoComNomeInvalido");
        String[] refeicao = {"Refeição que não tem", "Outra refeição"};
        String tamanhoRefeicao = "grande";
        cardapio.calcularCaloriasRefeicao(refeicao, tamanhoRefeicao);
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void testCalcularCaloriasRefeicaoTamanhoInvalido() {
        System.out.println("calcularCaloriasRefeicaoTamanhoInvalido");
        cardapio.adicionaItem(new ItemCardapio(("Feijoada"), 150));
        String[] refeicao = {"Feijoada"};
        String tamanhoRefeicao = "blabla";
        cardapio.calcularCaloriasRefeicao(refeicao, tamanhoRefeicao);
    }
    
    @Test
    public void testCalcularCaloriasRefeicaoMega() {
        System.out.println("calcularCaloriasRefeicaoMega");
        cardapio.adicionaItem(new ItemCardapio(("Feijoada"), 150));
        cardapio.adicionaItem(new ItemCardapio(("Arroz Branco"), 150));
        String[] refeicao = {"Feijoada", "Arroz Branco"};
        String tamanhoRefeicao = "mega";
        assertEquals(900, cardapio.calcularCaloriasRefeicao(refeicao, tamanhoRefeicao));
    }
    
    @Test
    public void testCalcularCaloriasRefeicaoGrande() {
        System.out.println("calcularCaloriasRefeicaoGrande");
        cardapio.adicionaItem(new ItemCardapio(("Feijoada"), 150));
        cardapio.adicionaItem(new ItemCardapio(("Arroz Branco"), 150));
        String[] refeicao = {"Feijoada", "Arroz Branco"};
        String tamanhoRefeicao = "grande";
        assertEquals(600, cardapio.calcularCaloriasRefeicao(refeicao, tamanhoRefeicao));
    }
    
    @Test
    public void testCalcularCaloriasRefeicaoNormal() {
        System.out.println("calcularCaloriasRefeicaoGrande");
        cardapio.adicionaItem(new ItemCardapio(("Feijoada"), 150));
        cardapio.adicionaItem(new ItemCardapio(("Arroz Branco"), 150));
        String[] refeicao = {"Feijoada", "Arroz Branco"};
        String tamanhoRefeicao = "pequeno";
        assertEquals(300, cardapio.calcularCaloriasRefeicao(refeicao, tamanhoRefeicao));
    }
}
