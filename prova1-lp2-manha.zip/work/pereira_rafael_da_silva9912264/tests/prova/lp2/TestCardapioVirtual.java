package prova.lp2;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TestCardapioVirtual {

	private CardapioVirtual cv;

	@Before
	@Test
	public void testConstrutor2() {
		cv = new CardapioVirtual("Cantina do ze", 2);

	}

	@Test
	public void testConstrutor1() {
		cv = new CardapioVirtual("Cantina do ze");
	}

	@Test
	public void testAdicionaItem() {
		Item arroz = new Item("arroz", 100);
		cv.adicionaItem(arroz);
		assertEquals("case 01:", cv.toString(), "Cantina do ze [nome: arroz, calorias = 100, null]");

	}

	@Test
	public void testListarCardapio() {
		Item arroz = new Item("arroz", 100);
		Item beef = new Item("bife", 100);
		cv.adicionaItem(arroz);
		cv.adicionaItem(beef);
		assertEquals("case02:", cv.listarCardapio(),
				"1 - nome: arroz, calorias = 100" + System.lineSeparator() + "2 - nome: bife, calorias = 100" + System.lineSeparator());
		;

	}
	
	
	@Test(expected=IllegalArgumentException.class)
	public void testCalcularCaloriasComException() {
		String[] refeicao = {"Cafe", "Cafe"};
		Item item = new Item("Arroz", 100);
		Item item2 = new Item("Feijão", 120);
		cv.adicionaItem(item2);
		cv.adicionaItem(item);
		cv.adicionaItem(item);
		assertEquals("case 04:", cv.calcularCaloriasRefeicao(refeicao, "Mega"), "vai gerar o IllegalArgumentException");
	}

}
