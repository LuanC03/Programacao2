package prova.lp2;

import java.util.Arrays;

public class CardapioVirtual {

	private String nomeDoEstabelecimento;
	private Item[] itens;

	public CardapioVirtual(String nomeDoEstabelecimento, int qtdItens) {
		this.nomeDoEstabelecimento = nomeDoEstabelecimento;
		this.itens = new Item[qtdItens];
	}

	public CardapioVirtual(String nomeDoEstabelecimento) {
		this(nomeDoEstabelecimento, 5);
	}

	public void adicionaItem(Item item) {
		itens[this.retornaPosicaoItemVazio()] = item;

	}

	private int retornaPosicaoItemVazio() {
		int posicao = 0;
		for (int i = 0; i < itens.length; i++) {
			if (itens[i] == null) {
				posicao = i;
				break;
			}
		}

		return posicao;
	}

	public String listarCardapio() {
		String listagem = "";
		for (int i = 0; i < itens.length; i++) {
			if (itens[i] != null) {
				listagem += (i + 1) + " - " + itens[i].toString() + System.lineSeparator();
			}
		}
		return listagem;

	}

	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {

		String tamanho = tamanhoRefeicao.toLowerCase();
		int calorias = 0;
		
		
		
		for (String r : refeicao) {
			if (r != null) {
				for (Item i : itens) {
					if (!r.equals(i.getNome())){
						throw new IllegalArgumentException();
					}
					
					
					if (i != null) {
						if (r.equals(i.getNome())) {
							calorias += i.getCalorias();
						}
					}
				}
			}
		}

		if (tamanho.equals("padrão")) {
			calorias *= 1;
		} else if (tamanho.equals("grande")) {
			calorias *= 2;
		} else if (tamanho.equals("mega")) {
			calorias *= 3;
		}

		return calorias;

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(itens);
		result = prime * result + ((nomeDoEstabelecimento == null) ? 0 : nomeDoEstabelecimento.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CardapioVirtual other = (CardapioVirtual) obj;
		if (!Arrays.equals(itens, other.itens))
			return false;
		if (nomeDoEstabelecimento == null) {
			if (other.nomeDoEstabelecimento != null)
				return false;
		} else if (!nomeDoEstabelecimento.equals(other.nomeDoEstabelecimento))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return nomeDoEstabelecimento + " " + Arrays.toString(itens);
	}

}
