import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.*;

public class CardapioTest {

	@Test
	public void testListaCardapio() {
		
		Cardapio cardapio1 = new Cardapio("Quitandinha", "5");
			
		ItemCardapio item1 = new ItemCardapio("Arroz", 50);	
		ItemCardapio item2 = new ItemCardapio("batata", 70);
		ItemCardapio item3 = new ItemCardapio("milho", 80);
		ItemCardapio item4 = new ItemCardapio("Arroz", 60);
		ItemCardapio item5 = new ItemCardapio("vinagre", 30);
		
		cardapio1.adicionaItem(item1);
		cardapio1.adicionaItem(item2);
		cardapio1.adicionaItem(item3);
		cardapio1.adicionaItem(item4);
		
		assertEquals("1 - Arroz - 50 calorias/porção" + "\n"
					 + "2 - batata - 70 calorias/porção" + "\n"
					 + "3 - milho - 80 calorias/porção" + "\n"
					 + "4 - Arroz - 60 calorias/porção" + "\n"
					 ,cardapio1.listaCardapio());
		
		cardapio1.adicionaItem(item5);
		
		assertEquals("1 - Arroz - 50 calorias/porção" + "\n"
				 + "2 - batata - 70 calorias/porção" + "\n"
				 + "3 - milho - 80 calorias/porção" + "\n"
				 + "4 - Arroz - 60 calorias/porção" + "\n"
				 + "5 - vinagre - 30 calorias/porção" + "\n"
				 ,cardapio1.listaCardapio());
	}
	
	@Test
	public void testCalcularCaloriasRefeicao() {
		
		Cardapio cardapio1 = new Cardapio("Quitandinha", "5");
		
		ItemCardapio item1 = new ItemCardapio("repolho", 50);	
		ItemCardapio item2 = new ItemCardapio("cebola", 70);
		ItemCardapio item3 = new ItemCardapio("alho", 80);
		ItemCardapio item4 = new ItemCardapio("pimenta", 60);
		
		cardapio1.adicionaItem(item1);
		cardapio1.adicionaItem(item2);
		cardapio1.adicionaItem(item3);
		cardapio1.adicionaItem(item4);
	
		String [] refeicao1 = {"pimenta", "repolho", "alho"};
	
		assertEquals("190" ,cardapio1.calcularCaloriasRefeicao(refeicao1, "padrão"));
		assertEquals("380" ,cardapio1.calcularCaloriasRefeicao(refeicao1, "grande"));
		assertEquals("570" ,cardapio1.calcularCaloriasRefeicao(refeicao1, "mega"));
	}
}