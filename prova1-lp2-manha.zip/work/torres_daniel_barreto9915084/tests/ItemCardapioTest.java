import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.*;

public class ItemCardapioTest {

	ItemCardapio item1;
	ItemCardapio item2;
	ItemCardapio item3;
	ItemCardapio item4;
	
	@Before 
	public void criaItems() {
		
		item1 = new ItemCardapio("Arroz", 100);
		item2 = new ItemCardapio("Arroz", 70);
		item3 = new ItemCardapio("Arroz Grega", 120);
		item4 = new ItemCardapio("Feijão", 200);
	}
	
	@Test
	public void testToString() {
		
		assertEquals("Arroz - 100 calorias/porção", item1.toString());
		assertEquals("Arroz Grega - 120 calorias/porção", item3.toString());
		assertNotEquals("Feijão Preto - 120 calorias/porção", item4.toString());
		
	}

	@Test
	public void testEquals() {
		
		assertEquals(item1, item2);
		assertNotEquals(item1, item3);
		assertNotEquals(item2, item4);
	}
}
