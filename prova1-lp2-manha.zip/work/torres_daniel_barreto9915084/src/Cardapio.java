
public class Cardapio {
	
	private String nomeEstabelecimento;
	private ItemCardapio[] menu;
	private int qtdItems;
	
	public Cardapio(String nomeDoEstabelecimento) {
		
		this.nomeEstabelecimento = nomeDoEstabelecimento;
		this.menu = new ItemCardapio[5];
	}
			
	
	public Cardapio(String nomeDoEstabelecimento, String qtdItems) {
		
		this.nomeEstabelecimento = nomeDoEstabelecimento;
		this.menu = new ItemCardapio[Integer.parseInt(qtdItems)];
	}

	public void adicionaItem(ItemCardapio item) {
		
		this.menu[qtdItems] = item;
		this.qtdItems++;
	}
	
	public String listaCardapio() {
		
		String lista = "";
		
		for (int i = 0; i < qtdItems; i++) {
			
			lista += (i + 1) + " - " + menu[i].toString() + "\n";
		}
		
		return lista;
	}

	public String calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
	
		int soma = 0;
		boolean existeNoCardapio = false;
		
		for (String consumido: refeicao) {
			
			existeNoCardapio = false;
			
			for (ItemCardapio item: menu) {
				
				if (item.getNome().equals(consumido)) {
					
					soma += item.getCaloriasPorcao();
					existeNoCardapio = true;
					break;
				}
			}
			
			if (existeNoCardapio == false) {
				
				throw new IllegalArgumentException("Não existe item no cardápio");
			}
		}
	
		if (tamanhoRefeicao.equals("grande")) {
			
			soma = soma * 2;
		}
		
		if (tamanhoRefeicao.equals("mega")) {
			
			soma = soma * 3;
		}
		
		return "" + soma;
	}
}