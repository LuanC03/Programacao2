
public class ItemCardapio {
	
	private String nome;
	private int caloriasPorcao;
	
	
	public ItemCardapio(String nomeDoItem, int caloriasPorPorcao) {
		
		this.nome = nomeDoItem;
		this.caloriasPorcao = caloriasPorPorcao;
	}

	public String getNome() {
		
		return this.nome;
	}

	public int getCaloriasPorcao() {
		
		return this.caloriasPorcao;
	}

	public String toString() {
		
		return this.nome + " - " + this.caloriasPorcao + " calorias/porção";
	}

	@Override
	public int hashCode() {
		
		final int prime = 31;
		int result = 1;
		
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		
		if (this == obj)
			return true;
		
		if (obj == null)
			return false;
		
		if (getClass() != obj.getClass())
			return false;
	
		ItemCardapio other = (ItemCardapio) obj;
		
		if (nome == null) {
		
			if (other.nome != null)
				return false;
		
		} else if (!nome.equals(other.nome))
			return false;
		
		return true;
	}
	
	
}
