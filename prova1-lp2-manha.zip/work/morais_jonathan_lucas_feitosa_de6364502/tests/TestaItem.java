import static org.junit.Assert.*;

import org.junit.Test;

public class TestaItem {

	@Test
	public void testaConstrutor() {
		Item arrozBranco = new Item("Arroz Branco", 100);
		Item macarrao = new Item("Macarrão", 200);
		Item vinagrete = new Item("Vinagrete", 0);
		
		assertEquals("Arroz Branco", arrozBranco.getNome());
		assertEquals("Macarrão", macarrao.getNome());
		assertEquals("Vinagrete", vinagrete.getNome());

		assertEquals(100, arrozBranco.getCalorias());
		assertEquals(200, macarrao.getCalorias());
		assertEquals(0, vinagrete.getCalorias());
	}
	
	@Test
	public void TestaIguais() {
		Item feijoada = new Item("Feijoada", 150);
		Item frango = new Item("Frango Assado", 90);
		Item feijoada2 = new Item("Feijoada", 200);

		assertEquals(true, feijoada.equals(feijoada2));
		assertEquals(false, feijoada.equals(frango));
		assertEquals(false, feijoada.equals(null));
}
}