import static org.junit.Assert.*;

import org.junit.Test;

public class TestaCardapio {

	@Test
	public void testaConstrutor() {
		Cardapio LaSuissa = new Cardapio("La Suissa", 10);
		Cardapio Restaurante = new Cardapio("Um Restaurante Generico");
		
		assertEquals("La Suissa", LaSuissa.toString());
		assertEquals("Um Restaurante Generico", Restaurante.toString());
	}
	
	@Test
	public void testaCalularCalorias() throws Exception {
		Item arrozBranco = new Item("Arroz Branco", 100);
		Item macarrao = new Item("Macarrão", 200);
		Item vinagrete = new Item("Vinagrete", 0);
		Item feijoada = new Item("Feijoada", 150);
		Item frango = new Item("Frango Assado", 90);
		Item heineken = new Item("Heineken", 30);
		
		Cardapio bar = new Cardapio("La Suissa", 10);
		
		bar.adicionaItem(arrozBranco);
		bar.adicionaItem(macarrao);
		bar.adicionaItem(vinagrete);
		bar.adicionaItem(frango);
		bar.adicionaItem(feijoada);
		
		String[] refeicao = {"Arroz Branco", "Macarrão", "Frango Assado"};
		String[] refeicao2 = {"Feijoada", "Heineken"};
		assertEquals(180 , bar.calcularCaloriasRefeicao(refeicao2, "padrão"));
		assertEquals(390*3, bar.calcularCaloriasRefeicao(refeicao, "mega"));
		

	}

}
