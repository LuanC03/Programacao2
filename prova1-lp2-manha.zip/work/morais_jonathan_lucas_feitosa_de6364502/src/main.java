
public class main {

	public static void main(String[] args) {
		Item arrozBranco = new Item("Arroz Branco", 100);
		Item macarrao = new Item("Macarrão", 200);
		Item vinagrete = new Item("Vinagrete", 0);
		Item feijoada = new Item("Feijoada", 150);
		Item frango = new Item("Frango Assado", 90);
		
		Cardapio LaSuissa = new Cardapio("La Suissa", 10);
		Cardapio Restaurante = new Cardapio("Um Restaurante Generico");
		
		LaSuissa.adicionaItem(arrozBranco);
		LaSuissa.adicionaItem(macarrao);
		LaSuissa.adicionaItem(vinagrete);
		LaSuissa.adicionaItem(frango);
		LaSuissa.adicionaItem(feijoada);
		
		System.out.println(LaSuissa.listaCardapio());

	}

}
