import java.util.Arrays;

public class Cardapio {
	
	private String nomeEstabelecimento;
	private int qtdItens;
	private Item[] itens = new Item[qtdItens];
	
	public Cardapio(String nomeEstabelecimento, int qtdItens) {
		this.nomeEstabelecimento = nomeEstabelecimento;
		this.qtdItens = qtdItens;
	}
	
	public Cardapio(String nomeEstabelecimento) {
		this.nomeEstabelecimento = nomeEstabelecimento;
		this.qtdItens = 5;
	}
	
	public void adicionaItem(Item item) {
		for (int i = 0; i < itens.length; i++) {
			if (itens[i] == null) {
				itens[i] = item;
			}
		}
	}
	
	
	public String listaCardapio() {
		String lista = "";
		int count = 1;
	
		for (int i = 0; i < itens.length; i++) {
			if(itens[i] != null) {
				lista += count + " - " + itens.toString() + ". \n";
			}
		}
		return lista;
	}
	
	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) throws Exception{
		int calorias = 0;
		boolean conhecido = false;
		
		for (int i = 0; i < refeicao.length; i++) {
			if (refeicao[i] == itens[i].getNome()){
				conhecido = true;
				calorias += itens[i].getCalorias();
			}
			if (i == refeicao.length - 1 || conhecido == false) {
				//	throw IllegalArgumentException;
			}
		}
		
	
	if(tamanhoRefeicao == "padrão") {
		return calorias;
	} 
	else if (tamanhoRefeicao == "grande") {
		return calorias * 2;
	}
	else if (tamanhoRefeicao == "mega") {
		return calorias * 3;
	}
	return calorias;
	}
	

	@Override
	public String toString() {
		return nomeEstabelecimento;
	}
	
	

}

