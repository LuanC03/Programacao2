package Classes;

import java.util.Arrays;

public class Cardapio {
	private String estabelecimento;
	private Item[] itens;
	private int qtdItens;

	public Cardapio(String estabelecimento) {
		this(estabelecimento, 5);
	}

	public Cardapio(String estabelecimento, int n) {
		this.estabelecimento = estabelecimento;
		itens = new Item[n];
		qtdItens = 0;
	}

	public void adicionaItem(Item item) {
		itens[qtdItens] = item;
		qtdItens += 1;
	}

	public String listaCardapio() {
		String lista = "";

		for (int i = 0; i < qtdItens; i++) {
			lista += (i + 1) + " - " + itens[i].getNome() + " - " + itens[i].getCalorias() + " calorias/porção\n";
		}

		return lista;
	}

	private int qtdPorcoes(String tamanhoRefeicao) {
		int qtd;

		switch (tamanhoRefeicao) {
		case "mega":
			qtd = 3;
			break;
		case "grande":
			qtd = 2;
			break;
		default:
			qtd = 1;
		}

		return qtd;
	}

	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao){
		int totalCalorias = 0;
		
		for (int j = 0; j < refeicao.length; j++) {
			for (int i = 0; i < qtdItens; i++) {
				if (refeicao[j].equals(itens[i].getNome())) {
					totalCalorias += itens[i].getCalorias();
				}
			}
		}

		int qtd = qtdPorcoes(tamanhoRefeicao);
		totalCalorias *= qtd;

		return totalCalorias;

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((estabelecimento == null) ? 0 : estabelecimento.hashCode());
		result = prime * result + Arrays.hashCode(itens);
		result = prime * result + qtdItens;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cardapio other = (Cardapio) obj;
		
		if (this.estabelecimento.equals(other.estabelecimento))
			return true;
		return true;
	}

	@Override
	public String toString() {
		return "Cardapio\nNome do Estabelecimento: " + this.estabelecimento + "Itens: " + Arrays.toString(itens);
	}

}
