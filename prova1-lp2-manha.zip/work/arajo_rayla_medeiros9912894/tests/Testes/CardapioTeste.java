package Testes;

import Classes.Cardapio;
import Classes.Item;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CardapioTeste {

	@Test
	public void testCardapioPadrao() {
		Cardapio c = new Cardapio("Barraquinha");
	}
	
	@Test
	public void testCardapio() {
		Cardapio c = new Cardapio("Barraquinha", 10);
	}
	
	@Test
	public void testAdicionaItem() {
		Cardapio c = new Cardapio("Barraquinha");
		Item i = new Item("arroz", 100);
		
		c.adicionaItem(i);
	}
	
	@Test
	public void testCalcularCaloriasRefeicao() {
		Cardapio c = new Cardapio("Barraquinha");
		Item i1 = new Item("arroz", 100);
		Item i2 = new Item("feijao", 90);
		
		c.adicionaItem(i1);
		c.adicionaItem(i2);
		
		String[] r = new String[2];
		r[0] = "arroz";
		r[1] = "feijão";
		
		int test = c.calcularCaloriasRefeicao(r, "padrao");
		assertEquals(test, 190);
	}
	
	@Test
	public void testEqualsObjetosIguais() {
		Cardapio c1 = new Cardapio("Barraquinha");
		Cardapio c2 = new Cardapio("Barraquinha");
		
	}

}
