package Quiosque;

import static org.junit.Assert.*;

import org.junit.Test;

public class CardapioTest {

	@Test
	public void adicionaItemtest() {
		Cardapio cardapio = new Cardapio("McDonalds");
		Alimento comida = new Alimento("arroz", 20) ;
		cardapio.adicionaItem(comida);
	}
	
	@Test
	public void listaCardapioTest() {
		Cardapio cardapio = new Cardapio("McDonalds");
		Alimento comida = new Alimento("arroz", 20) ;
		cardapio.adicionaItem(comida);
		assertEquals(cardapio.listaCardapio(), "arroz Caloria por porção: 20\n");
	}
	
	@Test
	public void calcularCaloriasRefeicaoPadraoTest() {
		Cardapio cardapio = new Cardapio("McDonalds");
		Alimento comida = new Alimento("arroz", 20) ;
		Alimento feijao = new Alimento("feijao", 30);
		Alimento batata = new Alimento("batata", 50);
		cardapio.adicionaItem(comida);
		cardapio.adicionaItem(feijao);
		cardapio.adicionaItem(batata);
		String[] comidas = {"arroz", "feijao", "batata"};
		String tamanho = "padrao";
		assertEquals(cardapio.calcularCaloriasRefeicao(comidas, tamanho), "100 Calorias.");
	}
	
	@Test
	public void calcularCaloriasRefeicaoGrandeTest() {
		Cardapio cardapio = new Cardapio("McDonalds");
		Alimento comida = new Alimento("arroz", 20) ;
		Alimento feijao = new Alimento("feijao", 30);
		Alimento batata = new Alimento("batata", 50);
		cardapio.adicionaItem(comida);
		cardapio.adicionaItem(feijao);
		cardapio.adicionaItem(batata);
		String[] comidas = {"arroz", "feijao", "batata"};
		String tamanho = "grande";
		assertEquals(cardapio.calcularCaloriasRefeicao(comidas, tamanho), "200 Calorias.");
	}
	
	@Test
	public void calcularCaloriasRefeicaoMegaTest() {
		Cardapio cardapio = new Cardapio("McDonalds");
		Alimento comida = new Alimento("arroz", 20) ;
		Alimento feijao = new Alimento("feijao", 30);
		Alimento batata = new Alimento("batata", 50);
		cardapio.adicionaItem(comida);
		cardapio.adicionaItem(feijao);
		cardapio.adicionaItem(batata);
		String[] comidas = {"arroz", "feijao", "batata"};
		String tamanho = "mega";
		assertEquals(cardapio.calcularCaloriasRefeicao(comidas, tamanho), "300 Calorias.");
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void calcularCaloriasRefeicaoErradaTest() {
		Cardapio cardapio = new Cardapio("McDonalds");
		Alimento comida = new Alimento("arroz", 20) ;
		Alimento feijao = new Alimento("feijao", 30);
		Alimento batata = new Alimento("batata", 50);
		cardapio.adicionaItem(comida);
		cardapio.adicionaItem(feijao);
		cardapio.adicionaItem(batata);
		String[] comidas = {"arroz", "playstation 4", "batata"};
		String tamanho = "mega";
		assertEquals(cardapio.calcularCaloriasRefeicao(comidas, tamanho), "300 Calorias.");
	}

}
