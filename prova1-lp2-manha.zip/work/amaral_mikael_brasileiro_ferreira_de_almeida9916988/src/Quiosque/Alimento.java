package Quiosque;

public class Alimento {
	private String nome;
	private int porcao;
	
	
	public Alimento(String nome, int porcao) {
		this.nome = nome;
		this.porcao = porcao;
	}
	
	public String toString() {
		String dados = this.nome + " " + "Caloria por porção: " + this.porcao;
		return dados;
	}

	public String getNome() {
		return nome;
	}
	
	public int getPorcao() {
		return porcao;
	}
	
	public boolean nomeIgual(String nome) {
		return this.nome.equals(nome);
	}

	@Override
	public boolean equals(Object obj) {
		if (obj != null) {
			if (this instanceof Object) {
				Alimento comida = (Alimento) obj;

				if (this.nome.equals(comida.getNome())) {
					return true;
				}
			}
		}

		return false;
	}

}
