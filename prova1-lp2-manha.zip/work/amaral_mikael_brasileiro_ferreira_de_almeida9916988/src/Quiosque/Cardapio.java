package Quiosque;

public class Cardapio {
	private String nome;
	private Alimento[] itens;

	public Cardapio(String nome) {
		this.nome = nome;
		this.itens = new Alimento[5];
	}

	public Cardapio(String nome, int tamanho) {
		this.nome = nome;
		this.itens = new Alimento[tamanho];
	}

	public void adicionaItem(Alimento comida) {
		int i = 0;

		while (i < itens.length) {
			if (itens[i] == null) {
				itens[i] = comida;
				break;

			} else {
				i++;
			}
		}
	}

	public String listaCardapio() {
		String listaItens = "";
		int z = 0;
		while (z < itens.length) {
			if (itens[z] == null) {
				break;
			} else {
				listaItens += itens[z].toString() + "\n";
				z++;
			}
		}
		return listaItens;
	}

	public String calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		int soma = 0;
		int tamanho = 0;

		if (tamanhoRefeicao.equals("padrao")) {
			tamanho = 1;

		} else if (tamanhoRefeicao.equals("grande")) {
			tamanho = 2;

		} else {
			tamanho = 3;
		}

		for (int r = 0; r < refeicao.length; r++) {
			int p = 0;
			boolean existe = false;

			while (p < itens.length) {
				if (itens[p] == null) {
					break;
				}
				if (itens[p].nomeIgual(refeicao[r])) {
					existe = true;
					break;
				} else {
					p++;
				}

			}

			if (!existe) {
				throw new IllegalArgumentException();
			}

			soma += itens[p].getPorcao();
		}

		int caloriasTotais = soma * tamanho;
		String caloriasRefeicao = caloriasTotais + " Calorias.";
		return caloriasRefeicao;
	}
}
