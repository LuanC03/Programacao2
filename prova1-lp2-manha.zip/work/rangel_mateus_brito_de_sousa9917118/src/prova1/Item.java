package prova1;

public class Item {
	private String nome;
	private int calorias;
	
	public Item(String nome, int calorias) {
		this.nome = nome;
		this.calorias = calorias;
	}
	
	public String toString() {
		return nome + " / " + calorias;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Item)) {
			return false;
		}
		Item other = (Item) obj;
		if (nome == null) {
			if (other.nome != null) {
				return false;
			}
		} else if (!nome.equals(other.nome)) {
			return false;
		}
		return true;
	}

	public String getNome() {
		return nome;
	}

	public int getCalorias() {
		return calorias;
	}
}
