package prova1;

import static org.junit.Assert.*;

import org.junit.Test;

public class CardapioTest {

	@Test(expected=IllegalArgumentException.class)
	public void itensDesconhecidosDoCardapio() {
		String[] refeicao = new String[2];
		String comida1 = "lasanha";
		String comida2 = "fava";
		refeicao[] = new String(comida1, comida2);
		Cardapio.calcularCaloriasRefeicao(refeicao, padrão);
		fail("Nomes desconhecidos do cardapio");
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void adicionaItemNomeSoEspacos() {
		String nome = "   ";
		int calorias = 50;
		Cardapio cardapio = new cardapio();
		Cardapio.adicionaItem(nome, calorias);
		fail("Nome adicionado feito só com espaços");
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void adicionaItemVazio() {
		String nome = "";
		int calorias = 50;
		Item item = new Item(nome, calorias);
		fail("Nome adicionado vazio");
	}
	
	@Test(expected=NullPointerException.class)
	public void adicionaItemNull() {
		String nome = null;
		int calorias = 50;
		Item item = new Item(nome, calorias);
		fail("Nome adicionado null");
	}
}
