package prova1;

public class Item {

	private String nome;
	private int caloriasPorcao;
	
	public Item(String nome, int caloriasPorcao) {
		nome = nome.trim();
		verificaValidadeItem(nome, caloriasPorcao);
		this.nome = nome;
		this.caloriasPorcao = caloriasPorcao;
	}

	private void verificaValidadeItem(String nome, int caloriasPorcao) {
		if(nome == null) {
			throw new NullPointerException();
		}
		if(nome.equals("") || caloriasPorcao < 0) {
			throw new IllegalArgumentException();
		}
	}

	public String getNome() {
		return this.nome;
	}

	public int getCaloriasPorcao() {
		return this.caloriasPorcao;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return String.format("%s - %d calorias/porção\n", nome, caloriasPorcao);
	}
	
}
