package prova1;

public class Cardapio {
	private String estabelecimento;
	private Item[] arrItens;
	private int qtdAtualItens;
	
	public Cardapio(String nome, int quantidade) {
		if(quantidade < 0) {
			throw new NegativeArraySizeException();
		}
		nome = nome.trim();
		verificaCardapioNome(nome);
		this.estabelecimento = nome;
		this.arrItens = new Item[quantidade];
	}
	private void verificaCardapioNome(String nome) {
		if(nome == null) {
			throw new NullPointerException();
		}
		if(nome.equals("")) {
			throw new IllegalArgumentException();
		}
	}
	public Cardapio(String nome) {
		this.estabelecimento = nome;
		this.arrItens = new Item[5];
	}
	public void adicionaItem(Item item) {
		if(qtdAtualItens >= arrItens.length) {
			throw new IndexOutOfBoundsException("Não é possível adicionar mais itens."); 
		} else {
			this.arrItens[qtdAtualItens] = item;
			qtdAtualItens++;
		}
	}
	
	public String listaCardapio() {
		String strLista = "";
		for (int i = 0; i < qtdAtualItens; i++) {
			strLista += String.format("%d - %s", (i+1), arrItens[i].toString());
		}
		return strLista;
	}
	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		int totalCalorias = 0;
		verificaRefeicao(refeicao);
		String tipoDeTamanho = verificaTamanhoRefeicao(tamanhoRefeicao);
		for (int i = 0; i < refeicao.length; i++) {
			totalCalorias += procuraCaloriasPorNome(refeicao[i]);
		}
		if(tipoDeTamanho.equals("grande")){
			return totalCalorias * 2; 
		} else if(tipoDeTamanho.equals("mega")) {
			return totalCalorias * 3;
		}
		return totalCalorias;
	}
	private int procuraCaloriasPorNome(String nome) {
		int calorias = 0;
		for(int i = 0; i < qtdAtualItens; i++) {
			if(nome.equals(arrItens[i].getNome())) {
				calorias = arrItens[i].getCaloriasPorcao();
			}
		}
		return calorias;
	}
	private void verificaRefeicao(String[] refeicao) {
		boolean flagEncontrado;
		for (int i = 0; i < refeicao.length; i++) {
			flagEncontrado = false; 
			for (int j = 0; j < qtdAtualItens; j++) {
				if(refeicao[i].equals(arrItens[j].getNome())) {
					flagEncontrado = true;
				}
			}
			if(!flagEncontrado) {
				throw new IllegalArgumentException();
			}
		}
	}
	private String verificaTamanhoRefeicao(String tam) {
		if(!tam.equals("padrão") && !tam.equals("grande") && !tam.equals("mega")) {
			throw new IllegalArgumentException();
		}
		return tam;
	}
}
