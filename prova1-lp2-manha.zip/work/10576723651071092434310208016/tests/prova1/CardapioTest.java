package prova1;

import static org.junit.Assert.*;

import org.junit.*;

public class CardapioTest {

	Cardapio cardapioPadrao;
	Item item1;
	Item item2;
	Item item3;

	@Before
	public void criaCardapioPadrao() {
		item1 = new Item("arroz branco", 100);
		item2 = new Item("arroz a grega", 200);
		item3 = new Item("macarrao", 200);
		cardapioPadrao = new Cardapio("Estabelecimento Padrão", 4);
		cardapioPadrao.adicionaItem(item1);
		cardapioPadrao.adicionaItem(item2);
		cardapioPadrao.adicionaItem(item3);
	}
	@Test (expected=NegativeArraySizeException.class)
	public void testCardapioStringIntValorAbsurdo() {
		Cardapio cardapioFalho = new Cardapio("Estabelecimento Diferente", -1);
	}

	@Test (expected=NullPointerException.class)
	public void testCardapioStringNomeNulo() {
		Cardapio cardapioFalho = new Cardapio(null, 10);
	}
	@Test (expected=IllegalArgumentException.class)
	public void testCardapioStringNomeVazio() {
		Cardapio cardapioFalho = new Cardapio("       ", 10);
	}

	@Test (expected=IndexOutOfBoundsException.class)
	public void testAdicionaItemOutOfBounds() {
		Item item4 = new Item("feijoada", 150);
		Item item5 = new Item("feijao verde", 90);
		cardapioPadrao.adicionaItem(item4);
		cardapioPadrao.adicionaItem(item5);
	}

	@Test
	public void testListaCardapio() {
		String msg = "Esperando receber a string definida";
		String esperado = "1 - arroz branco - 100 calorias/porção\n"
						+ "2 - arroz a grega - 200 calorias/porção\n"
						+ "3 - macarrao - 200 calorias/porção\n";
		assertEquals(msg, esperado, cardapioPadrao.listaCardapio());
	}
	@Test
	public void testCalcularCaloriasRefeicao() {
		String[] refeicao = {"arroz branco", "macarrao"};
		String msg = "Esperando obter 900 calorias";
		assertEquals(msg, 900, cardapioPadrao.calcularCaloriasRefeicao(refeicao, "mega"));
	}
	@Test (expected=IllegalArgumentException.class)
	public void testCalcularCaloriasRefeicaoIllegalRefeicao() {
		String[] refeicao = {"arroz branco", "macarrao", "feijoada"};
		cardapioPadrao.calcularCaloriasRefeicao(refeicao, "padrão");
	}
	@Test (expected=IllegalArgumentException.class)
	public void testCalcularCaloriasRefeicaoIllegalTamanho() {
		String[] refeicao = {"arroz branco", "macarrao", "feijoada"};
		cardapioPadrao.calcularCaloriasRefeicao(refeicao, "padraao");
	}

}
