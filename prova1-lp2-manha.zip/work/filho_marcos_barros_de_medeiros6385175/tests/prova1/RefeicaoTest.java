package prova1;

import org.junit.Assert;
import org.junit.Test;

public class RefeicaoTest {

	@Test
	public void refeicaoValida() {
		new Refeicao("Lamen", 150);
	}
	
	@Test(expected=NullPointerException.class)
	public void refeicaoNomeNull() {
		new Refeicao(null, 150);
	}
	
	@Test
	public void testaEqualsTrue() {
		Refeicao a = new Refeicao("feijão carioca", 100);
		Refeicao b = new Refeicao("feijão carioca", 500);
		Assert.assertTrue(a.equals(b));
	}
	
	@Test
	public void testaEqualsFalse() {
		Refeicao a = new Refeicao("feijão carioca", 100);
		Refeicao b = new Refeicao("feijão", 500);
		Assert.assertFalse(a.equals(b));
	}
	
	@Test
	public void testaToString() {
		Refeicao a = new Refeicao("feijão carioca", 100);
		Assert.assertEquals("feijão carioca - 100 calorias.", a.toString());
	}

}
