package prova1;

import org.junit.Assert;
import org.junit.Test;

public class CardapioTest {
	
	@Test
	public void criaCardapioBásico() {
		Cardapio a = new Cardapio("RU");
		Assert.assertEquals(5, a.getCardapio().length);
	}
	
	@Test
	public void criaCardapioEspacosDefinidos() {
		Cardapio a = new Cardapio("RU", 15);
		Assert.assertEquals(15, a.getCardapio().length);
	}
	
	@Test(expected=NullPointerException.class)
	public void criaCardapioNomeNulo() {
		new Cardapio(null, 16);
	}
	
	@Test
	public void testaAdicionaItem() {
		Cardapio a = new Cardapio("RU");
		Refeicao alimento = new Refeicao("Feijoada Simples", 100);
		a.adicionaItem(alimento);
		a.adicionaItem(alimento);
		a.adicionaItem(alimento);
		a.adicionaItem(alimento);
		a.adicionaItem(alimento);
	}
	
	@Test(expected=ArrayIndexOutOfBoundsException.class)
	public void testaAdicionaItemAlemLimite() {
		Cardapio a = new Cardapio("RU");
		Refeicao alimento = new Refeicao("Feijoada Simples", 100);
		a.adicionaItem(alimento);
		a.adicionaItem(alimento);
		a.adicionaItem(alimento);
		a.adicionaItem(alimento);
		a.adicionaItem(alimento);
		a.adicionaItem(alimento);
	}
	
	@Test
	public void testaListarCardapio() {
		Cardapio a = new Cardapio("RU", 3);
		Refeicao alimento = new Refeicao("Feijoada Simples", 100);
		a.adicionaItem(alimento);
		a.adicionaItem(alimento);
		a.adicionaItem(alimento);
		Assert.assertEquals("Feijoada Simples - 100 calorias.\nFeijoada Simples - 100 calorias.\nFeijoada Simples - 100 calorias.\n", a.listaCardapio());
	}
	
	@Test
	public void calcularCaloriasRefeicaoPadrao() {
		Cardapio a = new Cardapio("RU", 3);
		Refeicao alimento = new Refeicao("Feijoada Simples", 300);
		a.adicionaItem(alimento);
		alimento = new Refeicao("Vinagrete", 100);
		a.adicionaItem(alimento);
		alimento = new Refeicao("arroz branco", 300);
		a.adicionaItem(alimento);
		String[] jj = {"arroz branco", "Feijoada Simples", "Vinagrete"};
		Assert.assertTrue(a.calcularCaloriasRefeicao(jj, "padrão") == 700);
	}
	
	@Test
	public void calcularCaloriasRefeicaoGrande() {
		Cardapio a = new Cardapio("RU", 3);
		Refeicao alimento = new Refeicao("Feijoada Simples", 300);
		a.adicionaItem(alimento);
		alimento = new Refeicao("Vinagrete", 100);
		a.adicionaItem(alimento);
		alimento = new Refeicao("arroz branco", 300);
		a.adicionaItem(alimento);
		String[] jj = {"arroz branco", "Feijoada Simples", "Vinagrete"};
		Assert.assertTrue(a.calcularCaloriasRefeicao(jj, "grande") == 700*2);
	}
	
	@Test
	public void calcularCaloriasRefeicaoMega() {
		Cardapio a = new Cardapio("RU", 3);
		Refeicao alimento = new Refeicao("Feijoada Simples", 300);
		a.adicionaItem(alimento);
		alimento = new Refeicao("Vinagrete", 100);
		a.adicionaItem(alimento);
		alimento = new Refeicao("arroz branco", 300);
		a.adicionaItem(alimento);
		String[] jj = {"arroz branco", "Feijoada Simples", "Vinagrete"};
		Assert.assertTrue(a.calcularCaloriasRefeicao(jj, "mega") == 700*3);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void calcularCaloriasRefeicaoInvalida() {
		Cardapio a = new Cardapio("RU", 3);
		Refeicao alimento = new Refeicao("Feijoada Simples", 300);
		a.adicionaItem(alimento);
		alimento = new Refeicao("Vinagrete", 100);
		a.adicionaItem(alimento);
		alimento = new Refeicao("arroz branco", 300);
		a.adicionaItem(alimento);
		String[] jj = {"arroz branco", "Feijoada Simples", "Cachaça"};
		a.calcularCaloriasRefeicao(jj, "mega");
	}
	
	@Test
	public void testaEqualsTrue() {
		Cardapio a = new Cardapio("C.U.", 10);
		Cardapio b = new Cardapio("C.U.", 10);
		Assert.assertTrue(a.equals(b));
	}
	
	@Test
	public void testaEqualsFalse() {
		Cardapio a = new Cardapio("C.U.", 10);
		Cardapio b = new Cardapio("C.U.", 15);
		Assert.assertFalse(a.equals(b));
	}
}
