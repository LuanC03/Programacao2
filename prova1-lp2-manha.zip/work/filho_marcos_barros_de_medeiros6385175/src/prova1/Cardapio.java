package prova1;

import java.util.Arrays;

public class Cardapio {
	String estabelecimento;
	Refeicao[] cardapio;
	
	public Cardapio(String nome, int numeroOpcoes) throws NullPointerException{
		if (nome == null) {
			throw new NullPointerException();
		}
		this.estabelecimento = nome;
		this.cardapio = new Refeicao[numeroOpcoes];
	}
	
	public Cardapio (String nome) throws NullPointerException{
		if (nome == null) {
			throw new NullPointerException();
		}
		this.estabelecimento = nome;
		this.cardapio = new Refeicao[5];
	}
	
	public void adicionaItem(Refeicao refeicao) {
		cardapio[espacoVazio()] = refeicao;
	}
	
	private int espacoVazio() {
		for (int i = 0; i < this.cardapio.length; i++) {
			if (this.cardapio[i] == null){
				return i;
			}
		}
		return -1;
	}
	
	public String listaCardapio() {
		int d;
		String retorno = "";
		if (espacoVazio() == -1) {
			d = this.cardapio.length;
		} else {
			d = espacoVazio();
		}
		
		for (int i = 0; i < d; i++) {
			retorno += this.cardapio[i] + "\n";
		}
		
		return retorno;
	}
	
	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoDaRefeicao) throws IllegalArgumentException{
		int multiplicador = tamanhoRefeicao(tamanhoDaRefeicao);
		int calorias = 0;
		String prato;
		for (int j = 0; j < refeicao.length; j++) {
			prato = refeicao[j];
			calorias += procuraCalorias(prato);
		}
		return calorias*multiplicador;
	}
	
	private int tamanhoRefeicao(String tamanhoDaRefeicao) {
		switch(tamanhoDaRefeicao) {
		case "padrão":
			return 1;
		case "grande":
			return 2;
		case "mega":
			return 3;
		default:
			return 1;
		}
	}
	
	private int procuraCalorias(String prato) throws IllegalArgumentException{
		for(int i = 0; i < this.cardapio.length; i++) {
			if (prato.equals(this.cardapio[i].getNome())){
				return this.cardapio[i].getCalorias();
			}
		}
		throw new IllegalArgumentException("Um dos pratos não está no menu!");
	}

	public Refeicao[] getCardapio() {
		return cardapio;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(cardapio);
		result = prime * result + ((estabelecimento == null) ? 0 : estabelecimento.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cardapio other = (Cardapio) obj;
		if (!Arrays.equals(cardapio, other.cardapio))
			return false;
		if (estabelecimento == null) {
			if (other.estabelecimento != null)
				return false;
		} else if (!estabelecimento.equals(other.estabelecimento))
			return false;
		return true;
	}
	
	
}
