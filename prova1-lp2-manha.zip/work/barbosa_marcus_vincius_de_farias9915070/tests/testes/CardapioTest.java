package testes;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import model.Cardapio;
import model.Item;

public class CardapioTest {
	
	Cardapio cardapio;
	
	@Before
	public void setUp(){
		cardapio = new Cardapio("Cardapio");
	}

	@Test
	public void adicionaItemCorreto(){
		cardapio.adicionaItem(new Item("Arroz", 100));
		assertEquals(6, cardapio.tamanhoCardapio());
	}
	
	@Test(expected = NullPointerException.class)
	public void adicionaItemNulo() {
		cardapio.adicionaItem(null);
	}
	
	@Test
	public void listaCardapioPadrão() {
		String s = "1 - Arroz - 100 calorias/porção\n" +
				"2 - Feijão - 100 calorias/porção\n" +
				"3 - Farofa - 100 calorias/porção\n" +
				"4 - Macarrão - 100 calorias/porção\n" +
				"5 - Suco - 100 calorias/porção\n";
		
		assertEquals(s, cardapio.listaCardapio());
	}
	
	@Test
	public void listaCardapioModificado() {
		String s = "1 - Arroz - 100 calorias/porção\n" +
				"2 - Feijão - 100 calorias/porção\n" +
				"3 - Farofa - 100 calorias/porção\n" +
				"4 - Macarrão - 100 calorias/porção\n" +
				"5 - Suco - 100 calorias/porção\n" +
				"6 - Feijoada - 100 calorias/porção\n";
		
		cardapio.adicionaItem(new Item("Feijoada", 100));
		
		assertEquals(s, cardapio.listaCardapio());
	}
	
	@Test
	public void calcularCaloriasRefeicaoPadrão() {
		String[] refeicao = {"Arroz","Feijão"};
		assertEquals(200, cardapio.calcularCaloriasRefeicao(refeicao, "padrão"));
	}

	@Test
	public void calcularCaloriasRefeicaoGrande() {
		String[] refeicao = {"Arroz","Feijão"};
		assertEquals(400, cardapio.calcularCaloriasRefeicao(refeicao, "grande"));
	}
	
	@Test
	public void calcularCaloriasRefeicaoMega() {
		String[] refeicao = {"Arroz","Feijão"};
		assertEquals(600, cardapio.calcularCaloriasRefeicao(refeicao, "mega"));
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void calcularCaloriasRefeicaoInvalida() {
		String[] refeicao = {"Arroz","Feijoada"};
		assertEquals(200, cardapio.calcularCaloriasRefeicao(refeicao, "padrão"));
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void calcularCaloriasRefeicaoTamanhoInvalido() {
		String[] refeicao = {"Arroz","Suco"};
		assertEquals(200, cardapio.calcularCaloriasRefeicao(refeicao, "gigante"));
	}
	
	@Test
	public void pesquisaItemCorreto() {
		Item item_aux = new Item("Arroz", 100);
		assertEquals(item_aux, cardapio.pesquisaItem("Arroz"));
	}
	
	@Test
	public void pesquisaItemNomeInvalido() {
		assertEquals(null, cardapio.pesquisaItem("Vinagrete"));
	}
}
