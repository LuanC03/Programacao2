package model;

import java.util.Arrays;

public class Cardapio {
	
	private String nome;
	private Item[] itens;
	
	public Cardapio(String nome, int num_itens) {
		this.nome = nome;
		this.itens = new Item[num_itens];
	}
	
	public Cardapio(String nome) {
		this.nome = nome;
		this.itens = this.criaListaPadrao();
	}
	
	public void adicionaItem(Item item) {
		if(item == null) {
			throw new NullPointerException("Valor nulo para item!");
		}
		else {
			int tam = itens.length;
			itens = Arrays.copyOf(itens, tam + 1);
			itens[tam] = item;	
		}
	}
	
	public String listaCardapio() {
		
		String s = "";
		
		for(int i = 0; i < itens.length; i++) {
			s += i+1 + " - " + itens[i].toString() + "\n";
		}
		
		return s;
	}
	
	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		int calorias = 0;
		
		for(String s : refeicao) {
			if(pesquisaItem(s) == null) {
				throw new IllegalArgumentException("Refeição Inválida");
			}
			else {
				calorias += pesquisaItem(s).getCalorias();
			}
		}
		
		if(tamanhoRefeicao.equals("padrão")) {
			calorias *= 1;
		}
		else if(tamanhoRefeicao.equals("grande")) {
			calorias *= 2;
		}
		else if(tamanhoRefeicao == "mega") {
			calorias *= 3;
		}
		else {
			throw new IllegalArgumentException("Tamanho inválido");
		}
		
		return calorias;
	}
	
	public int tamanhoCardapio() {
		return itens.length;
	}
	
	public Item pesquisaItem(String nome) {
		for(Item i : itens) {
			if(i.getNome().equals(nome)) {
				return i;
			}
		}
		
		return null;
	}
	
	private Item[] criaListaPadrao() {
		this.itens = new Item[5];
		
		itens[0] = new Item("Arroz", 100);
		itens[1] = new Item("Feijão", 100);
		itens[2] = new Item("Farofa", 100);
		itens[3] = new Item("Macarrão", 100);
		itens[4] = new Item("Suco", 100);
		
		return itens;
	}
}
