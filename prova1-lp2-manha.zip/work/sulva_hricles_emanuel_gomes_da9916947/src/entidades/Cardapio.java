package entidades;

public class Cardapio {
	private String nome;
	private Item[] itens;
	int pos = 0;

	public Cardapio(String nome) {
		this.nome = nome;
		this.itens = new Item[5];
	}

	public Cardapio(String nome, int numItens) {
		this.nome = nome;
		this.itens = new Item[numItens];
	}

	private Item procuraItem(String nome) {
		for (Item i : itens) {
			if (i != null && i.getNome().equals(nome)) {
				return i;
			}
		}
		throw new IllegalArgumentException("Objeto não existe");
	}

	public void adicionaItem(Item item) {
		if (pos == itens.length) {
			throw new ArrayIndexOutOfBoundsException("Limite Atingido");
		}
		this.itens[pos] = item;
		pos++;
	}

	public String listaCardapio() {
		String retorno = this.nome + System.lineSeparator();
		for (int i = 0; i < itens.length; i++) {
			if (itens[i] != null) {
				retorno += i + 1 + " - " + itens[i].toString() + System.lineSeparator();
			}
		}
		return retorno;
	}

	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		int calorias = 0;
		for (String i : refeicao) {
			calorias += procuraItem(i).getCalorias();
		}

		switch (tamanhoRefeicao) {
		case "mega":
			return calorias * 3;
		case "grande":
			return calorias * 2;
		default:
			return calorias;
		}
	}

	public Item[] getItens() {
		return itens;
	}

	
}
