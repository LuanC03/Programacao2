package entidades;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CardapioTest {
	private final String NL = System.lineSeparator();
	Cardapio cardapio;
	Item i1, i2;

	@Before
	public void criaCardapio() {
		cardapio = new Cardapio("Ilha");
		i1 = new Item("coxinha", 150);
		i2 = new Item("coxão", 200);
		cardapio.adicionaItem(i1);

	}

	@Test
	public void testAdicionaItem() {
		assertEquals(i1, cardapio.getItens()[0]);
		cardapio.adicionaItem(i2);
		assertEquals(i2, cardapio.getItens()[1]);
	}

	@Test
	public void testContrutorNumPadrao() {
		assertEquals(5, cardapio.getItens().length);
	}

	@Test
	public void testConstrutorNumItens() {
		Cardapio grandao = new Cardapio("7 itens", 7);
		assertEquals(7, grandao.getItens().length);
	}

	@Test
	public void testlistaCardapio() {
		assertEquals("Ilha" + NL + "1 - coxinha - 150 calorias." + NL, cardapio.listaCardapio());
		Item i2 = new Item("coxão", 200);
		cardapio.adicionaItem(i2);
		assertEquals("Ilha" + NL + "1 - coxinha - 150 calorias." + NL + "2 - coxão - 200 calorias." + NL,
				cardapio.listaCardapio());

	}

	@Test
	public void testCalcularCaloriasRefeicao() {
		String[] refeicao = { "coxinha", "coxão" };
		cardapio.adicionaItem(i2);
		assertEquals(350, cardapio.calcularCaloriasRefeicao(refeicao, "padrão"));
		assertEquals(700, cardapio.calcularCaloriasRefeicao(refeicao, "grande"));
		assertEquals(1050, cardapio.calcularCaloriasRefeicao(refeicao, "mega"));
	}

	@Test(expected = ArrayIndexOutOfBoundsException.class)
	public void testAdicionaItemInvalido() {
		cardapio.adicionaItem(i2);
		cardapio.adicionaItem(i2);
		cardapio.adicionaItem(i2);
		cardapio.adicionaItem(i2);
		cardapio.adicionaItem(i2);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testProcuraItemNaoExistente() {
		cardapio.calcularCaloriasRefeicao(new String[] { "coxinha", "coxão" }, "mega");
	}
}
