package Prova1;

import java.util.Arrays;

public class Cardapio {
	private String nome;
	private Item[] itens;

	public Cardapio(String nome, int qtdItens) {
		this.nome = nome;
		this.itens = new Item[qtdItens];
	}

	public Cardapio(String nome) {
		new Cardapio(nome, 5);
	}

	public void adicionaItem(Item item) {
		for (int i = 0; i < this.itens.length; i++) {
			if (this.itens[i] == null) {
				this.itens[i] = item;
				break;
			}
		}
	}

	public String listaCardapio() {
		String aux = "";
		for (int i = 0; i < this.itens.length; i++) {
			if (this.itens[i] != null) {
				aux += "" + (i + 1) + " - " + this.itens[i].toString() + "\n";
			}
		}
		return aux;

	}

	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		verificaRefeicaoInvalida(refeicao);
		int totalCalorico = 0;
		for (int i = 0; i < refeicao.length; i++) {
			totalCalorico += this.itens[encontraRefeicao(refeicao[i])].getCalorias();
		}

		return caloriasTamanho(totalCalorico, tamanhoRefeicao);

	}

	private int caloriasTamanho(int totalCalorico, String tamanho) {
		if (tamanho.equals("grande")) {
			return totalCalorico * 2;
		} else {
			if (tamanho.equals("mega")) {
				return totalCalorico * 3;
			} else {
				return totalCalorico;
			}
		}
	}

	private int encontraRefeicao(String refeicao) {
		for (int i = 0; i < this.itens.length; i++) {
			if (this.itens[i].getNome().equals(refeicao)) {
				return i;
			}
		}
		return 0;
	}

	private boolean pertenceItens(String item) {
		for (int i = 0; i < this.itens.length; i++) {
			if (this.itens[i] != null) {
				if (this.itens[i].getNome().equals(item)) {
					return true;
				}
			}
		}

		return false;
	}

	private void verificaRefeicaoInvalida(String[] refeicao) {
		for (int i = 0; i < refeicao.length; i++) {
			if (!pertenceItens(refeicao[i])) {
				throw new IllegalArgumentException();
			}

		}

	}

	@Override
	public String toString() {
		return "Cardapio [nome=" + nome + ", itens=" + Arrays.toString(itens) + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(itens);
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cardapio other = (Cardapio) obj;
		if (!Arrays.equals(itens, other.itens))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		return true;
	}

}
