package Prova1;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCardapio {

	@Test
	public void testConstrutor() {
		new Cardapio("Seu Olavo", 20);
	}

	@Test
	public void testaConstrutor() {
		new Cardapio("Seu Olavo");
	}

	@Test
	public void testaAdicionaItem() {
		Item i = new Item("Arroz Branco", 120);
		Cardapio c = new Cardapio("Seu Olavo", 20);
		c.adicionaItem(i);
		assertEquals("1 - Arroz Branco - 120 calorias/porção" + "\n", c.listaCardapio());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testaCardapioIlegal() {
		Cardapio c = new Cardapio("Seu Olavo", 20);
		Item sanduiche = new Item("sanduiche", 300);
		Item bolo = new Item("bolo", 200);
		c.adicionaItem(bolo);
		c.adicionaItem(sanduiche);
		String[] refeicao = { "bolo", "sanduiche", "arroz branco" };
		c.calcularCaloriasRefeicao(refeicao, "padrão");
	}

	@Test
	public void testaCalculoCaloriasPadrao() {
		Cardapio c = new Cardapio("Seu Olavo", 20);
		Item sanduiche = new Item("sanduiche", 300);
		Item bolo = new Item("bolo", 200);
		c.adicionaItem(bolo);
		c.adicionaItem(sanduiche);
		String[] refeicao = { "bolo", "sanduiche" };
		assertEquals(500, c.calcularCaloriasRefeicao(refeicao, "padrao"));
	}

	@Test
	public void testaCalculoCaloriasGrande() {
		Cardapio c = new Cardapio("Seu Olavo", 20);
		Item sanduiche = new Item("sanduiche", 300);
		Item bolo = new Item("bolo", 200);
		c.adicionaItem(bolo);
		c.adicionaItem(sanduiche);
		String[] refeicao = { "bolo", "sanduiche" };
		assertEquals(1000, c.calcularCaloriasRefeicao(refeicao, "grande"));
	}

	@Test
	public void testaCalculoCaloriasMega() {
		Cardapio c = new Cardapio("Seu Olavo", 20);
		Item sanduiche = new Item("sanduiche", 300);
		Item bolo = new Item("bolo", 200);
		c.adicionaItem(bolo);
		c.adicionaItem(sanduiche);
		String[] refeicao = { "bolo", "sanduiche" };
		assertEquals(1500, c.calcularCaloriasRefeicao(refeicao, "mega"));
	}

	@Test
	public void testaListagem() {
		Cardapio c = new Cardapio("Seu Olavo", 20);
		Item sanduiche = new Item("sanduiche", 300);
		Item bolo = new Item("bolo", 200);
		c.adicionaItem(bolo);
		c.adicionaItem(sanduiche);
		assertEquals("1 - bolo - 200 calorias/porção" + "\n" + "2 - sanduiche - 300 calorias/porção" + "\n",
				c.listaCardapio());
	}
	
	@Test
	public void TestEquals() {
		Cardapio c = new Cardapio("Seu olavo",20);
		Cardapio d = new Cardapio("Seu olavo",20);
		Item bolo = new Item("bolo",200);
		c.adicionaItem(bolo);
		d.adicionaItem(bolo);
		assertEquals(c,d);
		
		
	}
	

}
