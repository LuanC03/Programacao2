
public class CardapioVirtual {
	
	private ItensCardapio cardapio[];
	private int contador;
	
	public CardapioVirtual(String estabelecimento, int quantItens) {
		if (quantItens == 0) {
			throw new NullPointerException();
		}
		if (estabelecimento == null) {
			throw new NullPointerException();
		}
		this.cardapio = new ItensCardapio[quantItens];
	}
	
	public void adicionaItem(ItensCardapio item) {
		if (item == null) {
			throw new NullPointerException();
		}
		this.cardapio[contador++] = item;
	}
	
	public String listaCardapio() {
		String listagem = "";
		for (int i = 0; i < cardapio.length; i++) {
			if (cardapio[i] != null) {
				int numeracao = i + 1;
				listagem += numeracao + " " + cardapio[i] + "/n";
			}
		}
		return listagem;
	}
	
	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		int totalCalorias = 0;
		for (int i = 0; i < refeicao.length; i++) {
			if (refeicao[i].equals("arroz branco")) {
				totalCalorias += 100;
			} else if (refeicao[i].equals("arroz a grega")) {
				totalCalorias += 200;
			} else if (refeicao[i].equals("macarrao")) {
				totalCalorias += 200;
			} else if (refeicao[i].equals("feijoada")) {
				totalCalorias += 150;
			} else if (refeicao[i].equals("feijao verde")) {
				totalCalorias += 90;
			} else if (refeicao[i].equals("frango assado")) {
				totalCalorias += 90;
			} else if (refeicao[i].equals("bife")) {
				totalCalorias += 100;
			} else if (refeicao[i].equals("vinagrete")){
				totalCalorias += 0;
			} else {
				throw new IllegalArgumentException();
			}
		}	
		if (tamanhoRefeicao.equals("grande")) {
			totalCalorias *= 2;
		} else if (tamanhoRefeicao.equals("mega")) {
			totalCalorias *= 3;
		} else {
			totalCalorias *= 1;
		}
		return totalCalorias;	
	}
	

}
