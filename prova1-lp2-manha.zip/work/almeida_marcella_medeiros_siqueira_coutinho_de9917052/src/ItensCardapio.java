
public class ItensCardapio {
	
	private String comida;
	private int calorias;
	
	public ItensCardapio(String comida, int calorias) {
		this.comida = comida;
		this.calorias = calorias;
	}
	
	public void setComida(String comida) {
		this.comida = comida;
	}
	
	public String getComida() {
		return this.comida;
	}
	
	public void setCalorias(int calorias) {
		this.calorias = calorias;
	}
	
	public int getCalorias() {
		return this.calorias;
	}
	
	@Override
	public String toString() {
		return "O item escolhido foi " + comida + " e sua quantidade de calorias é de " + calorias;
	}
	
	public boolean equals(Object obj) {
		if (this.comida == ((ItensCardapio) obj).getComida()) {
			return true;
		} else {
			return false;
		}
	}
	

}
