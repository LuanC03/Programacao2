import static org.junit.Assert.*;

import org.junit.Test;

public class CardapioVirtualTest {

	@Test
	public void listaCardapioTest() {
		CardapioVirtual cardapio = new CardapioVirtual("Amarelinha", 3);
		ItensCardapio item1 = new ItensCardapio("arroz branco", 100);
		ItensCardapio item2 = new ItensCardapio("feijao verde", 90);
		ItensCardapio item3 = new ItensCardapio("bife", 100);
		cardapio.adicionaItem(item1);
		cardapio.adicionaItem(item2);
		cardapio.adicionaItem(item3);
		cardapio.listaCardapio();		
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void comidaInexistente() {
		CardapioVirtual cardapio = new CardapioVirtual("Dona Inês", 3);
		String[] refeicao = {"arroz branco", "caviar", "carne de sol"};
		String tamanhoRefeicao = "mega";
		cardapio.calcularCaloriasRefeicao(refeicao, tamanhoRefeicao);
		fail("O item pedido não existe no cardápio.");
	}
	
	@Test (expected = NullPointerException.class)
	public void quantItensNull() {
		CardapioVirtual cardapio = new CardapioVirtual("Seu Olavo", 0);
		fail("O número de itens no cardápio é inválido.");
	}
	
	@Test (expected = NullPointerException.class)
	public void estabeleciomentoNull() {
		CardapioVirtual cardapio = new CardapioVirtual(null, 3);
		fail("O nome do estabelecimento é inválido.");
	}
	
	@Test (expected = NullPointerException.class)
	public void adicionaItensNull() {
		CardapioVirtual cardapio = new CardapioVirtual("Anel", 2);
		cardapio.adicionaItem(null);
		fail("O item a ser adicionado é inválido.");
	}
	
	

	

}
