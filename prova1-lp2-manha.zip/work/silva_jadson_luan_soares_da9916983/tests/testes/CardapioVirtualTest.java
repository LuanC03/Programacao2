package testes;

import org.junit.*;
import static org.junit.Assert.*;
import classes.CardapioVirtual;
import classes.Item;

public class CardapioVirtualTest {
	private CardapioVirtual cardapio;
	private CardapioVirtual cardapio2;
	
	@Before
	public void criarCardapio() {
		this.cardapio = new CardapioVirtual("Neto Lanches", 7);
		cardapio.adicionaItem(new Item("arroz branco", 100));
		cardapio.adicionaItem(new Item("arroz preto", 80));
		cardapio.adicionaItem(new Item("arroz azul", 80));
		cardapio.adicionaItem(new Item("arroz verde", 80));
		cardapio.adicionaItem(new Item("arroz rosa", 100));
		cardapio.adicionaItem(new Item("arroz amarelo", 100));

		this.cardapio2 = new CardapioVirtual("Neto Lanches");
		cardapio2.adicionaItem(new Item("arroz branco", 100));
		cardapio2.adicionaItem(new Item("feijoada", 150));
	}
	
	@Test
	public void testAdicionaItemMax5() {
		assertTrue(cardapio2.adicionaItem(new Item("arroz preto", 80)));
		assertTrue(cardapio2.adicionaItem(new Item("arroz preto", 80)));
		assertTrue(cardapio2.adicionaItem(new Item("arroz preto", 80)));
		
		// Excede a capacidade máxima (5).
		assertFalse(cardapio2.adicionaItem(new Item("arroz preto", 80)));
	}
	
	@Test
	public void testAdicionaItemMaxDeterminado() {
		assertTrue(cardapio.adicionaItem(new Item("arroz roxo", 100)));
		
		// Excede a capacidade máxima (7).
		assertFalse(cardapio.adicionaItem(new Item("arroz lilas", 80)));
	}
	
	@Test
	public void testCalculaCaloriasRefeicao() {
		String[] refeicao = {"arroz branco", "feijoada"};
		
		int totalP = cardapio2.calcularCaloriasRefeicao(refeicao, "padrão");
		assertEquals(totalP, 250);
		
		int totalG = cardapio2.calcularCaloriasRefeicao(refeicao, "grande");
		assertEquals(totalG, 500);
		
		int totalM = cardapio2.calcularCaloriasRefeicao(refeicao, "mega");
		assertEquals(totalM, 750);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testCalculaCaloriasRefeicaoInvalida() {
		String[] refeicaoInvalida = {"arroz branco", "farofa"};
		cardapio2.calcularCaloriasRefeicao(refeicaoInvalida, "mega");
	}
	
	@Test
	public void testListaCardapio() {
		String representacao = "1 - arroz branco - 100 calorias/porção";
		representacao += "\n";
		representacao += "2 - feijoada - 150 calorias/porção";
		
		assertEquals(representacao, cardapio2.listaCardapio());
	}
}
