package classes;

/**
 * Representa um cardápio virtual. Possui o nome do estabelecimento e uma lista
 * de itens cadastrados.
 * 
 * @author Jadson Luan Soares da Silva, 117110391
 */
public class CardapioVirtual {
	private String estabelecimento;
	private Item[] itens;
	private int numItens;

	/**
	 * Constrói um cardápio virtual que será iniciado com nome do estabelecimento e
	 * capacidade de armazenamento (de itens) especificada.
	 * 
	 * @param estabelecimento
	 *            String: nome do estabelecimento a qual o cardápio pertence.
	 * @param numItens
	 *            int: número de itens do cardápio virtual.
	 */
	public CardapioVirtual(String estabelecimento) {
		this(estabelecimento, 5);
	}

	/**
	 * Constrói um cardápio virtual que será iniciado com nome do estabelecimento e
	 * e com espaço padrão para armazenar cinco itens no cardápio.
	 * 
	 * @param estabelecimento
	 *            String: nome do estabelecimento a qual o cardápio pertence.
	 * @param capacidade
	 *            int: número de itens do cardápio virtual.
	 */
	public CardapioVirtual(String estabelecimento, int capacidade) {
		this.estabelecimento = estabelecimento;
		this.itens = new Item[capacidade];
		this.numItens = 0;
	}

	/**
	 * Adiciona um item ao cardápio se ele não estiver cheio.
	 * 
	 * @param item
	 *            Item: o item a ser adicionado ao cardápio.
	 * @return true, caso o item seja adicionado com sucesso. Caso contrário,
	 *         retornará false (Caso a capacidade máxima do cardápio tenha sido
	 *         atingida.)
	 */
	public boolean adicionaItem(Item item) {
		if (numItens < itens.length) {
			itens[numItens] = item;
			numItens++;
			return true;
		}

		return false;
	}

	/**
	 * Representação textual dos itens do cardápio numerados pela ordem de inserção
	 * no mesmo.
	 * 
	 * @return uma string onde cada linha representa um item do cardápio.
	 */
	public String listaCardapio() {
		String cardapio = "";

		for (int i = 0; i < numItens; i++) {
			cardapio += (i + 1) + " - ";
			cardapio += itens[i].toString();

			if (i != numItens - 1)
				cardapio += ("\n");
		}

		return cardapio;
	}

	/**
	 * Calcula a quantidade total de uma refeição.
	 * 
	 * @param refeicao
	 *            String[]: um array com os nomes das refeições
	 * @param tamanhoRefeicao
	 *            String: o tamanho da refeição (padrão, grande ou mega)
	 * @return um inteiro que representa a quantidade total de calorias de uma
	 *         refeição (soma das calorias de cada refeição vezes o tamanho da
	 *         refeição (1 para padrão, 2 para grande e 3 para mega)
	 */
	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		int caloriasTotal = 0;

		for (int i = 0; i < refeicao.length; i++) {
			String refeicaoAtual = refeicao[i];
			boolean noCardapio = false;

			for (int j = 0; j < numItens; j++) {
				Item item = itens[j];

				if (item.getNome().equals(refeicaoAtual)) {
					noCardapio = true;
					caloriasTotal += item.getCaloriasPorPorcao();
				}
			}

			if (!noCardapio)
				throw new IllegalArgumentException("Item da refeição desconhecido.");
		}

		int tamanhoPorcao = 0;

		switch (tamanhoRefeicao.toLowerCase()) {
		case "grande":
			tamanhoPorcao = 2;
			break;
		case "mega":
			tamanhoPorcao = 3;
			break;

		case "padrão":
		default:
			tamanhoPorcao = 1;
			break;
		}

		return caloriasTotal * tamanhoPorcao;
	}
}
