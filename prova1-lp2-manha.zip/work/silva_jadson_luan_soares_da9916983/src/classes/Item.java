package classes;

/**
 * Representa um item do cardápio. Possui um nome e a quantidade de calorias por
 * porção.
 * 
 * @author Jadson Luan Soares da Silva, 117110391
 */
public class Item {
	private String nome;
	private int caloriasPorPorcao;

	/**
	 * Constrói um item inicializados com os dados (nome, caloriasPorPorcao)
	 * passados como parâmetros.
	 * 
	 * @param nome
	 *            String: representação do nome desse item. 
	 * @param caloriasPorPorcao
	 *            int: quantidade de calorias por porção desse item.
	 */
	public Item(String nome, int caloriasPorPorcao) {
		this.verificacoes(nome, caloriasPorPorcao);
		this.nome = nome;
		this.caloriasPorPorcao = caloriasPorPorcao;
	}

	private void verificacoes(String nome, int caloriasPorPorcao) {
		if (nome == null)
			throw new NullPointerException();
	}

	/**
	 * Verifica se dois objetos são iguais baseados nos seguintes parâmetros: um não
	 * ser nulo, serem da mesma classe e possuirem o mesmo nome.
	 * 
	 * @return true, caso sejam iguais. Caso contrário, retornará false.
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}

		if (obj.getClass() != this.getClass()) {
			return false;
		}

		Item other = (Item) obj;
		return other.nome.equals(this.nome);
	}

	/**
	 * Representação textual de um Item baseado em seu nome e sua quantidade de
	 * calorias por porção.
	 * 
	 * @return uma string no formato "(nome) - (caloriasPorPorcao) calorias/porção"
	 */
	@Override
	public String toString() {
		return nome + " - " + caloriasPorPorcao + " calorias/porção";
	}
	
	public String getNome() {
		return nome;
	}
	
	public int getCaloriasPorPorcao() {
		return caloriasPorPorcao;
	}
}
