package testes;

import static org.junit.Assert.*;
import org.junit.Test;
import cardapio.CardapioVirtual;
import cardapio.Item;

public class CardapioTeste {

	@Test
	public void cadastrarCardapioPadrao() {
		CardapioVirtual cardapio = new CardapioVirtual("Cantina 1");
		assertEquals(cardapio.toString(), "Cantina 1 - 5 itens");
	}
	
	@Test
	public void cadastrarCardapioFlexivel() {
		CardapioVirtual cardapio = new CardapioVirtual("Cantina 2", 8);
		assertEquals(cardapio.toString(), "Cantina 2 - 8 itens");
	}
	
	@Test
	public void cadastrarItens() {
		CardapioVirtual cardapio = new CardapioVirtual("Cantina 3", 3);
		cardapio.adicionaItem(new Item("arroz branco", 100));
		cardapio.adicionaItem(new Item("arroz a grega", 200));
		cardapio.adicionaItem(new Item("macarrao", 200));
		
		String retornoEsperado = "1 - arroz branco - 100 calorias/porção\n"
				+ "2 - arroz a grega - 200 calorias/porção\n"
				+ "3 - macarrao - 200 calorias/porção\n";
		
		assertEquals(cardapio.listarCardapio(), retornoEsperado);
	}

	@Test
	public void calcularCalorias1() {
		CardapioVirtual cardapio = new CardapioVirtual("Cantina 3", 3);
		cardapio.adicionaItem(new Item("arroz branco", 100));
		cardapio.adicionaItem(new Item("feijoada", 150));
		cardapio.adicionaItem(new Item("vinagrete", 0));
		
		String[] refeicao = {"arroz branco", "feijoada", "vinagrete"};
		assertEquals(cardapio.calcularCaloriasRefeicao(refeicao, "grande"), 500);
	}
	
	@Test
	public void calcularCalorias2() {
		CardapioVirtual cardapio = new CardapioVirtual("Cantina 3", 3);
		cardapio.adicionaItem(new Item("arroz branco", 100));
		cardapio.adicionaItem(new Item("feijoada", 150));
		cardapio.adicionaItem(new Item("frango assado", 90));
		
		String[] refeicao = {"arroz branco", "feijoada", "frango assado"};
		assertEquals(cardapio.calcularCaloriasRefeicao(refeicao, "mega"), 1020);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void calcularCaloriasItemInvalido() {
		CardapioVirtual cardapio = new CardapioVirtual("Cantina 3", 3);
		cardapio.adicionaItem(new Item("arroz branco", 100));
		cardapio.adicionaItem(new Item("feijoada", 150));
		cardapio.adicionaItem(new Item("vinagrete", 0));
		
		String[] refeicao = {"arroz branco", "feijoada", "frango assado"};
		cardapio.calcularCaloriasRefeicao(refeicao, "grande");
	}
	
	@Test
	public void itensIguais() {
		Item item1 = new Item("arroz branco", 100);
		Item item2 = new Item("arroz branco", 130);
		assert(item1.equals(item2));
	}
	
}
