package cardapio;

public class CardapioVirtual {

	private String nomeEstabelecimento;
	private Item[] itens;
	
	public CardapioVirtual(String nomeEstabelecimento) {
		this.nomeEstabelecimento = nomeEstabelecimento;
		itens = new Item[5];
	}
	
	public CardapioVirtual(String nome, int qtdItens) {
		this(nome);
		itens = new Item[qtdItens];
	}
	
	public void adicionaItem(Item item) {
		int indice = 0;
		boolean adicionado = false;
		while (indice < itens.length && !adicionado) {
			if (itens[indice] == null) {
				itens[indice] = new Item(item.getNome(), item.getCalorias());
				adicionado = true;
			}
			indice++;
		}
	}
	
	public String listarCardapio() {
		String listagem = "";
		for (int i = 0; i < itens.length; i++) {
			listagem += i+1 + " - " + itens[i].toString() + "\n";
		}
		return listagem;
	}
	
	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		int somaCalorias = 0;
		for (int i = 0; i < refeicao.length; i++) {
			boolean itemEncontrado = false;
			for (int j = 0; j < itens.length; j++) {
				if(itens[j] != null) {
					if(itens[j].getNome().equals(refeicao[i])) {
						somaCalorias += itens[j].getCalorias();
						itemEncontrado = true;
					}
				}
			}
			if (!itemEncontrado) {
				throw new IllegalArgumentException("Nome desconhecido: " + refeicao[i]);
			}
		}
		
		if (tamanhoRefeicao.equals("grande")) {
			somaCalorias *= 2;
		}
		else if(tamanhoRefeicao.equals("mega")) {
			somaCalorias *= 3;
		}
		
		return somaCalorias;
	}

	@Override
	public String toString() {
		return nomeEstabelecimento + " - " + itens.length + " itens";
	}
	
}