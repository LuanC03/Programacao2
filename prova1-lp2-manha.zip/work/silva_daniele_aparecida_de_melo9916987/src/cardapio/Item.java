package cardapio;

public class Item {

	private String nome;
	private int caloriasPorcao;
	
	public Item(String nome, int caloriasPorcao) {
		this.nome = nome;
		this.caloriasPorcao = caloriasPorcao;
	}
	
	public String getNome() {
		return nome;
	}
	
	public int getCalorias() {
		return caloriasPorcao;
	}
	
	public void setCalorias(int novaCaloria) {
		this.caloriasPorcao = novaCaloria;
	}

	@Override
	public String toString() {
		return nome + " - " + caloriasPorcao + " calorias/porção";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if(this.getClass() != obj.getClass()) {
			return false;
		}
		
		Item item = (Item) obj;
		if(this.nome != null && item.nome == null) {
			return false;
		}
		if(this.nome == null && item.nome != null) {
			return false;
		}
		if(!this.nome.equals(item.nome)) {
			return false;
		}
		
		return true;
	}
	
}
