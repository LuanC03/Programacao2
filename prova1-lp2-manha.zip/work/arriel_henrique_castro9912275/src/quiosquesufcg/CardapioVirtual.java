package quiosquesufcg;

import java.util.Arrays;

public class CardapioVirtual {
	private String nomeEstabelecimento;
	private ItemCardapio[] cardapio;
	private int qtdItens;

	public CardapioVirtual(String nome) {
		this.nomeEstabelecimento = nome;
		this.cardapio = new ItemCardapio[5];
	}

	public CardapioVirtual(String nome, int qtdItens) {
		this.nomeEstabelecimento = nome;
		this.cardapio = new ItemCardapio[qtdItens];
	}

	public void adicionaItem(ItemCardapio item) {
		if (qtdItens < cardapio.length) {
			this.cardapio[qtdItens] = item;
			qtdItens++;
		}

	}

	public String listaCardapio() {
		String lista = "";
		for (int i = 0; i < this.qtdItens; i++) {
			lista += (i + 1) + " - " + cardapio[i].toString() + System.lineSeparator();
		}
		return lista;
	}

	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		int soma = 0;
		for (int i = 0; i < refeicao.length; i++) {
			boolean verificador = false;
			for (int j = 0; j < this.qtdItens; j++) {
				if (refeicao[i].equals(this.cardapio[j].getNome())) {
					soma += cardapio[j].getCalorias();
					verificador = true;
				}
			}
			if (verificador == false) {
				throw new IllegalArgumentException();
			}
		}

		return total(soma, tamanhoRefeicao);

	}

	private int total(int soma, String tamanhoRefeicao) {
		if (tamanhoRefeicao.equals("padrao")) {
			return soma;
		} else if (tamanhoRefeicao.equals("grande")) {
			return soma * 2;
		} else {
			return soma * 3;
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(cardapio);
		result = prime * result + ((nomeEstabelecimento == null) ? 0 : nomeEstabelecimento.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CardapioVirtual other = (CardapioVirtual) obj;
		if (!Arrays.equals(cardapio, other.cardapio))
			return false;
		if (nomeEstabelecimento == null) {
			if (other.nomeEstabelecimento != null)
				return false;
		} else if (!nomeEstabelecimento.equals(other.nomeEstabelecimento))
			return false;
		return true;
	}

}
