package testes;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import quiosquesufcg.*;

public class CardapioVirtualTest {
	private CardapioVirtual cardapioTeste;
	private ItemCardapio feijao;
	private ItemCardapio arroz;

	@Before
	public void criaCardapioVirtual() {
		cardapioTeste = new CardapioVirtual("Cantina");
		feijao = new ItemCardapio("feijao", 100);
		arroz = new ItemCardapio("arroz", 50);
		cardapioTeste.adicionaItem(feijao);
		cardapioTeste.adicionaItem(arroz);

	}

	@Test
	public void listaCardapio() {
		assertEquals("1 - feijao - 100 calorias/porcao" + System.lineSeparator() + "2 - arroz - 50 calorias/porcao"
				+ System.lineSeparator(), cardapioTeste.listaCardapio());

	}

	@Test
	public void CardapioCheio() {
		CardapioVirtual cardapioCheio = new CardapioVirtual("Cantina2", 1);
		cardapioCheio.adicionaItem(arroz);
		// Não adiciona o item caso o cardápio esteja cheio.
		cardapioCheio.adicionaItem(feijao);
		assertEquals("1 - arroz - 50 calorias/porcao" + System.lineSeparator(), cardapioCheio.listaCardapio());

	}

	@Test
	public void testcalcularCaloriasRefeicao() {
		String[] refeicao = { "arroz", "feijao" };
		assertEquals(150, cardapioTeste.calcularCaloriasRefeicao(refeicao, "padrao"));
		assertEquals(300, cardapioTeste.calcularCaloriasRefeicao(refeicao, "grande"));
		assertEquals(450, cardapioTeste.calcularCaloriasRefeicao(refeicao, "mega"));

	}

	@Test
	public void testEquals() {
		CardapioVirtual cardapioDoido = new CardapioVirtual("Cantina");
		assertFalse(cardapioTeste.equals(cardapioDoido));
		cardapioDoido.adicionaItem(feijao);
		cardapioDoido.adicionaItem(arroz);
		assertTrue(cardapioTeste.equals(cardapioDoido));

	}

	@Test
	public void testHashcode() {
		CardapioVirtual cardapioDoido = new CardapioVirtual("Cantina");
		assertFalse(cardapioTeste.hashCode() == cardapioDoido.hashCode());
		cardapioDoido.adicionaItem(feijao);
		cardapioDoido.adicionaItem(arroz);
		assertTrue(cardapioTeste.hashCode() == cardapioDoido.hashCode());

	}

	@Test(expected = IllegalArgumentException.class)
	public void testCalcularCaloriasRefeicaoException() {
		String[] refeicao = { "arroz", "batatinha" };
		cardapioTeste.calcularCaloriasRefeicao(refeicao, "padrao");

	}

}
