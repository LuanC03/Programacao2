package prova;

public class Cardapio {
	private String nomeEstabelecimento;
	private Item[] itens;
	private int numeroDeItens, itensArmazenados;
	
	public Cardapio(String nome, int numero) {
		if(nome == null) {
			throw new NullPointerException();
		}
		if(numero < 1) {
			throw new IllegalArgumentException();
		}
		if(nome.trim().equals("")) {
			throw new IllegalArgumentException();
		}
		this.nomeEstabelecimento = nome;
		this.numeroDeItens = numero;
		this.itensArmazenados = 0;
		this.itens = new Item[numeroDeItens];
	}
	
	public Cardapio(String nome) {
		if(nome == null) {
			throw new NullPointerException();
		}
		if(nome.trim().equals("")) {
			throw new IllegalArgumentException();
		}
		this.nomeEstabelecimento = nome;
		this.numeroDeItens = 5;
		this.itensArmazenados = 0;
		this.itens = new Item[numeroDeItens];
	}
	
	public void adicionaItem(Item item) {
		if(item == null) {
			throw new NullPointerException();
		}
		this.itens[itensArmazenados] = item;
		itensArmazenados += 1;
	}
	
	public String listaCardapio() {
		String lista = "";
		for(int i = 0; i < numeroDeItens; i++) {
			if(itens[i] == null) {
				break;
			}
			lista = lista + (i+1) + " - " + itens[i].getNome() + " - " + itens[i].getCalorias() + " calorias/porção\n";
		}
		return lista;
	}
	
	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		int totalDeCalorias = 0, multiplicador;
		boolean itemConhecido = false;
		if(tamanhoRefeicao == null) {
			throw new NullPointerException("Tamanho passado como null");
		}
		if(tamanhoRefeicao.trim().equals("")) {
			throw new IllegalArgumentException();
		}
		if(tamanhoRefeicao.equals("padrão")) {
			multiplicador = 1;
		}else if(tamanhoRefeicao.equals("grande")) {
			multiplicador = 2;
		}else if(tamanhoRefeicao.equals("mega")) {
			multiplicador = 3;
		}else {
			throw new IllegalArgumentException("Tamanho de refeicao inválido.");
		}
		for(int j = 0; j < refeicao.length; j++) {
			itemConhecido = false;
			for(int k = 0; k < numeroDeItens; k++) {
				if(itens[k] == null) {
					break;
				}
				if(refeicao[j].equals(itens[k].getNome())) {
					totalDeCalorias += itens[k].getCalorias();
					itemConhecido = true;
				}
			}
			if(itemConhecido == false) {
				throw new IllegalArgumentException("Array de refeições inválido..");
			}
		}
		totalDeCalorias *= multiplicador;
		return totalDeCalorias;
	}
}
