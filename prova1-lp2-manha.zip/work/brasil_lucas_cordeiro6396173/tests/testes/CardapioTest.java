package testes;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import prova.Cardapio;
import prova.Item;

public class CardapioTest {

	private Cardapio cardapioTeste;
	private Item itemTeste1, itemTeste2, itemTeste3, itemTeste4, itemTeste5,itemTeste6;
	private String[] refeicaoTesteValido;
	private String[] refeicaoTesteInvalido;
	
	@Before
	public void criaCardapioTeste() {
		cardapioTeste = new Cardapio("Cardapio Teste");
		itemTeste1 = new Item("arroz branco", 100);
		itemTeste2 = new Item("arroz a grega", 200);
		itemTeste3 = new Item("macarrao", 200);
		itemTeste4 = new Item("feijoada", 150);
		itemTeste5 = new Item("feijao verde", 90);
		cardapioTeste.adicionaItem(itemTeste1);
		cardapioTeste.adicionaItem(itemTeste2);
		cardapioTeste.adicionaItem(itemTeste3);
		cardapioTeste.adicionaItem(itemTeste4);
		refeicaoTesteValido = new String[2];
		refeicaoTesteValido[0] = "arroz branco";
		refeicaoTesteValido[1] = "feijoada";
		refeicaoTesteInvalido = new String[2];
		refeicaoTesteInvalido[0] = "frango";
		refeicaoTesteInvalido[1] = "arroz branco";
	}

	@Test
	public void criaCardapioPassandoNumeroDeItens() {
		cardapioTeste = new Cardapio("Cardapio de Teste", 3);
		cardapioTeste.adicionaItem(itemTeste1);
		cardapioTeste.adicionaItem(itemTeste3);
		cardapioTeste.adicionaItem(itemTeste5);
		assertEquals(cardapioTeste.listaCardapio(), "1 - arroz branco - 100 calorias/porção\n2 - macarrao - 200 calorias/porção\n3 - feijao verde - 90 calorias/porção\n");
	}
	
	@Test(expected = NullPointerException.class)
	public void criaCardapioComNomeNullPassandoNumeroDeItens() {
		cardapioTeste = new Cardapio(null, 4);
	}

	@Test(expected = NullPointerException.class)
	public void criaCardapioComNomeNullSemPassarNumeroDeItens() {
		cardapioTeste = new Cardapio(null);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void criaCardapioComNumeroDeItensNegativo() {
		cardapioTeste = new Cardapio("Cardapio Teste", -1);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void criaCardapioComNumeroDeItensZero(){
		cardapioTeste = new Cardapio("Cardapio Teste", 0);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void criaCardapioComNomeDeEspacosSemPassarNumeroDeItens() {
		cardapioTeste = new Cardapio("  ");
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void criaCardapioComNomeDeEspacosPassandoNumeroDeItens() {
		cardapioTeste = new Cardapio("    ", 3);
	}
	
	@Test
	public void adicionaItemValido() {
		cardapioTeste.adicionaItem(itemTeste5);
		assertEquals(cardapioTeste.listaCardapio(),"1 - arroz branco - 100 calorias/porção\n2 - arroz a grega - 200 calorias/porção\n3 - macarrao - 200 calorias/porção\n4 - feijoada - 150 calorias/porção\n5 - feijao verde - 90 calorias/porção\n");
	}
	
	@Test(expected = NullPointerException.class)
	public void adicionaItemNaoCadastrado() {
		cardapioTeste.adicionaItem(itemTeste6);
	}
	
	@Test
	public void listaCardapioExistente() {
		assertEquals(cardapioTeste.listaCardapio(), "1 - arroz branco - 100 calorias/porção\n2 - arroz a grega - 200 calorias/porção\n3 - macarrao - 200 calorias/porção\n4 - feijoada - 150 calorias/porção\n");
	}
	
	@Test
	public void calculoDeCaloriasRefeicaoValida() {
		assertEquals(cardapioTeste.calcularCaloriasRefeicao(refeicaoTesteValido, "grande"), 500);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void calculoDeCaloriasRefeicaoInvalida() {
		cardapioTeste.calcularCaloriasRefeicao(refeicaoTesteInvalido, "grande");
	}
	
	@Test(expected = NullPointerException.class)
	public void calculoDeCaloriasTamanhoNull() {
		cardapioTeste.calcularCaloriasRefeicao(refeicaoTesteValido, null);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void calculoDeCaloriasTamanhoRefeicaoStringVazia() {
		cardapioTeste.calcularCaloriasRefeicao(refeicaoTesteValido, "   ");
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void calculoDeCaloriasTamanhoRefeicaoInvalido() {
		cardapioTeste.calcularCaloriasRefeicao(refeicaoTesteValido, "gigante");
	}
}
