package testes;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import menu.Cardapio;
import menu.Item;

public class CardapioTest {
	
	private Cardapio cardapio1;
	
	private Item item;
	
	@Before
	public void criaCardapioQQ() {
		this.cardapio1 = new Cardapio("Lanc. do Marcos", 7);
		Item arroz = new Item ("arroz", 250);
		Item feijao = new Item ("feijao", 325);
		Item batata1 = new Item ("batata frita", 300);
		Item xburger = new Item ("cheeseburger", 400);
		Item batata2 = new Item ("batata doce", 200);
		Item frango = new Item ("frango ao molho", 400);
		Item carne = new Item ("carne assada", 500);
		Item item = new Item ("prato qualquer", 250);
		cardapio1.adicionaItem(arroz);
		cardapio1.adicionaItem(feijao);
		cardapio1.adicionaItem(batata1);
		cardapio1.adicionaItem(batata2);
		cardapio1.adicionaItem(frango);
		cardapio1.adicionaItem(carne);
		cardapio1.adicionaItem(xburger);	
	}
	
	@Test
	public void CriaeAdicionaItens() {
		Cardapio cardapio2 = new Cardapio("Lanc. do Marcos", 7);
		Item arroz = new Item ("arroz", 250);
		Item feijao = new Item ("feijao", 325);
		Item batata1 = new Item ("batata frita", 300);
		Item xburger = new Item ("cheeseburger", 400);
		Item batata2 = new Item ("batata doce", 200);
		Item frango = new Item ("frango ao molho", 400);
		Item carne = new Item ("carne assada", 500);
		cardapio2.adicionaItem(arroz);
		cardapio2.adicionaItem(feijao);
		cardapio2.adicionaItem(batata1);
		cardapio2.adicionaItem(batata2);
		cardapio2.adicionaItem(frango);
		cardapio2.adicionaItem(carne);
		cardapio2.adicionaItem(xburger);	
	}

	@Test (expected=ArrayIndexOutOfBoundsException.class)
	public void testaAdItemForadoAlcance() {
		this.cardapio1.adicionaItem(item);
	}
	
	@Test
	public void listaCardapioTest() {
		assertEquals("1 - arroz - 250 calorias/porção\n2 - feijao - 325 calorias/porção\n3 - batata frita - 300 calorias/porção\n"
				+ "4 - batata doce - 200 calorias/porção\n5 - frango ao molho - 400 calorias/porção\n6 - carne assada - 500 calorias/porção\n"
				+ "7 - cheeseburger - 400 calorias/porção\n", cardapio1.listaCardapio());
	}
	
	@Test
	public void calcularCaloriasRefeicaoTest() {
		String[] refeicao = {"arroz", "feijao", "frango ao molho", "batata doce"};
		assertEquals(1175, cardapio1.calcularCaloriasRefeicao(refeicao));
	}
	
	@Test
	public void calcularCaloriasRefeicaoTestmega() {
		String[] refeicao = {"arroz", "feijao", "frango ao molho", "batata doce"};
		assertEquals(3 * 1175, cardapio1.calcularCaloriasRefeicao(refeicao, "mega"));
	}
	
	@Test (expected=IllegalArgumentException.class)
	public void calcularCaloriasEntradaInvalida() {
		String[] refeicao = {"arroz", "feijao", "frango a passarinha", "batata doce"};
		cardapio1.calcularCaloriasRefeicao(refeicao);
	}

}
