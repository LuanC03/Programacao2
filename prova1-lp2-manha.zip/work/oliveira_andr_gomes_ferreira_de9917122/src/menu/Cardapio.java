package menu;

public class Cardapio {
	
	private String nome;
	
	private int qtd;
	
	private int cont = 0;
	
	private Item[] menu;
	
	public Cardapio(String nome) {
		this(nome, 5);
	}
	
	public Cardapio(String nome, int qtdItens) {
		this.nome = nome;
		this.qtd = qtdItens;
		this.menu = new Item[qtd];
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public void adicionaItem(Item prato) {
		this.menu[cont] = prato;
		cont ++;
	}
	
	public String listaCardapio() {
		int indice = 0;
		String saida = "";
		for (Item i: menu) {
			if (i!=null) {
				indice ++;
				saida += indice + " - " +  i.toString() + "\n";
			}
		}
		return saida;
	}
	
	public int calcularCaloriasRefeicao(String [] refeicao) {
		return calcularCaloriasRefeicao(refeicao, "padrão");
	}
	
	public int calcularCaloriasRefeicao(String [] refeicao, String tamanhoRefeicao) {
		int mult;
		int somaCal = 0;
		boolean consta = false;
		switch (tamanhoRefeicao) {
		case "padrão":
			mult = 1;
			break;
		case "grande":
			mult = 2;
			break;
		case "mega":
			mult = 3;
			break;	
			default:
				mult = 1;
		}
		for (String i : refeicao) {
			consta = false;
			for (Item j : menu) {
				if (i.equals(j.getNome())) {
					somaCal += mult * j.getCalorias();
					consta = true;
					break;
				}
			}
			if(!consta) {
				throw new IllegalArgumentException();
			}
		}
		return somaCal;
	}
	
}
