package menu;

public class Item {
	
	private String nome;
	
	private int calorias;
	
	public Item(String nome, int calorias) {
		this.nome = nome;
		this.calorias = calorias;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public int getCalorias() {
		return this.calorias;
	}
	
	@Override
	public boolean equals(Object obj) {
		Item comparado = (Item) obj;
		if (comparado.nome == null) {
			return false;
		} else if (!this.getClass().equals(comparado.getClass())) {
			return false;
		} else if (this.nome.equals(comparado.nome)) {
			return true;
		} else {
			return false;
		}
	}
	
	@Override
	public String toString(){
		return nome + " - " + calorias + " calorias/porção";
	}
}
