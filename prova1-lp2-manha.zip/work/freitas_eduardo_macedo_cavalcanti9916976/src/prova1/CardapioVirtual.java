package prova1;

public class CardapioVirtual {
	
	private String nomeEstabelecimento;
	private Item[] itens = new Item[5];
	private int posicao;
	
	public CardapioVirtual(String nome) {
		this.nomeEstabelecimento = nome;
	}
	
	public CardapioVirtual(String nome, int quantidade) {
		this.nomeEstabelecimento = nome;
		this.itens = new Item[quantidade];
	}
	
	public void adicionaItem(Item item) {
		this.itens[this.posicao] = item;
		posicao ++;
	}
	
	public String listaCardapio() {
		String lista = "";
		for (int i = 0; i < itens.length; i++) {
			if (itens[i] != null) {
				lista += i+1 + " - " + itens[i].toString() + "\n";
			}
		}
		return lista;
	}
	
	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		
		if (!this.validaArrayRefeicao(refeicao)) {
			throw new IllegalArgumentException("A refeicao nao estah no cardapio!");
		}
		
		int soma = this.somaCalorias(refeicao,tamanhoRefeicao);
		
		if (tamanhoRefeicao.equals("grande")) {
			return soma*2;
		} else if (tamanhoRefeicao.equals("mega")) {
			return soma*3;
		} else {
			return soma;
		}
	}
	
	private int somaCalorias(String[] refeicao, String tamanhoRefeicao) {
		int soma = 0;
		for (int i = 0; i < refeicao.length; i++) {
			for (int j = 0; j < itens.length; j++) {
				if (this.itens[j] != null && refeicao[i].equals(itens[j].getNome())) {
					soma += itens[j].getCalorias();
					break;
				}
			}
			
		} 
		return soma;
	}
	
	private boolean validaArrayRefeicao(String[] refeicao) {
		boolean check = false;
		for (int i = 0; i < refeicao.length; i++) {
			for (int j = 0; j < itens.length; j++) {
				
				if (this.itens[j] != null && refeicao[i].equals(this.itens[j].getNome())) {
					check = true;
				}
			}
			if (!check) {
				return false;
			}
		} return true;
	}
	
	public Item[] getItens() {
		return this.itens;
	}
	
	public String getNomeEstabelecimento() {
		return this.nomeEstabelecimento;
	}
}
