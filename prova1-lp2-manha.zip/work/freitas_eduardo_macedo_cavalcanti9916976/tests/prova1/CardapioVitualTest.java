package prova1;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CardapioVitualTest {
	
	private CardapioVirtual cardapioSimples;
	private CardapioVirtual cardapioComposto;
	private Item item;
	
	@Before
	public void criaParadas() {
		this.cardapioSimples = new CardapioVirtual("Quitanda");
		
		this.cardapioComposto = new CardapioVirtual("Lanchonete", 10);
		
		this.item = new Item("Bananinha",10);
		
		this.cardapioSimples.adicionaItem(item);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void testRefeicaoInvalida() {
		String[] refeicao = {"arroz"};
		this.cardapioSimples.calcularCaloriasRefeicao(refeicao, "grande");
	}
	
	@Test 
	public void testAdicionaItem() {
		assertEquals(item,cardapioSimples.getItens()[0]);
	}
	
	@Test
	public void testListaCardapio() {
		Item item2 = new Item("Batata",20);
		this.cardapioSimples.adicionaItem(item2);
		assertEquals("1 - Bananinha 10.0\n2 - Batata 20.0\n",this.cardapioSimples.listaCardapio());
	}
	
	@Test
	public void testCalcularCaloriasRefeicaoGrande() {
		Item item2 = new Item("Batata",20);
		this.cardapioSimples.adicionaItem(item2);
		String[] refeicao = {"Bananinha","Batata"};
		assertEquals(60, this.cardapioSimples.calcularCaloriasRefeicao(refeicao, "grande"));
	}
	
	@Test
	public void testCalcularCaloriasRefeicaoMega() {
		Item item2 = new Item("Batata",20);
		this.cardapioSimples.adicionaItem(item2);
		String[] refeicao = {"Bananinha","Batata"};
		assertEquals(90, this.cardapioSimples.calcularCaloriasRefeicao(refeicao, "mega"));
	}
	
	@Test
	public void testCalcularCaloriasRefeicaoPadrao() {
		Item item2 = new Item("Batata",20);
		this.cardapioSimples.adicionaItem(item2);
		String[] refeicao = {"Bananinha","Batata"};
		assertEquals(30, this.cardapioSimples.calcularCaloriasRefeicao(refeicao, "padrao"));
	}
	
	@Test
	public void testTamanhoDoArrayDeItensPadrao() {
		assertEquals(5,this.cardapioSimples.getItens().length);
	}
	
	@Test
	public void testTamanhoDoArrayDeItensVariavel() {
		assertEquals(10,this.cardapioComposto.getItens().length);
	}
}
