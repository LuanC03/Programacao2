package quiosques;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class ItemTest {
	Item farofa,feijao,feijaoLeve,macarronada,macarronada2;
	
	@Before
	public void setUp() throws Exception {
		farofa = new Item("farofa",240);
		feijao = new Item("feijão",240);
		feijaoLeve = new Item("feijão",120);
		macarronada = new Item("macarronada",400);
		macarronada2 = new Item("macarronada",400);
	}

	@Test
	public void equalsMesmoNome() {
		assertEquals(feijao,feijaoLeve);
		assertEquals(macarronada,macarronada2);
	}
	
	@Test
	public void equalsTesteNomesDiferentes(){
		assertNotEquals(farofa,feijao);
		assertNotEquals(feijao,macarronada);
		assertEquals(feijao,feijaoLeve);
		assertNotEquals(macarronada,farofa);
	}
	
	@Test
	public void toStringTest() {
		String saidaEsperada = "feijão-240 calorias/porção";
		String saidaEsperada2 = "macarronada-400 calorias/porção";
		assertEquals(saidaEsperada,feijao.toString());
		assertNotEquals(feijao.toString(),feijaoLeve.toString());
		assertEquals(saidaEsperada2,macarronada.toString());
		assertEquals(macarronada.toString(),macarronada2.toString());
	}
	

}
