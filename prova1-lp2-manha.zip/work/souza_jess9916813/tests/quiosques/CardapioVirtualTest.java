package quiosques;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CardapioVirtualTest {
	CardapioVirtual cardapio;
	Item xburgao,xfrango,xegg;

	@Before
	public void setUp() throws Exception {
		cardapio = new CardapioVirtual(10,"Seu Olavo Entertainment");
		xburgao = new Item("X-burguer",560);
		xfrango = new Item("X-frango",460);
		cardapio.adicionaItem(xburgao);
		cardapio.adicionaItem(xfrango);
	}

	@Test
	public void testAdicionaItem() {
		assertEquals(xburgao,cardapio.getCardapio()[0]);
		assertEquals(xfrango,cardapio.getCardapio()[1]);
		assertNotEquals(cardapio.getCardapio()[0],cardapio.getCardapio()[1]);
	}

	@Test
	public void testListaCardapio() {
		String saidaDesejada = "1 X-burguer-560 calorias/porção\n2 X-frango-460 calorias/porção\n";
		String saidaIndesejada = "1 X-burguer-560 calorias/porção\n2 X-frango-460 calorias/porção";
		String saidaIndesejada2 = "1 X-burguer-560calorias/porção\n2 X-frango-460calorias/porção\n";
		assertEquals(saidaDesejada,cardapio.listaCardapio());
		assertNotEquals(cardapio.listaCardapio(),saidaIndesejada);
		assertNotEquals(cardapio.listaCardapio(),saidaIndesejada2);
		
	}

	@Test
	public void testCalcularCaloriasRefeicao() {
		xegg = new Item("X-Egg",600);
		String[] refeicao = {"X-burguer","X-frango"};
		assertEquals(cardapio.calcularCaloriasRefeicao(refeicao, "grande"),2040);
	}


}
