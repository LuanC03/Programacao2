package quiosques;

public class Teste {

	public static void main(String[] args) {
		String[] lista = new String[10];
		System.out.println(lista[0]);
		}

}
