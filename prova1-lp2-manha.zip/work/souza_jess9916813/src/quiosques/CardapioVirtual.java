package quiosques;

public class CardapioVirtual {
	private String nomeEstabelecimento;
	private Item[] cardapio = new Item[5];
	
	
	public CardapioVirtual(int tamanho,String nome) {
		this.cardapio = new Item[tamanho];
		this.nomeEstabelecimento = nome;
		
	}
	
	public void adicionaItem(Item itemParaAdicionar) {
		for(int i = 0; i < cardapio.length; i++) {
			if (cardapio[i] == null) {
				cardapio[i] = itemParaAdicionar;
				break;
			}
		}
	}
	public String listaCardapio() {
		String saida = "";
		for( int i = 0; i < cardapio.length; i++) {
			if(cardapio[i] != null) {
				saida += (i+1) + " " + this.cardapio[i].toString() + "\n";
		}else {
			break;
		}
		}
		return saida;
	}
	
	public int calcularCaloriasRefeicao(String[] refeicao,String tamanhoRefeicao) {
		int caloriasTotais = 0;
		if (temNoCardapio(refeicao)== false) {
			throw new IllegalArgumentException();
		}else {	
			for(int i = 0; i < refeicao.length; i++) {
				for (int k = 0; k < cardapio.length; k ++) {
					if ( refeicao[i].equals(cardapio[k].getNome())) {
						caloriasTotais += cardapio[k].getCalorias();
					}
				}
			}
			if (tamanhoRefeicao.equals("grande")) {
				caloriasTotais = caloriasTotais * 2;
			}
			else if (tamanhoRefeicao.equals("mega")) {
				caloriasTotais = caloriasTotais * 3;	
			}
			return caloriasTotais;
		}
	}
	
	public boolean temNoCardapio(String[] refeicao) {
		boolean teste = false;
		for (int k = 0; k < refeicao.length; k ++) {
			for(int l = 0; l < cardapio.length; l++) {
				if (cardapio[l] != null) {
					if (cardapio[l].getNome().equals(refeicao[k])) {
						teste = true;
				}
			}else {
				break;
			}
		}
		
}	return teste;
	}
	
	public String toString() {
		String saida = this.nomeEstabelecimento + " Itens:";
		for (int i = 0; i < this.cardapio.length; i++) {
			if (i == cardapio.length - 1) {
				saida += cardapio[i].getNome();
		}else {
			saida += cardapio[i].getNome() + ",";
		}
	}
	return saida;		
	
	}
	
	public Item[] getCardapio() {
		return this.cardapio;
	}
}
