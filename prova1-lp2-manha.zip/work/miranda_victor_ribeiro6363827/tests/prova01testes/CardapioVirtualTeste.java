package prova01testes;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CardapioVirtualTeste {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testCardapioVirtualStringInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testCardapioVirtualString() {
		fail("Not yet implemented");
	}

	@Test
	public void testAdicionaItem() {
		fail("Not yet implemented");
	}

	@Test
	public void testListaCardapio() {
		fail("Not yet implemented");
	}

	@Test
	public void testCalcularCaloriasRefeicao() {
		fail("Not yet implemented");
	}

}
