package prova01;

public class Item {
	private String nome;
	private int calorias;
	
	public Item(String nome, int calorias) {
		this.nome = nome;
		this.calorias = calorias;
	}

	public String getNome() {
		return nome;
	}

	
	public int getCalorias() {
		return calorias;
	}


	@Override
	public String toString() {
		return "Refeição: " + nome + "\n" + "Calorias: " + calorias;
	}
}
