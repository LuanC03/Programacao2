package prova01;

import prova01.Item;

public class CardapioVirtual {

	private String nome_estabelecimento;
	private int quant_itens;

	Item[] array_itens;

	public CardapioVirtual(String nome_estabelecimento, int quant_itens) {
		this.nome_estabelecimento = nome_estabelecimento;
		this.quant_itens = quant_itens;
		array_itens = new Item[quant_itens];
	}

	public CardapioVirtual(String nome_estabelecimento) {
		this.nome_estabelecimento = nome_estabelecimento;
		array_itens = new Item[5];
	}

	public void adicionaItem(Item item) {
		for (int i = 0; i < array_itens.length; i++) {
			if (array_itens[i] == null) {
				array_itens[i] = item;
				break;
			}
		}

	}

	public String listaCardapio() {
		String saida = "";
		for (int i = 0; i < array_itens.length; i++) {
			if (array_itens[i] != null) {
				saida = saida + array_itens[i].toString() + "/n";
			}

		}
		return saida;
	}

	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) throws Exception {
		int calorias = 0;
		try {
			for (int i = 0; i < refeicao.length; i++) {
				for (int j = 0; j < array_itens.length; j++) {
					if (refeicao[i] == array_itens[j].getNome()) {
						if (tamanhoRefeicao.equals("grande")) {
							calorias += array_itens[j].getCalorias() * 2;
						} else if (tamanhoRefeicao.equals("mega")) {
							calorias += array_itens[j].getCalorias() * 3;
						} else {
							calorias += array_itens[j].getCalorias();
						}
					}
				}
			}

		} catch (Exception IllegalArgumentException) {
			throw IllegalArgumentException;
		}

		return calorias;
	}
}
