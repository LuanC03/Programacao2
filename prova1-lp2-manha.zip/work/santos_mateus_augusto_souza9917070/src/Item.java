
public class Item {
	private int calorias;
	private String nome;
	
	public Item(String nome, int calorias){
		this.nome = nome;
		this.calorias = calorias;
	}
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		
		Item item = (Item) obj;
		return (item.nome == this.nome);
	}
	public String toString() {
		return (this.nome + " " + this.calorias);
	}
	public String getNome() {
		return (this.nome);
	}
	public int getCalorias() {
		return (this.calorias);
	}

}
