
public class Cardapio {
	private Item[] itens;
	private int itensAdicionados;
	private int somatorio = 0; 
	
	
	public Cardapio(String nome, int quantidadeDeItens){
		this.itens = new Item[quantidadeDeItens]; 
		this.itensAdicionados = 0;
		
		
	}
	public void adicionaItem(Item item) {
		this.itens[itensAdicionados] = item;
		itensAdicionados += 1;
			
	}
	public void listaCardapio() {
		for(int i = 0; i < itens.length; i++) {
			if (itens[i] != null) {
				System.out.println((i + 1) + " - " + itens[i].getNome() + " " + itens[i].getCalorias());
			}
		}
	}
	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		for(int j = 0; j < refeicao.length; j++) {
			for(int l = 0; l < itens.length; l++) {
				if (refeicao[j].equals(itens[l].getNome())){
					somatorio += itens[l].getCalorias();
				}
				
			}
		}
		if (tamanhoRefeicao.equals("padrão")){
			return (somatorio);
		}
		else if(tamanhoRefeicao.equals("grande")){
			return (somatorio * 2);
		
		
	}
		else {
			return (somatorio * 3);
		}
		
	}
	

}
