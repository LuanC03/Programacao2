import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CardapioTest {
	private String[] refeicao = {"peixe", "feijão"};
	private Item novoItem;
	private Item maisUmItem;
	private Cardapio cardapio;
	@Before
	
	public void registraCardapio() {
		
		Cardapio cardapio = new Cardapio("cardapio", 3);
		Item novoItem = new Item("batata", 50) ;
		Item maisUmItem = new Item("batata", 30);
		cardapio.adicionaItem(novoItem);
		cardapio.adicionaItem(maisUmItem);

	}
	
	@Test
	public void testEquals() {
		assertEquals(novoItem, maisUmItem);
	}
}