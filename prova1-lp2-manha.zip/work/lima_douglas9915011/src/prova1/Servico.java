package prova1;

public class Servico {
	public static void main(String[] args) {
		Cardapio hoje = new Cardapio("Almoço", 6);
		Item feijao = new Item("Feijão", 90);
		hoje.adicionaItem(feijao);
		System.out.println(hoje.listaCardapio());
	}
}
