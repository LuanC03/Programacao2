package prova1;

public class Cardapio {
	
	private String nome;
	private Item[] itens;
	int calorias, tamanho, posicao = 0;
	String lista;
	
	public Cardapio(String nome, int quantidade) {
		this.nome = nome;
		this.itens = new Item[quantidade];
		if (nome == null) {
			throw new NullPointerException("Nome nulo");
		}
		if (nome.trim().equals("")) {
			throw new IllegalArgumentException("Nome vazio");
		}
	}
	
	public Cardapio(String nome){
		this.nome = nome;
		this.itens = new Item[5];
	}
	
	public void adicionaItem(Item item) {
		this.itens[posicao] = item;
		posicao++;
	}
	
	public String listaCardapio() {
		lista = "";
		for (int i = 0; i <= itens.length; i++) {
			if (itens[i] == null) {
				break;
			} else {
				lista += ((i+1) + " - " + itens[i].toString() + "\n");
			}
		}
		return lista;
	}
	
	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) {
		if (tamanhoRefeicao.equals("padrão")) {
			tamanho = 1;
		} else if (tamanhoRefeicao.equals("grande")) {
			tamanho = 2;
		} else if (tamanhoRefeicao.equals("mega")) {
			tamanho = 3;
		}
		
		for (int i = 0; i <= refeicao.length; i++) {
			for (int p = 0; p <= itens.length; p++) {
				if (refeicao[i].equals(itens[p])) {
					calorias += (itens[p].getCalorias()*tamanho);
				} else {
					throw new IllegalArgumentException("Item inválido");
				}
			}
		}
				
		return calorias;		
	}

	public String getNome() {
		return (this.nome);
	}

	public Item[] getItens() {
		return (this.itens);
	}

	
}
