package prova1;

import static org.junit.Assert.*;

import org.junit.Test;

public class CardapioTest {
	
	@Test 
	public void testCardapioNomeNulo() {
		try {
			Cardapio hoje = new Cardapio(null, 6);
			if (hoje.getNome() == null) {
				fail("Nome do cardápio não pode ser nulo");
			}
		} catch (NullPointerException nn) {
			assertEquals(nn.getMessage(), "Nome nulo");
		}
	}

	@Test
	public void testCardapioNomeVazio() {
		try {
			Cardapio hoje = new Cardapio("   ", 6);
			if (hoje.getNome().trim().equals("")) {
				fail("Nome do cardápio não pode ser vazio");
			}
		} catch (IllegalArgumentException nv) {
			assertEquals(nv.getMessage(), "Nome vazio");
		}
	}

	@Test
	public void testAdicionaItem() {
		Cardapio hoje = new Cardapio("Almoço", 6);
		Item feijao = new Item("Feijão", 90);
		hoje.adicionaItem(feijao);
		assertEquals(feijao, hoje[0]);
	}

	@Test
	public void testCalcularCaloriasRefeicaoExisteItem() {
		int tamanho = 0;
		try {
			Cardapio hoje = new Cardapio(null, 6);
			Item feijao = new Item("Feijão", 90);
			hoje.adicionaItem(feijao);
			String[] refeicao = new String[1];
			refeicao[1] = "Arroz";
			hoje.calcularCaloriasRefeicao(refeicao, "grande");
			for (int p = 0; p <= hoje.getItens().length; p++) {
				if (refeicao[0].equals(hoje.getItens()[p])) {
					calorias += (hoje.getItens()[p].getCalorias()*tamanho);
				}
			}
		} catch (IllegalArgumentException ii) {
			assertEquals(ii.getMessage(), "Item inválido");
		}
	}

}
