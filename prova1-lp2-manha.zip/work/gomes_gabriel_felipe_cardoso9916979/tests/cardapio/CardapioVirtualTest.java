package cardapio;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Gabriel Felipe Cardoso Gomes - 117110681
 */
public class CardapioVirtualTest {
    
    
    @Test(expected=IllegalArgumentException.class)
    public void calcularCaloriasRefeicao1(){
        CardapioVirtual cv = new CardapioVirtual("Cardapio Teste");
        cv.adicionaItem(new Item("Arroz", 100));
        cv.adicionaItem(new Item("Feijoada", 150));
        String lista[] = new String[2];
        lista[0] = "Macarronada";
        lista[1] = "Arroz";
        int result = cv.calcularCaloriasRefeicao(lista, "padrão");
    }
    
    @Test
    public void calcularCaloriasRefeicao2(){
        CardapioVirtual cv = new CardapioVirtual("Cardapio Teste");
        cv.adicionaItem(new Item("Arroz", 100));
        cv.adicionaItem(new Item("Feijoada", 150));
        String lista[] = new String[2];
        lista[0] = "Feijoada";
        lista[1] = "Arroz";
        int result = cv.calcularCaloriasRefeicao(lista, "padrão");
        assertEquals("Calcular caloria errado", 250, result);
    }
    
    @Test(expected=IllegalArgumentException.class)
    public void calcularCaloriasRefeicao3(){
        CardapioVirtual cv = new CardapioVirtual("Cardapio Teste");
        cv.adicionaItem(new Item("Arroz", 100));
        cv.adicionaItem(new Item("Feijoada", 150));
        String lista[] = new String[2];
        lista[0] = "Feijoada";
        lista[1] = "Arroz";
        int result = cv.calcularCaloriasRefeicao(lista, "normal");
    }  
    
    @Test
    public void calcularCaloriasRefeicao4(){
        CardapioVirtual cv = new CardapioVirtual("Cardapio Teste");
        cv.adicionaItem(new Item("Arroz", 100));
        cv.adicionaItem(new Item("Feijoada", 150));
        int result = cv.calcularCaloriasRefeicao(null, "padrão");
        assertEquals("Calcular caloria errado", 0, result);
    }
    
    @Test(expected=IllegalArgumentException.class)
    public void calcularCaloriasRefeicao5(){
        CardapioVirtual cv = new CardapioVirtual("Cardapio Teste");
        String lista[] = new String[2];
        lista[0] = "Feijoada";
        lista[1] = "Arroz";
        int result = cv.calcularCaloriasRefeicao(lista, "padrão");
        assertEquals("Calcular caloria errado", 0, result);
    }

    @Test(expected=ArrayIndexOutOfBoundsException.class)
    public void calcularCaloriasRefeicao6(){
        CardapioVirtual cv = new CardapioVirtual("Cardapio Teste");
        cv.adicionaItem(new Item("arroz branco", 100));
        cv.adicionaItem(new Item("arroz a grega", 200));
        cv.adicionaItem(new Item("macarrao", 200));
        cv.adicionaItem(new Item("feijoada", 150));
        cv.adicionaItem(new Item("feijao verde", 90));
        cv.adicionaItem(new Item("frango assado", 90));
        cv.adicionaItem(new Item("bife", 100));
        cv.adicionaItem(new Item("vinagrete", 0));
    }

    @Test
    public void calcularCaloriasRefeicao7(){
        CardapioVirtual cv = new CardapioVirtual("Cardapio Teste");
        cv.adicionaItem(new Item("arroz branco", 100));
        cv.adicionaItem(new Item("arroz a grega", 200));
        cv.adicionaItem(new Item("macarrao", 200));
        cv.adicionaItem(new Item("feijoada", 150));
        cv.adicionaItem(new Item("feijao verde", 90));
        String l[] = {"arroz branco"};
        int result = cv.calcularCaloriasRefeicao(l, "padrão");
        assertEquals("Calcular caloria errado", 100, result);
    }
}
