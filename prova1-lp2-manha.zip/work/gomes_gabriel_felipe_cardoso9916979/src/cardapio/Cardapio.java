package cardapio;

/**
 *
 * @author Gabriel Felipe Cardoso Gomes - 117110681
 */
public class Cardapio {

    public static void main(String[] args) {
        CardapioVirtual cv = new CardapioVirtual("Teste",8);
        cv.adicionaItem(new Item("arroz branco", 100));
        cv.adicionaItem(new Item("arroz a grega", 200));
        cv.adicionaItem(new Item("macarrao", 200));
        cv.adicionaItem(new Item("feijoada", 150));
        cv.adicionaItem(new Item("feijao verde", 90));
        cv.adicionaItem(new Item("frango assado", 90));
        cv.adicionaItem(new Item("bife", 100));
        cv.adicionaItem(new Item("vinagrete", 0));
        System.out.println(cv.listaCardapio());
        String lista[] = {"arroz branco", "feijoada", "vinagrete"};
        System.out.println(cv.calcularCaloriasRefeicao(lista, "grande"));
    }
    
}
