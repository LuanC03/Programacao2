package cardapio;

/**
 *
 * @author Gabriel Felipe Cardoso Gomes - 117110681
 */
public class CardapioVirtual {
    private String nome;
    private Item[] listaDeItens;
    private int qtdItens;
    
    public CardapioVirtual(String nome, int quantidadeItens){
        this.nome = nome;
        listaDeItens = new Item[quantidadeItens];
        this.qtdItens = 0;
    }
    
    public CardapioVirtual(String nome){
        this(nome,5);
    }
    
    public void adicionaItem(Item item){
        this.listaDeItens[qtdItens++] = item;
    }
    
    public String listaCardapio(){
        String ret = "";
        for(int i = 0; i < qtdItens; i++){
            ret += (i + 1) + " - " + this.listaDeItens[i].toString() + "\n";
        }
        return ret;
    }
    
    private Item buscarNoCardapio(String nome){
        for(int i = 0; i < this.qtdItens; i++){
            if(this.listaDeItens[i].getNome().equals(nome)){
                return this.listaDeItens[i];
            }
        }
        return null;
    }
    
    public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao){
        int total = 0, multiplicador;
        switch(tamanhoRefeicao){
            case "padrão":
                multiplicador = 1;
                break;
            case "grande":
                multiplicador = 2;
                break;
            case "mega":
                multiplicador = 3;
                break;
            default:
                throw new IllegalArgumentException("Tamanho da Refeição inválido.");
        }
        if(refeicao == null)return 0;
        for (String refeicao1 : refeicao) {
            Item busca = buscarNoCardapio(refeicao1);
            if(busca == null)
                throw new IllegalArgumentException("Esse item não está cadastrado.");
            total += busca.getCaloriasPorPorcao();
        }
        total *= multiplicador;
        return total;
    }
}
