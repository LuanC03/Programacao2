package cardapio;

/**
 *
 * @author Gabriel Felipe Cardoso Gomes - 117110681
 */
public class Item {

    private String nome;
    private int caloriasPorPorcao;

    public Item(String nome, int caloriasPorPorcao) {
        this.nome = nome;
        this.caloriasPorPorcao = caloriasPorPorcao;
    }

    public String getNome() {
        return this.nome;
    }

    public int getCaloriasPorPorcao() {
        return this.caloriasPorPorcao;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Item other = (Item) obj;
        return this.nome.equals(other.getNome());
    }

    @Override
    public String toString() {
        return this.nome + " - " + this.caloriasPorPorcao + " calorias/porção.";
    }
}
