package controle_Refeição;

import java.util.HashMap;

public class Fachada {
	
	private HashMap<String, Dia> diasCadastrados = new HashMap<>();

	public void cadastraRefeicao(String data, String nome, String hora) throws Exception {
		if(diasCadastrados.containsKey(data)) {
			Refeicao refeicao = new Refeicao(nome, hora);
			diasCadastrados.get(data).adicionaRefeicao(refeicao);
		}
		else 
			throw new Exception("Dia Nao Cadastrado!");					
	}
	
	public void cadastraDia(String data) throws Exception {
		if(diasCadastrados.containsKey(data))
			throw new Exception("Dia Ja Cadastrado!");
		else {
			Dia dia = new Dia(data);
			diasCadastrados.put(data, dia);
		}
	}
	
	public void adicionaAlimentos(String data, String nomeRefeicao, String nomeAlimento, int calorias, int gordura, int carb) throws Exception {
		if(diasCadastrados.containsKey(data)) {
			Alimento alimento = new Alimento(nomeAlimento, calorias, gordura, carb);
			diasCadastrados.get(data).adiconaAlimentosARefeicao(nomeRefeicao, alimento);
		}else
			throw new Exception("Dia Nao Cadastrado");
	}
	
	public String representacaoDeUmaRefeicaoEspecifica(String data, String nomeRefeicao) throws Exception {
		if(diasCadastrados.containsKey(data))
			return diasCadastrados.get(data).refeicao(nomeRefeicao);
		else
			throw new Exception("Dia Nao Cadastrado");
	}
	
	public void calculaSaudeDasRefeicoesDiarias(String data) {
		diasCadastrados.get(data).calculaSaudeDiaria();
	}
}
