package controle_Refeição;

import java.util.ArrayList;

public class Refeicao {
	
	private final static String N = System.lineSeparator();
	private String nome;
	private String hora;
	private int nivelDeSaude;
	private ArrayList<Alimento> itensRefeicao;
	
	public Refeicao(String nome, String hora) throws Exception {
		if(nome.equals("")||nome.equals(" ")|| nome == null)
			throw new Exception("Nome da Refeicao Nao Pode Ser Nula");
		if(hora.equals("")||hora.equals(" ")|| hora == null)
			throw new Exception("Hora da Refeicao Nao Pode Ser Nula");
		this.nome = nome;
		this.hora = hora;
		nivelDeSaude = 0;
		itensRefeicao = new ArrayList<>();
	}

	public String getNome() {
		return nome;
	}

	public String getHora() {
		return hora;
	}

	public String toString() {
		return hora+" - "+nome;
	}

	public void adicionaAlimento(Alimento alimento) {
		itensRefeicao.add(alimento);
	}
	
	public void calculaNivelDeSaude() {
		int nivelDeSaude = 0;
		for (Alimento alimento : itensRefeicao) {
			nivelDeSaude = alimento.getCalorias()+ alimento.getCalorias()+ alimento.getCarb();
		}
		setNivelDeSaude(max(5 - nivelDeSaude / 80, 1));
	}
	
	public int getNivelDeSaude() {
		return nivelDeSaude;
	}

	private void setNivelDeSaude(int max) {
		this.nivelDeSaude = max;		
	}

	private int max(int i, int j) {
		if (i > j)
			return i;
		else
			return j;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Refeicao other = (Refeicao) obj;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		return true;
	}

	public String getAlimentos() {
		String retorno = "";
		for (Alimento alimento : itensRefeicao) {
			retorno += alimento.toString()+N;
		}
		return retorno;
	}
	
}
