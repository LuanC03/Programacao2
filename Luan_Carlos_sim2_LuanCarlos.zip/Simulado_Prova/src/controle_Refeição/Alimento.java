package controle_Refeição;

public class Alimento {

	private String nome;
	private int calorias;
	private int gordura;
	private int carb;

	public Alimento(String nome, int calorias, int gordura, int carb) throws Exception {
		if (nome.equals("") || nome.equals(" ") || nome == null)
			throw new Exception("Nome Nao Pode Ser Vazio ou Nulo.");
		if (calorias <= 0)
			throw new Exception("Quantidade de Calorias Nao Pode Ser Menor ou Igual a Zero");
		if (gordura <= 0)
			throw new Exception("Quantidade de Gordura Nao Pode Ser Menor ou Igual a Zero");
		if (carb <= 0)
			throw new Exception("Quantidade de Carboidratos Nao Pode Ser Menor ou Igual a Zero");
		this.nome = nome;
		this.calorias = calorias;
		this.gordura = gordura;
		this.carb = carb;
	}

	public String getNome() {
		return nome;
	}

	public int getCalorias() {
		return calorias;
	}

	public int getGordura() {
		return gordura;
	}

	public int getCarb() {
		return carb;
	}
	
	public String toString() {
		return nome + " - " + calorias;
	}
}
