package controle_Refeição;

import java.util.ArrayList;

public class Dia {
	
	private final static String N = System.lineSeparator();

	private String data;
	private double nivelDeSaudeDiaria;
	private ArrayList<Refeicao> refeicoesDoDia;
	
	@SuppressWarnings("unused")
	public Dia(String data) throws Exception {
		if(data.equals("")||data.equals(" "))
			throw new Exception("Data não pode ser vazia ou nula.");
		if(data == null)
			throw new Exception("Data nao pode ser vazia ou nula.");
		this.data = data;
		setNivelDeSaudeDiaria(0);
		refeicoesDoDia = new ArrayList<>();
	}

	public String getData() {
		return data;
	}
	
	public void adicionaRefeicao(Refeicao refeicao) {
		refeicoesDoDia.add(refeicao);
	}
	
	public void adiconaAlimentosARefeicao(String refeicao, Alimento alimento) throws Exception {
		Alimento alimentoAdicionado = null;
		for (Refeicao refeicao2 : refeicoesDoDia) {
			if(refeicao2.getNome().equalsIgnoreCase(refeicao)) {
				alimentoAdicionado = alimento;
				refeicao2.adicionaAlimento(alimento);
			}
		}
		if(alimentoAdicionado == null)
			throw new Exception("Refeicao Nao Cadastrada!");
		
	}
	
	public void calculaSaudeDiaria() {
		double nivelDeSaude = 0;
		for (Refeicao refeicao : refeicoesDoDia) {
			nivelDeSaude += refeicao.getNivelDeSaude();
		}
		setNivelDeSaudeDiaria(nivelDeSaude/refeicoesDoDia.size());
	}
	
	public String refeicao(String nome) {
		String retorno = "";
		for (Refeicao refeicao : refeicoesDoDia) {
			if(refeicao.getNome().equalsIgnoreCase(nome)) {
				retorno += refeicao.toString() + N + refeicao.getAlimentos();
				
			}
		}
		return retorno;
	}

	public double getNivelDeSaudeDiaria() {
		return nivelDeSaudeDiaria;
	}

	public void setNivelDeSaudeDiaria(double nivelDeSaudeDiaria) {
		this.nivelDeSaudeDiaria = nivelDeSaudeDiaria;
	}
}
