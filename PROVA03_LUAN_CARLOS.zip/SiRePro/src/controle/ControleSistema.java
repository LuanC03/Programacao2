/**
 * UFCG - UNIVERSIDADE FEDERAL DE CAMPINA GRANDE
 * LUAN CARLOS
 */
package controle;

import java.util.HashMap;
import java.util.HashSet;

public class ControleSistema {

	private HashMap<String, Pessoa> colecaoPessoas;
	private HashSet<Pessoa> listaPessoas;
	private String ultimaPessoa = "";
	private static final String N = System.lineSeparator();

	public ControleSistema() {
		this.colecaoPessoas = new HashMap<>();
		this.listaPessoas = new HashSet<>();
	}

	private boolean verificaAtributos(String nome, int autoestima, int nivelEmpatia, int ep) throws Exception {
		if (nome.trim().equals("") || nome == null)
			throw new Exception("Erro no cadastro de Pessoa: nome nao pode ser nulo ou vazio");
		else if (autoestima < 0 || autoestima > 10)
			throw new Exception("Erro no cadastro de Pessoa: autoestima tem que ser maior que 0 e menor que 10");
		else if (nivelEmpatia < 0 || nivelEmpatia > 10)
			throw new Exception("Erro no cadastro de Pessoa: nivel de Empatia tem que ser maior que 0 e menor que 10");
		else if (ep < 0 || ep > 100)
			throw new Exception(
					"Erro no cadastro de Pessoa: Experiencia Profissional tem que ser maior que 0 e menor que 100");
		else
			return true;
	}

	public void cadastrarPessoa(String nome, int autoestima, int nivelEmpatia, int ep) throws Exception {
		if(verificaAtributos(nome, autoestima, nivelEmpatia, ep)){
			Pessoa pessoa = new Pessoa(nome, autoestima, nivelEmpatia, ep);
			colecaoPessoas.put(nome, pessoa);
			listaPessoas.add(pessoa);
			ultimaPessoa = nome;
		}
	}
	
	public String recuperarPessoa(String nome) throws Exception{
		if(colecaoPessoas.containsKey(nome))
			return colecaoPessoas.get(nome).toString();
		else
			throw new Exception("Erro na Recuperacao de Pessoas: Pessoa nao cadastrada");
	}
	
	public String listaPessoas(){
		String retorno = "";
		for (Pessoa pessoa : listaPessoas) {
			if(pessoa.getNome().equals(ultimaPessoa))
				retorno += pessoa.toString();
			else
				retorno += pessoa.toString()+N;
		}
		return retorno;
	}
	
	public void ativarHabilidade(String nomePessoa, String hab) throws Exception{
		if(hab.trim().equals("") || hab == null)
			throw new Exception("Erro na ativacao da habilidade: Habilidade nao pode ser nula ou vazia");
		else if(colecaoPessoas.containsKey(nomePessoa))
			colecaoPessoas.get(nomePessoa).setHabilidade(hab);
		else
			throw new Exception("Erro na ativacao da habilidade: Pessoa nao Cadastrada");
	}
	
	public int getNivelHabilidade(String nomePessoa) throws Exception{
		if(colecaoPessoas.containsKey(nomePessoa))
			return colecaoPessoas.get(nomePessoa).getHabilidade();
		else
			throw new Exception("Erro na recuperacao do nivel de habilidade: Pessoa nao Cadastrada");
	}
	
	public void resolverProblema(String nomePessoa, int nivelProblema) throws Exception{
		if(colecaoPessoas.containsKey(nomePessoa)){
			if(colecaoPessoas.get(nomePessoa).getHabilidade() >= nivelProblema)
				colecaoPessoas.get(nomePessoa).setProblemasResolvidos();
		}else{
			throw new Exception("Erro na Resolucao do Problema: Pessoa nao Cadastrada");
		}
	}
	
	public int getProblemasResolvidos(String nomePessoa) throws Exception{
		if(colecaoPessoas.containsKey(nomePessoa))
			return colecaoPessoas.get(nomePessoa).getProblemasResolvidos();
		else
			throw new Exception("Erro na recuperacao do Total de Problemas Resolvidos: Pessoa nao cadastrada");
	}
}
