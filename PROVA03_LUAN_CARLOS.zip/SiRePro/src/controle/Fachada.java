/**
 * UFCG - UNIVERSIDADE FEDERAL DE CAMPINA GRANDE
 * LUAN CARLOS
 */
package controle;

public class Fachada {

	private ControleSistema sistema = new ControleSistema();

	public void cadastrarPessoa(String nome, int autoestima, int nivelEmpatia, int ep) throws Exception {
		sistema.cadastrarPessoa(nome, autoestima, nivelEmpatia, ep);
	}
	
	public String recuperarPessoa(String nome) throws Exception{
		return sistema.recuperarPessoa(nome);
	}
	
	public String listaPessoas(){
		return sistema.listaPessoas();
	}
	
	public void ativarHabilidade(String nomePessoa, String hab) throws Exception{
		sistema.ativarHabilidade(nomePessoa, hab);
	}
	
	public int getNivelHabilidade(String nomePessoa) throws Exception{
		return sistema.getNivelHabilidade(nomePessoa);
	}
	
	public void resolverProblema(String nomePessoa, int nivelProblema) throws Exception{
		sistema.resolverProblema(nomePessoa, nivelProblema);
	}
	
	public int getProblemasResolvidos(String nomePessoa) throws Exception{
		return sistema.getProblemasResolvidos(nomePessoa);
	}
	
}
