/**
 * UFCG - UNIVERSIDADE FEDERAL DE CAMPINA GRANDE
 * LUAN CARLOS
 */
package controle;

public class Pessoa {

	private String nome;
	private int autoestima;
	private int nivelEmpatia;
	private int ep;
	private int habilidade;
	private int problemasResolvidos;

	private void verificaAtributos(String nome, int autoestima, int nivelEmpatia, int ep) throws Exception {
		if (nome.trim().equals("") || nome == null)
			throw new Exception("Erro no cadastro de Pessoa: nome nao pode ser nulo ou vazio");
		else if (autoestima < 0 || autoestima > 10)
			throw new Exception("Erro no cadastro de Pessoa: autoestima tem que ser maior que 0 e menor que 10");
		else if (nivelEmpatia < 0 || nivelEmpatia > 10)
			throw new Exception("Erro no cadastro de Pessoa: nivel de Empatia tem que ser maior que 0 e menor que 10");
		else if (ep < 0 || ep > 100)
			throw new Exception(
					"Erro no cadastro de Pessoa: Experiencia Profissional tem que ser maior que 0 e menor que 100");
	}
	
	public Pessoa(String nome, int autoestima, int nivelEmpatia, int ep) throws Exception {
		verificaAtributos(nome, autoestima, nivelEmpatia, ep);
		this.nome = nome;
		this.autoestima = autoestima;
		this.nivelEmpatia = nivelEmpatia;
		this.ep = ep;
		this.habilidade = calculaHabilidade("pessoal");
		this.problemasResolvidos = 0;
	}

	public String getNome() {
		return this.nome;
	}

	public int getAutoestima() {
		return this.autoestima;
	}

	public int getNivelEmpatia(){
		return this.nivelEmpatia;
	}
	
	public int getEp(){
		return this.ep;
	}
	
	public int getHabilidade(){
		return this.habilidade;
	}
	
	public void setHabilidade(String hab){
		calculaHabilidade(hab);
	}
	
	public int getProblemasResolvidos(){
		return this.problemasResolvidos;
	}
	
	public void setProblemasResolvidos(){
		this.problemasResolvidos ++;
	}
	
	private int calculaHabilidade(String habilidade){
		int valorHabilidade = 0;
		if(habilidade.equalsIgnoreCase("Pessoal"))
			valorHabilidade = (int) ((0.5 * this.autoestima) + (0.3 * (this.ep/10)) + (0.2 * this.nivelEmpatia)); 
		else if(habilidade.equalsIgnoreCase("Profissional")){			
			valorHabilidade = (int) (this.ep/10);
			if(this.autoestima < 7 || this.nivelEmpatia < 7)
				valorHabilidade = (int) (valorHabilidade - (valorHabilidade*0.1));
		}else if(habilidade.equalsIgnoreCase("Interpessoal"))
			valorHabilidade = (int) ((0.3*this.autoestima)+(0.2*(this.ep/10))+(0.5*this.nivelEmpatia));
		
		return valorHabilidade;
	}
	
	public String toString(){
		return this.nome + " - " + this.autoestima + " - " + this.nivelEmpatia + " - " + this.ep;
	}
}
