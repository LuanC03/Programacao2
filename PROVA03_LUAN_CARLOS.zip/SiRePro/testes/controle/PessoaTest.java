/**
 * UFCG - UNIVERSIDADE FEDERAL DE CAMPINA GRANDE
 * LUAN CARLOS
 */
package controle;

import org.junit.Test;

public class PessoaTest {
	
	@SuppressWarnings("unused")
	private Pessoa pessoa1;
	@SuppressWarnings("unused")
	private Pessoa pessoa2;
	@SuppressWarnings("unused")
	private Pessoa pessoa3;

	@Test
	(expected = Exception.class)
	public void criaPessoaNomeVazioTest() throws Exception{
		pessoa1 = new Pessoa("   ", 9, 9, 75);
	}
	
	@Test
	(expected = Exception.class)
	public void criaPessoaNomeNuloTest() throws Exception{
		pessoa2 = new Pessoa(null, 10, 10, 100);
	}
	
	@Test
	(expected = Exception.class)
	public void criaPessoaAutoEstimaInvalidaTest() throws Exception{
		pessoa3 = new Pessoa("Joao Bobo", -1, 3, 45);
		pessoa1 = new Pessoa("Luan Carlos", 101, 9, 75);
	}
	
	@Test
	(expected = Exception.class)
	public void criaPessoaNivelEmpatiaInvalidaTest() throws Exception{
		pessoa3 = new Pessoa("Joao Bobo", 3, -7, 45);
		pessoa2 = new Pessoa("Matheli Li", 100, 356, 75);
	}
	
	@Test
	(expected = Exception.class)
	public void criaPessoaExperienciaProfissionalInvalidaTest() throws Exception{
		pessoa1 = new Pessoa("Luan Carlos", 7, 3, -15478);
		pessoa2 = new Pessoa("Matheli Li", 10, 9, 750);
	}

}
