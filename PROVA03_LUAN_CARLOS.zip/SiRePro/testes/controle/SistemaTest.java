/**
 * UFCG - UNIVERSIDADE FEDERAL DE CAMPINA GRANDE
 * LUAN CARLOS
 */
package controle;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class SistemaTest {

	private ControleSistema sistema;
	private static final String N = System.lineSeparator();
	
	@Before
	public void inicializa() throws Exception{
		sistema = new ControleSistema();		
		sistema.cadastrarPessoa("Luan Carlos", 9, 9, 75);
		sistema.cadastrarPessoa("Matheli Li", 10, 10, 100);
		sistema.cadastrarPessoa("Joao Bobo", 5, 3, 45);
		sistema.ativarHabilidade("Luan Carlos", "Pessoal");
		sistema.ativarHabilidade("Matheli Li", "Interpessoal");
		sistema.ativarHabilidade("Joao Bobo", "Profissional");
	}
	
	@Test
	public void recuperarPessoaTest() throws Exception{
		assertEquals("Luan Carlos - 9 - 9 - 75", sistema.recuperarPessoa("Luan Carlos"));
		assertEquals("Matheli Li - 10 - 10 - 100", sistema.recuperarPessoa("Matheli Li"));
		assertEquals("Joao Bobo - 5 - 3 - 45", sistema.recuperarPessoa("Joao Bobo"));
	}		

	@Test
	public void listaPessoasTest(){
		assertEquals("Matheli Li - 10 - 10 - 100"+N+"Luan Carlos - 9 - 9 - 75"+N+"Joao Bobo - 5 - 3 - 45", sistema.listaPessoas());
	}
	
	@Test
	public void getNivelHabilidadeTest() throws Exception {
		assertEquals(8, sistema.getNivelHabilidade("Luan Carlos"));
		assertEquals(10, sistema.getNivelHabilidade("Matheli Li"));
		assertEquals(4, sistema.getNivelHabilidade("Joao Bobo"));
	}
	
	@Test
	public void resolverProblemaTest() throws Exception{		
		sistema.resolverProblema("Luan Carlos", 3);
		sistema.ativarHabilidade("Luan Carlos", "Interpessoal");
		sistema.resolverProblema("Luan Carlos", 8);
		sistema.resolverProblema("Luan Carlos", 6);
		sistema.resolverProblema("Matheli Li", 10);
		sistema.ativarHabilidade("Matheli Li", "Profissional");
		sistema.resolverProblema("Matheli Li", -9);
		sistema.resolverProblema("Joao Bobo", 7);
		sistema.ativarHabilidade("Joao Bobo", "Pessoal");
		sistema.resolverProblema("Joao Bobo", 5);
		assertEquals(3, sistema.getProblemasResolvidos("Luan Carlos"));
		assertEquals(2, sistema.getProblemasResolvidos("Matheli Li"));
		assertEquals(0, sistema.getProblemasResolvidos("Joao Bobo"));
	}
}
