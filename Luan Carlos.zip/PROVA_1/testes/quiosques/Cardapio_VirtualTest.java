package quiosques;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class Cardapio_VirtualTest {

	private Cardapio_Virtual cardapio1;
	private Cardapio_Virtual cardapio2;
	private Cardapio_Virtual cardapio3;
	private Cardapio_Virtual cardapio4;
	private Cardapio_Virtual cardapio5;
	private Item item1;
	private Item item2;
	private Item item3;
	private Item item4;
	private Item item5;
	private Item item6;
	private Item item7;
	private Item item8;
	private Item item9;
	private Item item10;

	@Before
	public void iniciaItens() throws Exception {
		item1 = new Item("Arroz Branco", 100);
		item2 = new Item("Macarrao", 200);
		item3 = new Item("feijoada", 150);
		item4 = new Item("bife", 100);
		item5 = new Item("Vinagrete", 0);
		item6 = new Item("Matuta", 75);
		item7 = new Item("Refri", 178);
		item8 = new Item("Biscoito", 213);
		item9 = new Item("X Burguer", 350);
		item10 = new Item("Tampico", 25);
	}

	@Before
	public void iniciaCardapios() throws Exception {
		cardapio1 = new Cardapio_Virtual("Seu Olavo", 3);
		cardapio2 = new Cardapio_Virtual("C.U.", 1);
		cardapio3 = new Cardapio_Virtual("Emporio", 4);
		cardapio4 = new Cardapio_Virtual("Anel Universitario", 0);
		cardapio5 = new Cardapio_Virtual("Marcus", 2);
		cardapio1.adicionaItem(item10);
		cardapio1.adicionaItem(item9);
		cardapio1.adicionaItem(item7);
		cardapio2.adicionaItem(item6);
		cardapio3.adicionaItem(item8);
		cardapio3.adicionaItem(item7);
		cardapio3.adicionaItem(item10);
		cardapio3.adicionaItem(item6);
		cardapio4.adicionaItem(item1);
		cardapio4.adicionaItem(item2);
		cardapio4.adicionaItem(item3);
		cardapio4.adicionaItem(item4);
		cardapio4.adicionaItem(item5);
		cardapio5.adicionaItem(item1);
		cardapio5.adicionaItem(item3);
	}

	@Test
	public void testRepresentacaoTextualCardapio() {
		assertEquals(
				"Seu Olavo - Cardapio: Tampico - 25 calorias/porcao, X Burguer - 350 calorias/porcao, Refri - 178 calorias/porcao",
				cardapio1.toString());
		assertEquals("C.U. - Cardapio: Matuta - 75 calorias/porcao", cardapio2.toString());
		assertEquals(
				"Emporio - Cardapio: Biscoito - 213 calorias/porcao, Refri - 178 calorias/porcao, Tampico - 25 calorias/porcao, Matuta - 75 calorias/porcao",
				cardapio3.toString());
		assertEquals(
				"Anel Universitario - Cardapio: Arroz Branco - 100 calorias/porcao, Macarrao - 200 calorias/porcao, feijoada - 150 calorias/porcao, bife - 100 calorias/porcao, Vinagrete - 0 calorias/porcao",
				cardapio4.toString());
		assertEquals("Marcus - Cardapio: Arroz Branco - 100 calorias/porcao, feijoada - 150 calorias/porcao",
				cardapio5.toString());
	}

}
