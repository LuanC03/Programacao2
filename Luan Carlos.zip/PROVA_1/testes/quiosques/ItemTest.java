package quiosques;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ItemTest {

	private Item item1;
	private Item item2;
	private Item item3;
	private Item item4;
	private Item item5;
		
	@Before
	public void iniciaItens() throws Exception {
		item1 = new Item("Arroz Branco", 100);
		item2 = new Item("Macarrao", 200);		
		item3 = new Item("feijoada", 150);
		item4 = new Item("bife", 100);
		item5 = new Item("Vinagrete", 0);
	}
	
	@Test
	public void testRepresentacaoTextual() {
		assertEquals("Arroz Branco - 100 calorias/porcao", item1.toString());
		assertEquals("Macarrao - 200 calorias/porcao", item2.toString());
		assertEquals("feijoada - 150 calorias/porcao", item3.toString());
		assertEquals("bife - 100 calorias/porcao", item4.toString());
		assertEquals("Vinagrete - 0 calorias/porcao", item5.toString());
	}
	
	@Test
	public void testCriacaoItensNomeIvalido() {
		try {
			item1 = new Item("", 100);
			item2 = new Item(" ", 986);
		}catch(Exception e) {
			System.out.println(e);
		}
		try {
			item3 = new Item(null, 0);
		}catch(Exception e) {
			System.out.println(e);
			fail();
		}
	}
	
	@Test
	public void testCriacaoItensQTDCaloriaInvalida() {
		try {
			item5 = new Item("Batata Frita", -125);
		}catch(Exception e) {
			System.out.println(e);
		}
		try {
			item4 = new Item("Matuta", -8961);
		}catch(Exception e) {
			System.out.println(e);
		}
	}
}
