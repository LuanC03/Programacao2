package quiosques;

public class Cardapio_Virtual {

	private String nome;
	private Item[] itens;
	private int contador;

	public Cardapio_Virtual(String nome, int qtdItens) throws IllegalArgumentException {
		if(nome.equals("")|| nome.equals(" ")|| nome == null)
			throw new IllegalArgumentException("Nome Nao Pode Estar Vazio");
		if(qtdItens == 0)
			qtdItens = 5;
		this.nome = nome;
		itens = new Item[qtdItens];
		contador = 0;
	}

	public void adicionaItem(Item item) {
		itens[getContador()] = item;
		setContador();
	}

	public String listaCardapio() {
		String retorno = "";
		for (Item item : itens) {
			retorno += getContador() + 1 + " " + item.toString();
		}
		return retorno;
	}

	public int calcularCaloriasRefeicao(String[] refeicao, String tamanhoRefeicao) throws IllegalArgumentException {
		int retorno = 0;
		int tamanho = 0;
		int contador1 = 0;
		int contador2 = 0;
		if (tamanhoRefeicao.equalsIgnoreCase("padrao"))
			tamanho = 1;
		else if (tamanhoRefeicao.equalsIgnoreCase("grande"))
			tamanho = 2;
		else if (tamanhoRefeicao.equalsIgnoreCase("Mega"))
			tamanho = 3;
		else
			throw new IllegalArgumentException("Tamanho da Refeicao Invalido"); 
		for (String prato : refeicao) {
			contador1 +=1;
			for (Item item : itens) {
				if (prato.equalsIgnoreCase(item.getNome())) {
					retorno += item.getCalorias();
					contador2 += 1;
				}
			}
		}
		if(contador1 != contador2)
			throw new IllegalArgumentException("Algum Item nao existente no Cardapio");
		retorno = retorno * tamanho;

		return retorno;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getContador() {
		return contador;
	}

	public void setContador() {
		this.contador += 1;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cardapio_Virtual other = (Cardapio_Virtual) obj;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		return true;
	}

	@Override
	public String toString() {
		String retorno = "";
		for (int i = 0; i < itens.length; i++) {
			if(i+1==itens.length)
				retorno += itens[i].toString();
			else
				retorno += itens[i].toString()+", ";
		}
		return nome + " - Cardapio: " + retorno;
	}

}
