package siplafe;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ControladorTest {

	private Controlador sistema = new Controlador();
	private Controlador sistema2 = new Controlador();

	@Before
	public void adicionaPlanos() throws Exception {
		sistema.cadastraPlano("Programar", "Programar Java todo dia sempre para fazer sistemas mega-poderosos!", 10);
		sistema.cadastraPlano("Desenvolvimento Web",
				"Programar Java todo dia sempre para fazer sistemas mega-poderosos!", 8);
		sistema.cadastraPlano("Aprender a usar a Cloud",
				"Programar Java todo dia sempre para fazer sistemas mega-poderosos!", 5);
	}

	@Test
	public void recuperaPlanoTest() throws Exception {
		assertEquals("Programar - 10 - Programar Java todo dia sempre para fazer sistemas mega-poderosos!",
				sistema.recuperaPlano("Programar"));
		assertEquals("Desenvolvimento Web - 8 - Programar Java todo dia sempre para fazer sistemas mega-poderosos!",
				sistema.recuperaPlano("Desenvolvimento Web"));
		assertEquals("Aprender a usar a Cloud - 5 - Programar Java todo dia sempre para fazer sistemas mega-poderosos!",
				sistema.recuperaPlano("Aprender a usar a Cloud"));
	}

	@Test
	public void maiorPrioridadeTest() throws Exception {
		assertEquals("Programar - 10 - Programar Java todo dia sempre para fazer sistemas mega-poderosos!",
				sistema.maiorPrioridade());
	}

	@Test
	public void dependenciasTest() throws Exception {
		sistema.criaDependencia("Programar", "Desenvolvimento Web");
		sistema.criaDependencia("Programar", "Aprender a usar a Cloud");
		assertEquals("Desenvolvimento Web - 8\nAprender a usar a Cloud - 5", sistema.recuperaDependencias("Programar"));
	}

	@Test(expected = Exception.class)
	public void listaDependenciasVazia() throws Exception {
		sistema.recuperaDependencias("Desenvolvimento Web");
	}

	@Test(expected = Exception.class)
	public void criarDependenciaComPlanosInvalidosTest() throws Exception {
		sistema.criaDependencia("CC", "Programar");
		sistema.criaDependencia("Programar", "CC");
	}

	@Test(expected = Exception.class)
	public void recuperarPrioridadeSemNenhumPlanoCadastradoTest() throws Exception {
		sistema2.maiorPrioridade();
	}

	@Test(expected = Exception.class)
	public void recuperarPlanoNaoCadastradoTest() throws Exception {
		sistema.recuperaPlano("CC");
	}
}
