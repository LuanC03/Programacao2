package siplafe;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PlanoTest {

	private Plano plano1;
	private Plano plano2;
	private Plano plano3;
	
	@Before
	public void criaPlanos() throws Exception {
		plano1 = new Plano("Programar" , "Programar Java todo dia sempre para fazer sistemas mega-poderosos!" , 10);
		plano2 = new Plano("Desenvolvimento Web" , "Programar Java todo dia sempre para fazer sistemas mega-poderosos!" , 8);
		plano3 = new Plano("Aprender a usar a Cloud" , "Programar Java todo dia sempre para fazer sistemas mega-poderosos!" , 5);
	}

	@Test(expected = Exception.class)
	public void planosComNomeNuloOuVazioTest() throws Exception {
		plano1 = new Plano("", "Programar Java todo dia sempre para fazer sistemas mega-poderosos!" , 10);
		plano2 = new Plano(" ", "Programar Java todo dia sempre para fazer sistemas mega-poderosos!" , 10);
		plano3 = new Plano(null, "Programar Java todo dia sempre para fazer sistemas mega-poderosos!" , 10);
	}
	
	@Test(expected = Exception.class)
	public void planosComDescricaoNuloOuVazioTest() throws Exception {
		plano1 = new Plano("Programar", "" , 10);
		plano2 = new Plano("Programar", " " , 10);
		plano3 = new Plano("Programar", null, 10);
	}
	
	@Test(expected = Exception.class)
	public void planosComPrioridadeIgualOuAbaixoDeZeroTest() throws Exception {
		plano1 = new Plano("Programar", "Programar Java todo dia sempre para fazer sistemas mega-poderosos!" , 0);
		plano2 = new Plano("Programar", "Programar Java todo dia sempre para fazer sistemas mega-poderosos!" , -1);
		plano3 = new Plano("Programar", "Programar Java todo dia sempre para fazer sistemas mega-poderosos!", -45);
	}	
	
	@Test
	public void representacaoTextualDoPlanoTest() {
		assertEquals("Programar - 10 - Programar Java todo dia sempre para fazer sistemas mega-poderosos!", plano1.toString());
		assertEquals("Desenvolvimento Web - 8 - Programar Java todo dia sempre para fazer sistemas mega-poderosos!", plano2.toString());
		assertEquals("Aprender a usar a Cloud - 5 - Programar Java todo dia sempre para fazer sistemas mega-poderosos!", plano3.toString());
	}
	
}
