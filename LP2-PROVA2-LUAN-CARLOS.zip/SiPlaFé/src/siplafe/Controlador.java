package siplafe;

import java.util.ArrayList;

public class Controlador {

	private ArrayList<Plano> planos = new ArrayList<>();

	private Plano procuraPlano(String nomePlano) {
		for (Plano plano : planos) {
			if (plano.getNome().equals(nomePlano))
				return plano;
		}
		return null;
	}

	public void cadastraPlano(String nome, String descricao, int prioridade) throws Exception {
		Plano plano = new Plano(nome, descricao, prioridade);
		planos.add(plano);
	}

	public String recuperaPlano(String nome) throws Exception {
		Plano plano = procuraPlano(nome);
		if (plano == null)
			throw new Exception("Erro na Recuperacao do Plano: Plano nao cadastrado.");
		else
			return plano.toString();
	}

	public String maiorPrioridade() throws Exception {
		Plano planoPrioritario = null;
		int maiorPrioridade = 0;
		for (Plano plano : planos) {
			if (plano.getPrioridade() >= maiorPrioridade) {
				maiorPrioridade = plano.getPrioridade();
				planoPrioritario = plano;
			}
		}
		if (planoPrioritario == null)
			throw new Exception("Erro na Recuperacao de Maior Prioridade: Nenhum Plano Cadastrado.");
		else
			return planoPrioritario.toString();
	}

	public void criaDependencia(String nomePlano, String nomePlanoDependente) throws Exception {
		Plano plano = procuraPlano(nomePlano);
		Plano planoDependente = procuraPlano(nomePlanoDependente);
		if (plano == null)
			throw new Exception("Erro na Criacao de Dependencias: Plano Nao Cadastrado");
		else if (planoDependente == null)
			throw new Exception("Erro na Criacao de Dependencias: Plano Nao Cadastrado");
		else
			plano.adicionaPlanoDependente(planoDependente);
	}

	public String recuperaDependencias(String nomePlano) throws Exception {
		Plano plano = procuraPlano(nomePlano);
		if (plano == null)
			throw new Exception("Erro na Recuperacao de Dependencias: Plano Nao Cadastrado");
		else
			return plano.recuperaDependencias();
	}
}
