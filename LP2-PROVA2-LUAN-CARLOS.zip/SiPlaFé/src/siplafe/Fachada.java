package siplafe;

public class Fachada {

	private Controlador sistema = new Controlador();
	
	public void cadastraPlano(String nome, String descricao, int prioridade) throws Exception {
		sistema.cadastraPlano(nome, descricao, prioridade);
	}
	
	public String recuperaPlano(String nome) throws Exception {
		return sistema.recuperaPlano(nome);
	}
	
	public String maiorPrioridade() throws Exception {
		return sistema.maiorPrioridade();
	}
	
	public void criaDependencia(String nomePlano, String nomePlanoDependente) throws Exception {
		sistema.criaDependencia(nomePlano, nomePlanoDependente);
	}
	
	public String recuperaDependencias(String nomePlano) throws Exception {
		return sistema.recuperaDependencias(nomePlano);
	}
}
