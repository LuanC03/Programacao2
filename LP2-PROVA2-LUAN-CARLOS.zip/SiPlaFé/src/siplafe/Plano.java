package siplafe;

import java.util.ArrayList;

public class Plano {
	
	private final static String N = System.lineSeparator();			
	
	private String nome;
	private String descricao;
	private int prioridade;
	private ArrayList<Plano> planosDependentes;

	public Plano(String nome, String descricao, int prioridade) throws Exception {
		if(nome.equals("")|| nome.equals(" ")||nome == null)
			throw new Exception("Erro no Cadastro dos Planos: Nome nao pode ser vazio ou nulo");
		if(descricao.equals("")|| descricao.equals(" ")||descricao == null)
			throw new Exception("Erro no Cadastro dos Planos: Descricao nao pode ser vazio ou nulo");
		if(prioridade <= 0)
			throw new Exception("Erro no Cadastro dos Planos: Prioridade nao pode ser menor ou igual a Zero");
		this.nome = nome;
		this.descricao = descricao;
		this.prioridade = prioridade;
		planosDependentes = new ArrayList<>();
	}

	public String getNome() {
		return nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public int getPrioridade() {
		return prioridade;
	}
	
	public void adicionaPlanoDependente(Plano plano) {
		planosDependentes.add(plano);
	}

	@Override
	public String toString() {
		return nome + " - " + prioridade + " - " + descricao;
	}

	public String recuperaDependencias() throws Exception {
		String retorno = "";		
		for (int i = 0; i < planosDependentes.size(); i++) {
			if(i+1 == planosDependentes.size())
				retorno += planosDependentes.get(i).getNome() + " - " + planosDependentes.get(i).getPrioridade();
			else
				retorno += planosDependentes.get(i).getNome() + " - " + planosDependentes.get(i).getPrioridade()+N;
		}
		if(retorno.equals(""))
			throw new Exception("Erro na Recuperacao de Dependencias: Nao Existe Plano Dependente deste");
		else
			return retorno;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((descricao == null) ? 0 : descricao.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result + prioridade;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Plano other = (Plano) obj;
		if (descricao == null) {
			if (other.descricao != null)
				return false;
		} else if (!descricao.equals(other.descricao))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (prioridade != other.prioridade)
			return false;
		return true;
	}
	
}
